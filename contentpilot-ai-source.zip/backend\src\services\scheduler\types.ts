export type ScheduledTaskType =
  | 'research'
  | 'content_generation'
  | 'rendering'
  | 'approval_reminders'
  | 'publishing'
  | 'analytics'
  | 'learning';

export type ScheduleType = 'one_time' | 'daily' | 'weekly' | 'custom_interval';

export type ScheduledTaskStatus = 'ACTIVE' | 'PAUSED' | 'COMPLETED' | 'DISABLED';

export interface CreateScheduledTaskInput {
  channelId?: string;
  name: string;
  taskType: ScheduledTaskType;
  scheduleType: ScheduleType;
  intervalMs?: number;
  preferredTime?: string; // e.g. "14:00"
  timezone?: string;
  config?: Record<string, unknown>;
  nextRunAt?: Date;
}

export interface SchedulerConfig {
  automationEnabled: boolean;
  researchEnabled: boolean;
  generationEnabled: boolean;
  autoPublishEnabled: boolean;
  publishingCadence: string;
  preferredPublishTime: string;
  timezone: string;
  maxVideosPerDay: number;
  maxConcurrentJobs: number;
}

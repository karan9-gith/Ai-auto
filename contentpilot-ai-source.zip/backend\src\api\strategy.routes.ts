import { Router, Request, Response, NextFunction } from 'express';
import { prisma } from '../database/client.js';
import { defaultAiProvider } from '../services/ai/defaultAIProvider.js';
import { AppError } from '../utils/errors.js';

const router = Router();
const param = (p: string | string[]): string => (Array.isArray(p) ? p[0] : p);

// GET all content strategies
router.get('/', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const channelId = req.query.channelId as string | undefined;
    const strategies = await prisma.contentStrategy.findMany({
      where: channelId ? { channelId } : undefined,
      include: {
        idea: true,
        scripts: { select: { id: true, title: true, status: true } },
      },
      orderBy: { createdAt: 'desc' },
      take: 50,
    });
    res.json({ success: true, count: strategies.length, data: strategies });
  } catch (err) {
    next(err);
  }
});

// POST generate strategy from an idea
router.post('/generate', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { ideaId, channelId } = req.body;
    if (!ideaId || !channelId) {
      res.status(400).json({ success: false, error: 'Fields "ideaId" and "channelId" are required' });
      return;
    }

    const [idea, channel] = await Promise.all([
      prisma.contentIdea.findUnique({ where: { id: ideaId } }),
      prisma.channel.findUnique({ where: { id: channelId }, include: { settings: true } }),
    ]);

    if (!idea || !channel) {
      throw new AppError('Idea or Channel not found', 404, 'NOT_FOUND');
    }

    const aiResult = await defaultAiProvider.generateStrategy({
      selectedIdea: {
        topic: idea.topic,
        angle: idea.angle,
        audience: idea.targetAudience,
        trendScore: idea.trendScore,
        searchIntent: idea.searchIntent,
        competitionScore: idea.competitionScore,
        noveltyScore: idea.noveltyScore,
        evergreenScore: idea.evergreenScore,
        riskScore: idea.riskScore,
        recommendedFormat: idea.recommendedFormat,
        sourceUrls: JSON.parse(idea.sourceUrlsJson || '[]'),
        evidenceSummary: idea.evidenceSummary,
      },
      channelNiche: channel.niche,
      targetAudience: channel.targetAudience,
      contentPillars: JSON.parse(channel.settings?.contentPillars || '[]'),
      cadencePerWeek: channel.settings?.defaultCadencePerWeek || 2,
      defaultFormat: channel.settings?.defaultFormat || 'explainer',
    });

    const strategy = await prisma.contentStrategy.create({
      data: {
        channelId,
        ideaId: idea.id,
        titleConcept: aiResult.titleConcept,
        hook: aiResult.hook,
        angle: aiResult.angle,
        targetAudience: aiResult.audience,
        contentPillars: JSON.stringify([aiResult.contentPillar]),
        format: aiResult.format,
        estimatedDurationSec: aiResult.estimatedDurationSec,
        primaryKeyword: aiResult.primaryKeyword,
        secondaryKeywords: JSON.stringify(aiResult.secondaryKeywords),
        cta: aiResult.cta,
        thumbnailConcept: aiResult.thumbnailConcept,
        expectedKpi: aiResult.expectedKpi,
        priority: aiResult.priority,
        risk: aiResult.risk,
        reasonForSelection: aiResult.reasonForSelection,
        status: 'approved',
      },
      include: { idea: true },
    });

    // Mark idea as planned
    await prisma.contentIdea.update({
      where: { id: idea.id },
      data: { status: 'planned' },
    });

    res.json({ success: true, data: strategy });
  } catch (err) {
    next(err);
  }
});

export default router;

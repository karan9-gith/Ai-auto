import { Router, Request, Response, NextFunction } from 'express';
import { prisma } from '../database/client.js';
import { config } from '../config/index.js';
import { AppError } from '../utils/errors.js';

const router = Router();
const param = (p: string | string[]): string => (Array.isArray(p) ? p[0] : p);

// GET all AI providers with sanitized configuration (NO SECRETS EXPOSED)
router.get('/', async (_req: Request, res: Response, next: NextFunction) => {
  try {
    let providers = await prisma.aiProvider.findMany({
      orderBy: { name: 'asc' },
    });

    // If table is empty, seed defaults
    if (providers.length === 0) {
      await prisma.aiProvider.createMany({
        data: [
          {
            name: 'gemini',
            providerType: 'text',
            isDefault: true,
            isEnabled: !!config.GEMINI_API_KEY && config.GEMINI_API_KEY.length > 5,
            configJson: JSON.stringify({ model: config.GEMINI_MODEL, multimodal: true }),
          },
          {
            name: 'openai',
            providerType: 'text',
            isDefault: false,
            isEnabled: !!config.OPENAI_API_KEY && config.OPENAI_API_KEY.length > 5,
            configJson: JSON.stringify({ model: config.OPENAI_MODEL }),
          },
          {
            name: 'elevenlabs',
            providerType: 'tts',
            isDefault: false,
            isEnabled: !!config.ELEVENLABS_API_KEY && config.ELEVENLABS_API_KEY.length > 5,
            configJson: JSON.stringify({ voiceId: config.ELEVENLABS_VOICE_ID }),
          },
          {
            name: 'replicate',
            providerType: 'image',
            isDefault: false,
            isEnabled: !!config.REPLICATE_API_TOKEN && config.REPLICATE_API_TOKEN.length > 5,
            configJson: JSON.stringify({ model: 'sdxl-turbo' }),
          },
        ],
      });

      providers = await prisma.aiProvider.findMany({ orderBy: { name: 'asc' } });
    }

    // Sanitize configJson: strictly prevent any secret leakage
    const sanitized = providers.map((p) => {
      let cfg: Record<string, unknown> = {};
      try {
        cfg = JSON.parse(p.configJson);
      } catch {}
      delete cfg.apiKey;
      delete cfg.apiToken;
      delete cfg.secret;

      return {
        ...p,
        config: cfg,
        hasServerSideKey:
          p.name === 'gemini'
            ? !!config.GEMINI_API_KEY && config.GEMINI_API_KEY.length > 5
            : p.name === 'openai'
              ? !!config.OPENAI_API_KEY && config.OPENAI_API_KEY.length > 5
              : p.name === 'elevenlabs'
                ? !!config.ELEVENLABS_API_KEY && config.ELEVENLABS_API_KEY.length > 5
                : p.name === 'replicate'
                  ? !!config.REPLICATE_API_TOKEN && config.REPLICATE_API_TOKEN.length > 5
                  : false,
      };
    });

    res.json({ success: true, count: sanitized.length, data: sanitized });
  } catch (err) {
    next(err);
  }
});

// PATCH update provider (toggle enabled, set default)
router.patch('/:id', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const id = param(req.params.id);
    const { isEnabled, isDefault, configJson } = req.body;

    const provider = await prisma.aiProvider.findUnique({ where: { id } });
    if (!provider) {
      throw new AppError('Provider not found', 404, 'NOT_FOUND');
    }

    if (isDefault) {
      // Unset existing default for same providerType
      await prisma.aiProvider.updateMany({
        where: { providerType: provider.providerType, id: { not: id } },
        data: { isDefault: false },
      });
    }

    const updated = await prisma.aiProvider.update({
      where: { id },
      data: {
        isEnabled: isEnabled !== undefined ? isEnabled : provider.isEnabled,
        isDefault: isDefault !== undefined ? isDefault : provider.isDefault,
        configJson: configJson ? JSON.stringify(configJson) : provider.configJson,
      },
    });

    res.json({ success: true, data: updated });
  } catch (err) {
    next(err);
  }
});

export default router;

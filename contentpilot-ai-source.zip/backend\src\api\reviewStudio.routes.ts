import { Router, Request, Response, NextFunction } from 'express';
import { reviewStudioService } from '../services/approval/reviewStudioService.js';
import { VideoPipeStateType } from '../core/pipeline/stateTypes.js';
import { config } from '../config/index.js';

const router = Router();
const param = (p: string | string[]): string => (Array.isArray(p) ? p[0] : p);

// GET complete Review Studio bundle for a project
router.get('/review/:projectId', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const bundle = await reviewStudioService.getReviewBundle(param(req.params.projectId));
    res.json({ success: true, data: bundle });
  } catch (err) {
    next(err);
  }
});

// GET list of pending approvals
router.get('/pending', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const channelId = req.query.channelId as string | undefined;
    const pending = await reviewStudioService.listPendingApprovals(channelId);
    res.json({ success: true, count: pending.length, data: pending });
  } catch (err) {
    next(err);
  }
});

// POST action: APPROVE
router.post('/:projectId/approve', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { approvedBy, notes } = req.body;
    if (!approvedBy) {
      res.status(400).json({ success: false, error: 'Field "approvedBy" is required for explicit approval' });
      return;
    }
    await reviewStudioService.approve(param(req.params.projectId), approvedBy, notes);
    res.json({ success: true, message: 'Project explicitly approved' });
  } catch (err) {
    next(err);
  }
});

// POST action: REJECT
router.post('/:projectId/reject', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { reviewer, reason } = req.body;
    if (!reviewer || !reason) {
      res.status(400).json({ success: false, error: 'Fields "reviewer" and "reason" are required' });
      return;
    }
    await reviewStudioService.reject(param(req.params.projectId), reviewer, reason);
    res.json({ success: true, message: 'Project rejected' });
  } catch (err) {
    next(err);
  }
});

// POST action: EDIT
router.post('/:projectId/edit', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { edits, editor } = req.body;
    if (!editor || !edits) {
      res.status(400).json({ success: false, error: 'Fields "editor" and "edits" are required' });
      return;
    }
    await reviewStudioService.edit(param(req.params.projectId), edits, editor);
    res.json({ success: true, message: 'Metadata updated successfully' });
  } catch (err) {
    next(err);
  }
});

// POST action: REGENERATE
router.post('/:projectId/regenerate', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { stage, requestedBy } = req.body;
    if (!stage || !requestedBy) {
      res.status(400).json({ success: false, error: 'Fields "stage" and "requestedBy" are required' });
      return;
    }
    const jobId = await reviewStudioService.regenerate(param(req.params.projectId), stage, requestedBy);
    res.json({ success: true, message: `Stage '${stage}' queued for regeneration`, jobId });
  } catch (err) {
    next(err);
  }
});

// POST action: SEND BACK
router.post('/:projectId/send-back', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { targetStage, notes, reviewer } = req.body;
    if (!targetStage || !notes || !reviewer) {
      res.status(400).json({ success: false, error: 'Fields "targetStage", "notes", and "reviewer" are required' });
      return;
    }
    await reviewStudioService.sendBack(param(req.params.projectId), targetStage as VideoPipeStateType, notes, reviewer);
    res.json({ success: true, message: `Project sent back to '${targetStage}'` });
  } catch (err) {
    next(err);
  }
});

// POST action: SCHEDULE
router.post('/:projectId/schedule', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { scheduledPublishTime, privacyStatus, scheduledBy } = req.body;
    if (!scheduledPublishTime || !scheduledBy) {
      res.status(400).json({ success: false, error: 'Fields "scheduledPublishTime" and "scheduledBy" are required' });
      return;
    }
    await reviewStudioService.schedule(
      param(req.params.projectId),
      new Date(scheduledPublishTime),
      privacyStatus || config.DEFAULT_YOUTUBE_PRIVACY || 'public',
      scheduledBy
    );
    res.json({ success: true, message: 'Project scheduled for publishing' });
  } catch (err) {
    next(err);
  }
});

export default router;

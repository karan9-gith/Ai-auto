import React, { useEffect, useState } from 'react';
import { api } from '../services/api';
import { EmptyState } from '../components/EmptyState';
import { FlaskConical, Plus, Check, Award, ArrowRight } from 'lucide-react';

interface ExperimentsPageProps {
  channelId: string;
  onNavigate: (page: any) => void;
}

export const ExperimentsPage: React.FC<ExperimentsPageProps> = ({ channelId, onNavigate }) => {
  const [experiments, setExperiments] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [title, setTitle] = useState('');
  const [hypothesis, setHypothesis] = useState('');
  const [baseline, setBaseline] = useState('');
  const [variant, setVariant] = useState('');
  const [metric, setMetric] = useState('retention');
  const [experimentType, setExperimentType] = useState('titles');
  const [message, setMessage] = useState<string | null>(null);

  useEffect(() => {
    loadExperiments();
  }, [channelId]);

  const loadExperiments = async () => {
    try {
      setLoading(true);
      const data = await api.getExperiments(channelId);
      setExperiments(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await api.createExperiment({
        channelId,
        title,
        hypothesis,
        baseline,
        variant,
        metric,
        experimentType,
      });
      setShowModal(false);
      setTitle('');
      setHypothesis('');
      setBaseline('');
      setVariant('');
      setMessage('Experiment created.');
      await loadExperiments();
    } catch (err: any) {
      setMessage(`Create error: ${err.message}`);
    }
  };

  const handleApprove = async (id: string) => {
    try {
      await api.approveExperiment(id, 'supervising_editor@contentpilot.ai');
      setMessage('Experiment winner approved by human.');
      await loadExperiments();
    } catch (err: any) {
      setMessage(`Approval error: ${err.message}`);
    }
  };

  const handleApply = async (id: string) => {
    try {
      await api.applyExperiment(id);
      setMessage('Winner applied to channel configuration!');
      await loadExperiments();
    } catch (err: any) {
      setMessage(`Apply error: ${err.message}`);
    }
  };

  return (
    <div style={{ padding: '2rem' }}>
      <div className="page-header">
        <div>
          <h1 className="page-title">Hypothesis Experiments (A/B Testing)</h1>
          <p className="page-description">
            Scientific title, thumbnail, and format testing with mandatory human signoff before strategy changes.
          </p>
        </div>
        <button className="btn btn-primary" onClick={() => setShowModal(true)}>
          <Plus size={16} /> New Experiment
        </button>
      </div>

      {message && (
        <div className="badge badge-info" style={{ marginBottom: '1.25rem', padding: '8px 12px' }}>
          {message}
        </div>
      )}

      {loading ? (
        <p style={{ color: 'var(--text-muted)' }}>Loading experiments...</p>
      ) : experiments.length === 0 ? (
        <EmptyState
          title="No active experiments."
          message="Formulate a hypothesis for titles, thumbnails, or topics to run controlled variant evaluations."
          actionText="Create Experiment"
          onAction={() => setShowModal(true)}
        />
      ) : (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(360px, 1fr))', gap: '1.25rem' }}>
          {experiments.map((exp) => (
            <div key={exp.id} className="glass-card" style={{ padding: '1.5rem', display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}>
              <div>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '8px' }}>
                  <span className="badge badge-info">{exp.experimentType}</span>
                  <span className={`badge ${exp.status === 'concluded' ? 'badge-success' : 'badge-warning'}`}>
                    {exp.status}
                  </span>
                </div>

                <h3 style={{ fontSize: '1.1rem', fontWeight: 800, marginBottom: '6px' }}>{exp.title}</h3>
                <p style={{ fontSize: '0.85rem', color: 'var(--text-secondary)', marginBottom: '12px', fontStyle: 'italic' }}>
                  "{exp.hypothesis}"
                </p>

                <div style={{ background: 'var(--bg-surface-elevated)', borderRadius: '8px', padding: '10px', marginBottom: '1rem', fontSize: '0.825rem' }}>
                  <div><strong>Baseline (A):</strong> {exp.variantA}</div>
                  <div style={{ marginTop: '4px' }}><strong>Variant (B):</strong> {exp.variantB}</div>
                  <div style={{ marginTop: '6px', color: 'var(--text-muted)' }}>Primary Metric: {exp.metric}</div>
                </div>

                {exp.winnerVariant && (
                  <div style={{ display: 'flex', alignItems: 'center', gap: '6px', color: '#34d399', fontWeight: 700, fontSize: '0.85rem', marginBottom: '1rem' }}>
                    <Award size={16} /> Winner: Variant {exp.winnerVariant}
                  </div>
                )}
              </div>

              {/* Approval & Apply Actions */}
              <div style={{ borderTop: '1px solid var(--border-subtle)', paddingTop: '10px', display: 'flex', gap: '0.5rem' }}>
                {exp.status === 'concluded' && !exp.humanApproved && (
                  <button className="btn btn-primary" style={{ flex: 1, fontSize: '0.78rem' }} onClick={() => handleApprove(exp.id)}>
                    <Check size={14} /> Approve Winner
                  </button>
                )}
                {exp.humanApproved && (
                  <button className="btn btn-success" style={{ flex: 1, fontSize: '0.78rem' }} onClick={() => handleApply(exp.id)}>
                    Apply to Channel
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Creation Modal */}
      {showModal && (
        <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.7)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 100 }}>
          <div className="glass-panel" style={{ width: '500px', padding: '1.75rem', background: 'var(--bg-surface)' }}>
            <h3 style={{ fontSize: '1.2rem', fontWeight: 800, marginBottom: '1rem' }}>Create Controlled Experiment</h3>
            <form onSubmit={handleCreate} style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
              <div>
                <label style={{ fontSize: '0.8rem', color: 'var(--text-secondary)' }}>Experiment Title</label>
                <input className="input" value={title} onChange={(e) => setTitle(e.target.value)} required placeholder="e.g. Question Hook vs Provocative Hook" />
              </div>
              <div>
                <label style={{ fontSize: '0.8rem', color: 'var(--text-secondary)' }}>Hypothesis</label>
                <textarea className="textarea" style={{ minHeight: '70px' }} value={hypothesis} onChange={(e) => setHypothesis(e.target.value)} required placeholder="e.g. Provocative titles will yield a 15% increase in CTR among technical viewers..." />
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.75rem' }}>
                <div>
                  <label style={{ fontSize: '0.8rem', color: 'var(--text-secondary)' }}>Baseline (A)</label>
                  <input className="input" value={baseline} onChange={(e) => setBaseline(e.target.value)} required />
                </div>
                <div>
                  <label style={{ fontSize: '0.8rem', color: 'var(--text-secondary)' }}>Variant (B)</label>
                  <input className="input" value={variant} onChange={(e) => setVariant(e.target.value)} required />
                </div>
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.75rem' }}>
                <div>
                  <label style={{ fontSize: '0.8rem', color: 'var(--text-secondary)' }}>Type</label>
                  <select className="select" value={experimentType} onChange={(e) => setExperimentType(e.target.value)}>
                    <option value="titles">Titles</option>
                    <option value="thumbnails">Thumbnails</option>
                    <option value="topics">Topics</option>
                    <option value="formats">Formats</option>
                    <option value="publish_timing">Publish Timing</option>
                  </select>
                </div>
                <div>
                  <label style={{ fontSize: '0.8rem', color: 'var(--text-secondary)' }}>Target Metric</label>
                  <input className="input" value={metric} onChange={(e) => setMetric(e.target.value)} required />
                </div>
              </div>
              <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '0.75rem', marginTop: '0.5rem' }}>
                <button type="button" className="btn btn-secondary" onClick={() => setShowModal(false)}>Cancel</button>
                <button type="submit" className="btn btn-primary">Start Experiment</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

import { prisma } from '../../database/client.js';
import { logger } from '../../utils/logger.js';
import { config } from '../../config/index.js';
import { persistentJobQueue } from '../../jobs/jobQueue.js';
import { youtubeUploadEngine } from '../youtube/youtubeUploadEngine.js';
import { preUploadSafetyChecker } from '../youtube/preUploadSafetyCheck.js';
import {
  CreateScheduledTaskInput,
  ScheduledTaskType,
  ScheduleType,
  SchedulerConfig,
} from './types.js';

export class PersistentScheduler {
  private isRunning = false;
  private timer: NodeJS.Timeout | null = null;
  private pollIntervalMs = 10000; // 10s tick

  /**
   * Start persistent scheduler loop and run crash recovery
   */
  public async start(): Promise<void> {
    if (this.isRunning) return;
    this.isRunning = true;

    logger.info({ msg: 'Starting Persistent Scheduler' });

    // Catch up / initialize nextRunAt for all active tasks
    await this.recoverAndInitializeTasks();

    this.scheduleNextTick();
  }

  /**
   * Stop scheduler loop
   */
  public async stop(): Promise<void> {
    this.isRunning = false;
    if (this.timer) {
      clearTimeout(this.timer);
      this.timer = null;
    }
    logger.info({ msg: 'Persistent Scheduler stopped' });
  }

  public getIsRunning(): boolean {
    return this.isRunning;
  }

  /**
   * Create or register a persistent scheduled task
   */
  public async createTask(input: CreateScheduledTaskInput): Promise<string> {
    const nextRun = input.nextRunAt || this.calculateNextRun(input.scheduleType, input.intervalMs, input.preferredTime);

    const task = await prisma.scheduledTask.create({
      data: {
        channelId: input.channelId,
        name: input.name,
        taskType: input.taskType,
        scheduleType: input.scheduleType,
        intervalMs: input.intervalMs,
        preferredTime: input.preferredTime || '14:00',
        timezone: input.timezone || 'UTC',
        configJson: JSON.stringify(input.config || {}),
        status: 'ACTIVE',
        nextRunAt: nextRun,
      },
    });

    logger.info({
      msg: 'Scheduled task created',
      taskId: task.id,
      name: task.name,
      nextRunAt: nextRun.toISOString(),
    });

    return task.id;
  }

  /**
   * Execute immediate tick to evaluate pending tasks
   */
  public async tick(): Promise<number> {
    const now = new Date();
    const tasksDue = await prisma.scheduledTask.findMany({
      where: {
        status: 'ACTIVE',
        nextRunAt: { lte: now },
      },
    });

    if (tasksDue.length === 0) {
      // Also check if any scheduled publishing items in PublishingQueue are due
      await this.processScheduledPublishingQueue(now);
      return 0;
    }

    logger.info({ msg: `Processing ${tasksDue.length} scheduled tasks due for execution` });

    for (const task of tasksDue) {
      try {
        await this.executeTask(task);

        // Update run metadata and calculate next execution
        const lastRunAt = new Date();
        const nextRunAt =
          task.scheduleType === 'one_time'
            ? null
            : this.calculateNextRun(task.scheduleType as ScheduleType, task.intervalMs || undefined, task.preferredTime || undefined);

        await prisma.scheduledTask.update({
          where: { id: task.id },
          data: {
            lastRunAt,
            nextRunAt,
            runCount: { increment: 1 },
            status: task.scheduleType === 'one_time' ? 'COMPLETED' : 'ACTIVE',
          },
        });
      } catch (err) {
        logger.error({ msg: 'Failed to execute scheduled task', taskId: task.id, error: err });
      }
    }

    // Process publishing queue
    await this.processScheduledPublishingQueue(now);

    return tasksDue.length;
  }

  /**
   * Execute individual scheduled task by type
   */
  private async executeTask(task: {
    id: string;
    channelId: string | null;
    taskType: string;
    configJson: string;
  }): Promise<void> {
    const taskConfig = JSON.parse(task.configJson || '{}');
    const channelId = task.channelId;

    logger.info({ msg: 'Executing scheduled task', taskId: task.id, taskType: task.taskType });

    switch (task.taskType as ScheduledTaskType) {
      case 'research':
        if (channelId) {
          await persistentJobQueue.createJob({
            type: 'research',
            payload: { channelId, source: 'scheduler' },
          });
        }
        break;

      case 'content_generation':
        if (channelId) {
          await persistentJobQueue.createJob({
            type: 'pipeline',
            payload: { channelId, source: 'scheduler' },
          });
        }
        break;

      case 'rendering':
        if (channelId) {
          await persistentJobQueue.createJob({
            type: 'render',
            payload: { channelId, source: 'scheduler' },
          });
        }
        break;

      case 'approval_reminders': {
        const pending = await prisma.videoProject.count({
          where: {
            ...(channelId && { channelId }),
            status: 'AWAITING_APPROVAL',
          },
        });

        if (pending > 0) {
          logger.info({
            msg: `Approval reminder: ${pending} video project(s) waiting for human approval`,
            channelId,
          });
          await prisma.systemLog.create({
            data: {
              level: 'info',
              category: 'pipeline',
              message: `Approval reminder: ${pending} video(s) awaiting editorial review`,
              metaJson: JSON.stringify({ pendingCount: pending, channelId }),
              timestamp: new Date(),
            },
          });
        }
        break;
      }

      case 'publishing':
        await this.processScheduledPublishingQueue(new Date(), channelId || undefined);
        break;

      case 'analytics':
        if (channelId) {
          await persistentJobQueue.createJob({
            type: 'analytics',
            payload: { channelId, source: 'scheduler' },
          });
        }
        break;

      case 'learning':
        if (channelId) {
          await persistentJobQueue.createJob({
            type: 'learning',
            payload: { channelId, source: 'scheduler' },
          });
        }
        break;

      default:
        logger.warn({ msg: `Unknown scheduled task type: ${task.taskType}` });
    }
  }

  /**
   * Process publishing queue for items whose scheduledPublishTime <= now
   * NEVER PUBLISHES UNAPPROVED CONTENT!
   */
  public async processScheduledPublishingQueue(now: Date, channelIdFilter?: string): Promise<number> {
    const queueItems = await prisma.publishingQueue.findMany({
      where: {
        status: 'QUEUED',
        scheduledPublishTime: { lte: now },
        ...(channelIdFilter && { channelId: channelIdFilter }),
      },
      include: {
        project: {
          include: {
            approvalRequests: { orderBy: { createdAt: 'desc' }, take: 1 },
          },
        },
      },
    });

    let publishedCount = 0;

    for (const item of queueItems) {
      try {
        // STRICT SAFETY CHECK: MUST BE EXPLICITLY APPROVED
        const latestApproval = item.project.approvalRequests[0];
        if (!latestApproval || latestApproval.status !== 'APPROVED') {
          logger.warn({
            msg: 'BLOCKED: Scheduled video skipped because human approval is missing or not APPROVED',
            projectId: item.projectId,
            approvalStatus: latestApproval?.status || 'NONE',
          });

          await prisma.systemLog.create({
            data: {
              level: 'warn',
              category: 'pipeline',
              message: `Scheduled publish skipped for project ${item.projectId}: Unapproved content`,
              timestamp: new Date(),
            },
          });
          continue;
        }

        // Run Pre-Upload Safety Check
        await preUploadSafetyChecker.verify(item.projectId);

        logger.info({
          msg: 'Executing scheduled publishing upload',
          projectId: item.projectId,
          channelId: item.channelId,
        });

        await youtubeUploadEngine.upload({
          projectId: item.projectId,
          channelId: item.channelId,
          privacyStatus: (item.privacyStatus as 'private' | 'unlisted' | 'public') || config.DEFAULT_YOUTUBE_PRIVACY || 'public',
          idempotencyKey: item.idempotencyKey,
        });

        publishedCount++;
      } catch (uploadErr) {
        logger.error({
          msg: 'Scheduled upload failed',
          projectId: item.projectId,
          error: uploadErr,
        });
      }
    }

    return publishedCount;
  }

  /**
   * Compute next run date based on recurrence pattern
   */
  public calculateNextRun(scheduleType: ScheduleType, intervalMs?: number, preferredTime = '14:00'): Date {
    const now = new Date();

    if (scheduleType === 'custom_interval') {
      return new Date(now.getTime() + (intervalMs || 3600000));
    }

    const [prefHour, prefMin] = preferredTime.split(':').map((s) => parseInt(s, 10));
    const target = new Date(now);
    target.setUTCHours(isNaN(prefHour) ? 14 : prefHour, isNaN(prefMin) ? 0 : prefMin, 0, 0);

    if (scheduleType === 'daily') {
      if (target.getTime() <= now.getTime()) {
        target.setUTCDate(target.getUTCDate() + 1);
      }
      return target;
    }

    if (scheduleType === 'weekly') {
      if (target.getTime() <= now.getTime()) {
        target.setUTCDate(target.getUTCDate() + 7);
      }
      return target;
    }

    // Default 1 hour from now for one_time fallback
    return new Date(now.getTime() + 3600000);
  }

  /**
   * On startup, recover tasks from SQLite database
   */
  private async recoverAndInitializeTasks(): Promise<void> {
    const activeTasks = await prisma.scheduledTask.findMany({
      where: { status: 'ACTIVE' },
    });

    const now = new Date();
    for (const task of activeTasks) {
      if (!task.nextRunAt) {
        const next = this.calculateNextRun(
          task.scheduleType as ScheduleType,
          task.intervalMs || undefined,
          task.preferredTime || undefined
        );
        await prisma.scheduledTask.update({
          where: { id: task.id },
          data: { nextRunAt: next },
        });
      } else if (task.nextRunAt.getTime() < now.getTime() - 24 * 3600 * 1000) {
        // More than a day overdue: recalculate to next valid slot to avoid runaway storms
        const next = this.calculateNextRun(
          task.scheduleType as ScheduleType,
          task.intervalMs || undefined,
          task.preferredTime || undefined
        );
        await prisma.scheduledTask.update({
          where: { id: task.id },
          data: { nextRunAt: next },
        });
      }
    }

    logger.info({ msg: `Recovered and verified ${activeTasks.length} persistent scheduled tasks on startup` });
  }

  private scheduleNextTick(): void {
    if (!this.isRunning) return;
    this.timer = setTimeout(async () => {
      try {
        await this.tick();
      } catch (err) {
        logger.error({ msg: 'Scheduler tick error', error: err });
      }
      this.scheduleNextTick();
    }, this.pollIntervalMs);
  }
}

export const persistentScheduler = new PersistentScheduler();

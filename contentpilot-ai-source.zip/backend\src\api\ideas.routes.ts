import { Router, Request, Response, NextFunction } from 'express';
import { prisma } from '../database/client.js';
import { AppError } from '../utils/errors.js';

const router = Router();
const param = (p: string | string[]): string => (Array.isArray(p) ? p[0] : p);

// GET all content ideas
router.get('/', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const channelId = req.query.channelId as string | undefined;
    const status = req.query.status as string | undefined;

    const ideas = await prisma.contentIdea.findMany({
      where: {
        ...(channelId ? { channelId } : {}),
        ...(status ? { status } : {}),
      },
      include: {
        researchRun: { select: { niche: true, createdAt: true } },
      },
      orderBy: [{ trendScore: 'desc' }, { createdAt: 'desc' }],
      take: 100,
    });

    res.json({ success: true, count: ideas.length, data: ideas });
  } catch (err) {
    next(err);
  }
});

// POST create custom content idea
router.post('/', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const {
      channelId,
      topic,
      angle,
      targetAudience,
      trendScore,
      searchIntent,
      competitionScore,
      noveltyScore,
      evergreenScore,
      riskScore,
      recommendedFormat,
      evidenceSummary,
    } = req.body;

    if (!channelId || !topic || !angle) {
      res.status(400).json({ success: false, error: 'Fields "channelId", "topic", and "angle" are required' });
      return;
    }

    const idea = await prisma.contentIdea.create({
      data: {
        channelId,
        topic,
        angle,
        targetAudience: targetAudience || 'General Audience',
        trendScore: trendScore ?? 75.0,
        searchIntent: searchIntent || 'informational',
        competitionScore: competitionScore ?? 50.0,
        noveltyScore: noveltyScore ?? 70.0,
        evergreenScore: evergreenScore ?? 60.0,
        riskScore: riskScore ?? 10.0,
        recommendedFormat: recommendedFormat || 'long_form',
        evidenceSummary: evidenceSummary || 'Curated editorial idea',
        status: 'backlog',
      },
    });

    res.json({ success: true, data: idea });
  } catch (err) {
    next(err);
  }
});

// PATCH update idea status (backlog, selected, discarded, planned)
router.patch('/:id/status', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const id = param(req.params.id);
    const { status } = req.body;

    if (!['backlog', 'selected', 'discarded', 'planned'].includes(status)) {
      res.status(400).json({ success: false, error: 'Invalid status value' });
      return;
    }

    const idea = await prisma.contentIdea.update({
      where: { id },
      data: { status },
    });

    res.json({ success: true, data: idea });
  } catch (err) {
    next(err);
  }
});

export default router;

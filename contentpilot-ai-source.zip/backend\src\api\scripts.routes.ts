import { Router, Request, Response, NextFunction } from 'express';
import { prisma } from '../database/client.js';
import { defaultAiProvider } from '../services/ai/defaultAIProvider.js';
import { AppError } from '../utils/errors.js';

const router = Router();
const param = (p: string | string[]): string => (Array.isArray(p) ? p[0] : p);

// GET all scripts
router.get('/', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const channelId = req.query.channelId as string | undefined;
    const scripts = await prisma.script.findMany({
      where: channelId ? { channelId } : undefined,
      include: {
        strategy: { select: { titleConcept: true, format: true } },
        versions: { select: { versionNumber: true, createdAt: true, editedBy: true } },
      },
      orderBy: { updatedAt: 'desc' },
      take: 50,
    });
    res.json({ success: true, count: scripts.length, data: scripts });
  } catch (err) {
    next(err);
  }
});

// GET single script with sections and versions
router.get('/:id', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const script = await prisma.script.findUnique({
      where: { id: param(req.params.id) },
      include: {
        strategy: true,
        versions: { orderBy: { versionNumber: 'desc' } },
        seoPackages: true,
        thumbnails: true,
      },
    });

    if (!script) {
      throw new AppError('Script not found', 404, 'SCRIPT_NOT_FOUND');
    }

    res.json({ success: true, data: script });
  } catch (err) {
    next(err);
  }
});

// POST generate script from strategy
router.post('/generate', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { strategyId, channelId } = req.body;
    if (!strategyId || !channelId) {
      res.status(400).json({ success: false, error: 'Fields "strategyId" and "channelId" are required' });
      return;
    }

    const [strategy, channel] = await Promise.all([
      prisma.contentStrategy.findUnique({ where: { id: strategyId } }),
      prisma.channel.findUnique({ where: { id: channelId }, include: { settings: true } }),
    ]);

    if (!strategy || !channel) {
      throw new AppError('Strategy or Channel not found', 404, 'NOT_FOUND');
    }

    const scriptOutput = await defaultAiProvider.generateScript({
      strategy: {
        titleConcept: strategy.titleConcept,
        hook: strategy.hook,
        angle: strategy.angle,
        audience: strategy.targetAudience,
        contentPillar: 'Main',
        format: strategy.format,
        estimatedDurationSec: strategy.estimatedDurationSec,
        primaryKeyword: strategy.primaryKeyword,
        secondaryKeywords: JSON.parse(strategy.secondaryKeywords || '[]'),
        cta: strategy.cta,
        thumbnailConcept: strategy.thumbnailConcept,
        expectedKpi: strategy.expectedKpi,
        priority: strategy.priority,
        risk: strategy.risk,
        reasonForSelection: strategy.reasonForSelection,
      },
      brandVoice: channel.brandVoice,
      targetDurationSec: channel.settings?.targetDurationSec || 480,
    });

    const script = await prisma.script.create({
      data: {
        strategyId: strategy.id,
        channelId,
        title: scriptOutput.title,
        hookText: scriptOutput.hook.text,
        hookVisualCue: scriptOutput.hook.visualCue,
        hookDurationSec: scriptOutput.hook.durationSec,
        sectionsJson: JSON.stringify(scriptOutput.sections),
        ctaText: scriptOutput.cta.text,
        ctaVisualCue: scriptOutput.cta.visualCue,
        outroText: scriptOutput.outro.text,
        outroVisualCue: scriptOutput.outro.visualCue,
        estimatedDurationSec: scriptOutput.estimatedDurationSec,
        wordCount: scriptOutput.wordCount,
        status: 'approved',
        currentVersion: 1,
      },
    });

    await prisma.scriptVersion.create({
      data: {
        scriptId: script.id,
        versionNumber: 1,
        title: script.title,
        hookJson: JSON.stringify(scriptOutput.hook),
        sectionsJson: JSON.stringify(scriptOutput.sections),
        ctaJson: JSON.stringify(scriptOutput.cta),
        outroJson: JSON.stringify(scriptOutput.outro),
        estimatedDurationSec: scriptOutput.estimatedDurationSec,
        wordCount: scriptOutput.wordCount,
        claimsJson: JSON.stringify(scriptOutput.claims),
        editedBy: 'ai',
      },
    });

    res.json({ success: true, data: script });
  } catch (err) {
    next(err);
  }
});

// PUT update script content (creates a new version)
router.put('/:id', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const id = param(req.params.id);
    const { title, hookText, hookVisualCue, sections, ctaText, outroText, editedBy, changeSummary } = req.body;

    const existing = await prisma.script.findUnique({
      where: { id },
      include: { versions: { orderBy: { versionNumber: 'desc' }, take: 1 } },
    });

    if (!existing) {
      throw new AppError('Script not found', 404, 'SCRIPT_NOT_FOUND');
    }

    const nextVersion = (existing.currentVersion || 1) + 1;
    const wordCount = (sections ? JSON.stringify(sections).split(/\s+/).length : existing.wordCount) || 100;

    const updated = await prisma.script.update({
      where: { id },
      data: {
        title: title || existing.title,
        hookText: hookText !== undefined ? hookText : existing.hookText,
        hookVisualCue: hookVisualCue !== undefined ? hookVisualCue : existing.hookVisualCue,
        sectionsJson: sections ? JSON.stringify(sections) : existing.sectionsJson,
        ctaText: ctaText !== undefined ? ctaText : existing.ctaText,
        outroText: outroText !== undefined ? outroText : existing.outroText,
        wordCount,
        currentVersion: nextVersion,
      },
    });

    await prisma.scriptVersion.create({
      data: {
        scriptId: id,
        versionNumber: nextVersion,
        title: updated.title,
        hookJson: JSON.stringify({ text: updated.hookText, visualCue: updated.hookVisualCue, durationSec: updated.hookDurationSec }),
        sectionsJson: updated.sectionsJson,
        ctaJson: JSON.stringify({ text: updated.ctaText, visualCue: updated.ctaVisualCue }),
        outroJson: JSON.stringify({ text: updated.outroText, visualCue: updated.outroVisualCue }),
        estimatedDurationSec: updated.estimatedDurationSec,
        wordCount,
        claimsJson: '[]',
        changeSummary: changeSummary || 'Manual editorial revision',
        editedBy: editedBy || 'user',
      },
    });

    res.json({ success: true, data: updated, version: nextVersion });
  } catch (err) {
    next(err);
  }
});

export default router;

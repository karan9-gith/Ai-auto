import React, { useEffect, useState } from 'react';
import { api } from '../services/api';
import { EmptyState } from '../components/EmptyState';
import { Target, Sparkles, Clock, Eye, Film, ArrowRight } from 'lucide-react';

interface StrategyPageProps {
  channelId: string;
  onNavigate: (page: any) => void;
}

export const StrategyPage: React.FC<StrategyPageProps> = ({ channelId, onNavigate }) => {
  const [strategies, setStrategies] = useState<any[]>([]);
  const [selectedStrategy, setSelectedStrategy] = useState<any | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadStrategies();
  }, [channelId]);

  const loadStrategies = async () => {
    try {
      setLoading(true);
      const data = await api.getStrategies(channelId);
      setStrategies(data);
      if (data.length > 0) {
        setSelectedStrategy(data[0]);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{ padding: '2rem' }}>
      <div className="page-header">
        <div>
          <h1 className="page-title">Content Strategy Blueprint</h1>
          <p className="page-description">
            Algorithmic hook positioning, target audience retention strategy, and thumbnail alignment.
          </p>
        </div>
      </div>

      {loading ? (
        <p style={{ color: 'var(--text-muted)' }}>Loading strategies...</p>
      ) : strategies.length === 0 ? (
        <EmptyState
          title="No content strategies found."
          message="Initiate the Autonomous Operator or select ideas from research to automatically architect content strategies."
          actionText="Open Autonomous Operator"
          onAction={() => onNavigate('operator')}
        />
      ) : (
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 2fr', gap: '1.5rem' }}>
          {/* List column */}
          <div className="glass-panel" style={{ padding: '1rem', maxHeight: '75vh', overflowY: 'auto' }}>
            <h3 style={{ fontSize: '0.85rem', color: 'var(--text-secondary)', marginBottom: '0.75rem', textTransform: 'uppercase' }}>
              Formulated Strategies ({strategies.length})
            </h3>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
              {strategies.map((s) => {
                const isSelected = selectedStrategy?.id === s.id;
                return (
                  <div
                    key={s.id}
                    onClick={() => setSelectedStrategy(s)}
                    style={{
                      padding: '0.85rem',
                      borderRadius: '8px',
                      background: isSelected ? 'rgba(59, 130, 246, 0.15)' : 'var(--bg-surface-elevated)',
                      border: `1px solid ${isSelected ? '#3b82f6' : 'var(--border-subtle)'}`,
                      cursor: 'pointer',
                    }}
                  >
                    <div style={{ fontWeight: 700, fontSize: '0.9rem' }}>{s.titleConcept}</div>
                    <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', marginTop: '4px' }}>
                      Format: {s.format} • {Math.round(s.estimatedDurationSec / 60)} mins
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Strategy Deep Dive Pane */}
          {selectedStrategy && (
            <div className="glass-panel" style={{ padding: '1.75rem' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '1.25rem' }}>
                <div>
                  <span className="badge badge-info" style={{ marginBottom: '6px' }}>{selectedStrategy.format}</span>
                  <h2 style={{ fontSize: '1.35rem', fontWeight: 800 }}>{selectedStrategy.titleConcept}</h2>
                </div>
                <span className="badge badge-success">Target KPI: {selectedStrategy.expectedKpi}</span>
              </div>

              {/* Grid of Strategy Elements */}
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem', marginBottom: '1.5rem' }}>
                <div className="glass-card" style={{ padding: '1rem' }}>
                  <div style={{ fontSize: '0.75rem', color: 'var(--text-secondary)', fontWeight: 600 }}>FIRST 10 SECONDS HOOK</div>
                  <div style={{ fontSize: '0.9rem', marginTop: '6px', fontStyle: 'italic', color: '#60a5fa' }}>
                    "{selectedStrategy.hook}"
                  </div>
                </div>

                <div className="glass-card" style={{ padding: '1rem' }}>
                  <div style={{ fontSize: '0.75rem', color: 'var(--text-secondary)', fontWeight: 600 }}>THUMBNAIL CONCEPT</div>
                  <div style={{ fontSize: '0.875rem', marginTop: '6px' }}>
                    {selectedStrategy.thumbnailConcept}
                  </div>
                </div>

                <div className="glass-card" style={{ padding: '1rem' }}>
                  <div style={{ fontSize: '0.75rem', color: 'var(--text-secondary)', fontWeight: 600 }}>PRIMARY KEYWORD</div>
                  <div style={{ fontSize: '0.95rem', fontWeight: 700, marginTop: '4px', color: '#34d399' }}>
                    {selectedStrategy.primaryKeyword}
                  </div>
                </div>

                <div className="glass-card" style={{ padding: '1rem' }}>
                  <div style={{ fontSize: '0.75rem', color: 'var(--text-secondary)', fontWeight: 600 }}>AUDIENCE TARGET</div>
                  <div style={{ fontSize: '0.875rem', marginTop: '4px' }}>
                    {selectedStrategy.targetAudience}
                  </div>
                </div>
              </div>

              {/* Angle & Reason for Selection */}
              <div style={{ background: 'var(--bg-surface-elevated)', padding: '1rem', borderRadius: '8px', marginBottom: '1.5rem' }}>
                <div style={{ fontSize: '0.75rem', color: 'var(--text-secondary)', fontWeight: 600, marginBottom: '4px' }}>
                  REASON FOR SELECTION & COMPETITIVE EDGE
                </div>
                <div style={{ fontSize: '0.875rem', lineHeight: 1.5 }}>
                  {selectedStrategy.reasonForSelection}
                </div>
              </div>

              <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
                <button className="btn btn-primary" onClick={() => onNavigate('scripts')}>
                  Proceed to Scripting <ArrowRight size={14} />
                </button>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

import { Router, Request, Response, NextFunction } from 'express';
import { prisma } from '../database/client.js';
import { AppError } from '../utils/errors.js';
import { storageManager } from '../storage/storageManager.js';
import { pipelineStateMachine } from '../core/pipeline/stateMachine.js';
import { VideoPipelineState } from '../core/pipeline/stateTypes.js';
import { persistentJobQueue } from '../jobs/jobQueue.js';

const router = Router();
const param = (p: string | string[]): string => (Array.isArray(p) ? p[0] : p);

// GET list all video projects
router.get('/projects', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const channelId = req.query.channelId as string | undefined;
    const projects = await prisma.videoProject.findMany({
      where: channelId ? { channelId } : undefined,
      include: {
        scenes: { orderBy: { sceneIndex: 'asc' } },
        narration: true,
        renders: { orderBy: { createdAt: 'desc' }, take: 1 },
        qualityChecks: { orderBy: { createdAt: 'desc' }, take: 1 },
        seoPackage: { select: { recommendedTitle: true } },
      },
      orderBy: { updatedAt: 'desc' },
      take: 50,
    });
    res.json({ success: true, count: projects.length, data: projects });
  } catch (err) {
    next(err);
  }
});

// GET detailed video project by ID
router.get('/projects/:id', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const projectId = param(req.params.id);
    const project = await prisma.videoProject.findUnique({
      where: { id: projectId },
      include: {
        channel: true,
        script: { include: { strategy: true, versions: true } },
        narration: true,
        seoPackage: true,
        thumbnail: { include: { variants: true } },
        scenes: {
          orderBy: { sceneIndex: 'asc' },
          include: { visualAsset: true },
        },
        renders: { orderBy: { createdAt: 'desc' } },
        qualityChecks: { orderBy: { createdAt: 'desc' } },
        rightsChecks: { orderBy: { createdAt: 'desc' } },
        approvalRequests: { orderBy: { createdAt: 'desc' } },
        publishingQueue: true,
      },
    });

    if (!project) {
      throw new AppError(`Project ${projectId} not found`, 404, 'PROJECT_NOT_FOUND');
    }

    // Check if master render file exists on disk
    let fileVerified = false;
    let fileSize = 0;
    const latestRender = project.renders[0];
    if (latestRender?.outputPath) {
      fileVerified = await storageManager.validateFileExistsAndNonEmpty(latestRender.outputPath);
      fileSize = latestRender.fileSize;
    }

    res.json({
      success: true,
      data: {
        ...project,
        fileVerification: {
          verified: fileVerified,
          fileSize,
          outputPath: latestRender?.outputPath || null,
        },
      },
    });
  } catch (err) {
    next(err);
  }
});

// POST trigger render or re-render for project
router.post('/projects/:id/render', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const projectId = param(req.params.id);
    const project = await prisma.videoProject.findUnique({
      where: { id: projectId },
      include: { narration: true, scenes: true },
    });

    if (!project) {
      throw new AppError(`Project ${projectId} not found`, 404, 'PROJECT_NOT_FOUND');
    }

    if (!project.narration) {
      throw new AppError('Cannot render: Narration is not ready yet', 400, 'NARRATION_MISSING');
    }

    // Queue persistent render job
    const jobId = await persistentJobQueue.createJob({
      type: 'render',
      payload: { projectId, resolution: project.resolution, targetFps: project.targetFps },
    });

    res.json({
      success: true,
      message: 'Render job safely queued',
      jobId,
    });
  } catch (err) {
    next(err);
  }
});

// POST safely regenerate a single scene
router.post('/projects/:id/regenerate-scene', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const projectId = param(req.params.id);
    const { sceneIndex, visualDescription } = req.body;

    if (sceneIndex === undefined) {
      res.status(400).json({ success: false, error: 'sceneIndex is required' });
      return;
    }

    const scene = await prisma.videoScene.findUnique({
      where: { projectId_sceneIndex: { projectId, sceneIndex: Number(sceneIndex) } },
    });

    if (!scene) {
      throw new AppError(`Scene #${sceneIndex} not found in project ${projectId}`, 404, 'SCENE_NOT_FOUND');
    }

    // Update scene status to regenerating
    const updated = await prisma.videoScene.update({
      where: { id: scene.id },
      data: {
        status: 'regenerating',
        visualDescription: visualDescription || scene.visualDescription,
      },
    });

    // Enqueue visual generation job for scene
    const jobId = await persistentJobQueue.createJob({
      type: 'visual',
      payload: {
        projectId,
        sceneId: scene.id,
        sceneIndex: Number(sceneIndex),
        description: visualDescription || scene.visualDescription,
      },
    });

    res.json({
      success: true,
      message: `Scene #${sceneIndex} queued for regeneration`,
      jobId,
      scene: updated,
    });
  } catch (err) {
    next(err);
  }
});

export default router;

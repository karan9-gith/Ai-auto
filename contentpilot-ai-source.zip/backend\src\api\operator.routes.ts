import { Router, Request, Response, NextFunction } from 'express';
import { autonomousOperator } from '../services/operator/autonomousOperator.js';
import { prisma } from '../database/client.js';
import { pipelineStateMachine } from '../core/pipeline/stateMachine.js';
import { VideoPipelineState } from '../core/pipeline/stateTypes.js';

const router = Router();
const param = (p: string | string[]): string => (Array.isArray(p) ? p[0] : p);

// Active operator state map for pause/cancel tracking in memory
const activeOperators = new Map<string, { status: 'running' | 'paused' | 'cancelled'; projectId: string }>();

// GET operator status for channel or overall
router.get('/status', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const channelId = req.query.channelId as string | undefined;

    // Find the most recent project in pipeline
    const project = await prisma.videoProject.findFirst({
      where: channelId ? { channelId } : undefined,
      orderBy: { updatedAt: 'desc' },
      include: {
        approvalRequests: { orderBy: { createdAt: 'desc' }, take: 1 },
        qualityChecks: { orderBy: { createdAt: 'desc' }, take: 1 },
        renders: { orderBy: { createdAt: 'desc' }, take: 1 },
        youtubeVideos: { take: 1 },
      },
    });

    if (!project) {
      res.json({
        success: true,
        data: {
          hasActivePipeline: false,
          status: 'IDLE',
          message: 'No pipeline has been executed yet.',
        },
      });
      return;
    }

    const stateLogs = await prisma.pipelineStateLog.findMany({
      where: { projectId: project.id },
      orderBy: { timestamp: 'desc' },
      take: 20,
    });

    const autoFixLogs = await prisma.autoFixLog.findMany({
      where: { projectId: project.id },
      orderBy: { timestamp: 'desc' },
      take: 10,
    });

    const isAwaitingApproval =
      project.status === VideoPipelineState.AWAITING_APPROVAL ||
      (project.approvalRequests[0] && project.approvalRequests[0].status === 'WAITING_APPROVAL');

    res.json({
      success: true,
      data: {
        hasActivePipeline: true,
        project: {
          id: project.id,
          title: project.title,
          status: project.status,
          currentStage: project.currentStage,
          format: project.format,
          updatedAt: project.updatedAt,
        },
        isAwaitingApproval,
        approvalRequest: project.approvalRequests[0] || null,
        qualityCheck: project.qualityChecks[0] || null,
        render: project.renders[0] || null,
        youtubeVideo: project.youtubeVideos[0] || null,
        stateLogs,
        autoFixLogs,
        runtimeControlStatus: activeOperators.get(project.id)?.status || 'idle',
      },
    });
  } catch (err) {
    next(err);
  }
});

// POST run autonomous operator cycle
router.post('/run', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const {
      channelId,
      channelObjective,
      targetAudience,
      contentPillars,
      language,
      brandVoice,
      publishingCadence,
      successMetrics,
      blockedTopics,
      maximumVideoDurationSec,
      existingProjectId,
    } = req.body;

    if (!channelId) {
      res.status(400).json({ success: false, error: 'Field "channelId" is required' });
      return;
    }

    const result = await autonomousOperator.run({
      channelId,
      channelObjective,
      targetAudience,
      contentPillars,
      language,
      brandVoice,
      publishingCadence,
      successMetrics,
      blockedTopics,
      maximumVideoDurationSec,
      existingProjectId,
    });

    if (result.projectId) {
      activeOperators.set(result.projectId, { status: 'running', projectId: result.projectId });
    }

    res.json({ success: true, result });
  } catch (err) {
    next(err);
  }
});

// POST pause autonomous operator
router.post('/pause', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { projectId } = req.body;
    if (!projectId) {
      res.status(400).json({ success: false, error: 'Field "projectId" is required' });
      return;
    }

    activeOperators.set(projectId, { status: 'paused', projectId });
    res.json({ success: true, message: 'Operator cycle paused safely at current checkpoint' });
  } catch (err) {
    next(err);
  }
});

// POST resume autonomous operator
router.post('/resume', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { projectId, channelId } = req.body;
    if (!projectId || !channelId) {
      res.status(400).json({ success: false, error: 'Fields "projectId" and "channelId" are required' });
      return;
    }

    activeOperators.set(projectId, { status: 'running', projectId });
    const result = await autonomousOperator.run({
      channelId,
      existingProjectId: projectId,
    });

    res.json({ success: true, result, message: 'Operator resumed from last valid state' });
  } catch (err) {
    next(err);
  }
});

// POST cancel autonomous operator
router.post('/cancel', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { projectId } = req.body;
    if (!projectId) {
      res.status(400).json({ success: false, error: 'Field "projectId" is required' });
      return;
    }

    activeOperators.set(projectId, { status: 'cancelled', projectId });
    await prisma.videoProject.update({
      where: { id: projectId },
      data: { status: 'CANCELLED', currentStage: 'cancelled' },
    });

    res.json({ success: true, message: 'Operator pipeline cancelled' });
  } catch (err) {
    next(err);
  }
});

// GET state history and auto-fix recovery logs for project
router.get('/logs/:projectId', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const projectId = param(req.params.projectId);
    const [stateLogs, autoFixLogs] = await Promise.all([
      prisma.pipelineStateLog.findMany({
        where: { projectId },
        orderBy: { timestamp: 'desc' },
      }),
      prisma.autoFixLog.findMany({
        where: { projectId },
        orderBy: { timestamp: 'desc' },
      }),
    ]);

    res.json({ success: true, data: { stateLogs, autoFixLogs } });
  } catch (err) {
    next(err);
  }
});

export default router;

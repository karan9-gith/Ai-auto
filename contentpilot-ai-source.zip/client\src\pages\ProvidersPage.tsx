import React, { useEffect, useState } from 'react';
import { api } from '../services/api';
import { EmptyState } from '../components/EmptyState';
import { Cpu, CheckCircle2, ShieldCheck, Key, Lock } from 'lucide-react';

export const ProvidersPage: React.FC = () => {
  const [providers, setProviders] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [message, setMessage] = useState<string | null>(null);

  useEffect(() => {
    loadProviders();
  }, []);

  const loadProviders = async () => {
    try {
      setLoading(true);
      const data = await api.getProviders();
      setProviders(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleToggle = async (id: string, currentEnabled: boolean) => {
    try {
      await api.updateProvider(id, { isEnabled: !currentEnabled });
      await loadProviders();
    } catch (err: any) {
      setMessage(`Update error: ${err.message}`);
    }
  };

  const handleSetDefault = async (id: string) => {
    try {
      await api.updateProvider(id, { isDefault: true });
      await loadProviders();
    } catch (err: any) {
      setMessage(`Update error: ${err.message}`);
    }
  };

  return (
    <div style={{ padding: '2rem' }}>
      <div className="page-header">
        <div>
          <h1 className="page-title">AI Engine Providers</h1>
          <p className="page-description">
            Multi-model orchestration: LLMs, text-to-speech, and visual diffusion models. Secrets strictly isolated on server.
          </p>
        </div>
      </div>

      {message && (
        <div className="badge badge-info" style={{ marginBottom: '1.25rem', padding: '8px 12px' }}>
          {message}
        </div>
      )}

      {loading ? (
        <p style={{ color: 'var(--text-muted)' }}>Loading AI providers...</p>
      ) : (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: '1.5rem' }}>
          {providers.map((p) => (
            <div key={p.id} className="glass-panel" style={{ padding: '1.5rem', display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}>
              <div>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1rem' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                    <div
                      style={{
                        width: '36px',
                        height: '36px',
                        borderRadius: '8px',
                        background: 'rgba(59, 130, 246, 0.15)',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        color: '#60a5fa',
                      }}
                    >
                      <Cpu size={20} />
                    </div>
                    <div>
                      <h3 style={{ fontSize: '1.1rem', fontWeight: 800, textTransform: 'capitalize' }}>{p.name}</h3>
                      <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', textTransform: 'uppercase' }}>
                        Type: {p.providerType}
                      </div>
                    </div>
                  </div>

                  <span className={`badge ${p.hasServerSideKey ? 'badge-success' : 'badge-warning'}`}>
                    {p.hasServerSideKey ? 'Key Configured' : 'Missing Key'}
                  </span>
                </div>

                {/* Configuration summary (safe - NO secrets) */}
                <div style={{ background: 'var(--bg-surface-elevated)', borderRadius: '8px', padding: '10px', marginBottom: '1rem', fontSize: '0.8rem' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '4px' }}>
                    <span style={{ color: 'var(--text-secondary)' }}>Status:</span>
                    <strong style={{ color: p.isEnabled ? '#34d399' : 'var(--text-muted)' }}>
                      {p.isEnabled ? 'Enabled' : 'Disabled'}
                    </strong>
                  </div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '4px' }}>
                    <span style={{ color: 'var(--text-secondary)' }}>Default Provider:</span>
                    <strong>{p.isDefault ? 'Yes' : 'No'}</strong>
                  </div>
                  <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                    <span style={{ color: 'var(--text-secondary)' }}>Security Gate:</span>
                    <span style={{ color: '#60a5fa', display: 'flex', alignItems: 'center', gap: '4px' }}>
                      <Lock size={12} /> Server-Side Encrypted
                    </span>
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div style={{ display: 'flex', gap: '0.5rem', borderTop: '1px solid var(--border-subtle)', paddingTop: '10px' }}>
                <button
                  className="btn btn-secondary"
                  style={{ flex: 1, fontSize: '0.78rem' }}
                  onClick={() => handleToggle(p.id, p.isEnabled)}
                >
                  {p.isEnabled ? 'Disable' : 'Enable'}
                </button>
                {!p.isDefault && p.isEnabled && (
                  <button
                    className="btn btn-primary"
                    style={{ flex: 1, fontSize: '0.78rem' }}
                    onClick={() => handleSetDefault(p.id)}
                  >
                    Set as Default
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

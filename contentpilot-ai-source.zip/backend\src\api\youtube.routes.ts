import { Router, Request, Response, NextFunction } from 'express';
import { prisma } from '../database/client.js';
import { youtubeAuthService } from '../services/youtube/youtubeAuth.js';
import { youtubeUploadEngine } from '../services/youtube/youtubeUploadEngine.js';

const router = Router();
const param = (p: string | string[]): string => (Array.isArray(p) ? p[0] : p);

// GET OAuth authorization URL
router.get('/auth-url', (req: Request, res: Response, next: NextFunction) => {
  try {
    const state = req.query.state as string | undefined;
    const url = youtubeAuthService.getAuthUrl(state);
    res.json({ success: true, url });
  } catch (err) {
    next(err);
  }
});

// POST handle OAuth callback code
router.post('/callback', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { code, channelId } = req.body;
    if (!code || !channelId) {
      res.status(400).json({ success: false, error: 'Fields "code" and "channelId" are required' });
      return;
    }
    const result = await youtubeAuthService.handleCallback(code, channelId);
    res.json({ success: true, channel: result });
  } catch (err) {
    next(err);
  }
});

// GET verify channel connection
router.get('/verify/:channelId', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const status = await youtubeAuthService.verifyChannel(param(req.params.channelId));
    res.json({ success: true, status });
  } catch (err) {
    next(err);
  }
});

// POST disconnect channel
router.post('/disconnect/:channelId', async (req: Request, res: Response, next: NextFunction) => {
  try {
    await youtubeAuthService.disconnectChannel(param(req.params.channelId));
    res.json({ success: true, message: 'YouTube channel disconnected' });
  } catch (err) {
    next(err);
  }
});

// POST trigger upload for project
router.post('/upload/:projectId', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { channelId, privacyStatus, scheduledPublishTime, playlistId } = req.body;
    if (!channelId) {
      res.status(400).json({ success: false, error: 'Field "channelId" is required' });
      return;
    }
    const result = await youtubeUploadEngine.upload({
      projectId: param(req.params.projectId),
      channelId,
      privacyStatus,
      scheduledPublishTime: scheduledPublishTime ? new Date(scheduledPublishTime) : undefined,
      playlistId,
    });
    res.json({ success: true, result });
  } catch (err) {
    next(err);
  }
});

// GET video status on YouTube
router.get('/video-status/:channelId/:videoId', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const status = await youtubeUploadEngine.getVideoStatus(param(req.params.channelId), param(req.params.videoId));
    res.json({ success: true, status });
  } catch (err) {
    next(err);
  }
});

// PATCH update video metadata on YouTube
router.patch('/metadata/:channelId/:videoId', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const updated = await youtubeUploadEngine.updateMetadata(
      param(req.params.channelId),
      param(req.params.videoId),
      req.body
    );
    res.json({ success: true, updated });
  } catch (err) {
    next(err);
  }
});

// GET all published/uploaded videos for a channel
router.get('/videos/:channelId', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const channelId = param(req.params.channelId);
    const videos = await prisma.youTubeVideo.findMany({
      where: { channelId },
      include: {
        project: { select: { id: true, title: true, format: true } },
        analytics: { where: { measurementWindow: 'lifetime' }, take: 1 },
      },
      orderBy: { publishedAt: 'desc' },
      take: 50,
    });
    res.json({ success: true, count: videos.length, data: videos });
  } catch (err) {
    next(err);
  }
});

// GET complete channel YouTube connection and status overview
router.get('/status/:channelId', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const channelId = param(req.params.channelId);
    const channel = await prisma.channel.findUnique({
      where: { id: channelId },
      include: { settings: true },
    });

    const credential = await prisma.credential.findFirst({
      where: { channelId, provider: 'youtube', status: 'active' },
      select: { provider: true, status: true, updatedAt: true, expiresAt: true },
    });

    const publishedCount = await prisma.youTubeVideo.count({ where: { channelId } });
    const queuedCount = await prisma.publishingQueue.count({
      where: { channelId, status: { in: ['QUEUED', 'PUBLISHING'] } },
    });

    res.json({
      success: true,
      data: {
        channel: channel
          ? {
              id: channel.id,
              name: channel.name,
              handle: channel.handle,
              youtubeChannelId: channel.youtubeChannelId,
              defaultLanguage: channel.defaultLanguage,
              timezone: channel.timezone,
            }
          : null,
        isConnected: !!credential,
        credentialStatus: credential?.status || 'disconnected',
        tokenExpiresAt: credential?.expiresAt || null,
        publishedCount,
        queuedCount,
      },
    });
  } catch (err) {
    next(err);
  }
});

export default router;

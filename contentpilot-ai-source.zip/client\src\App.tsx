import React, { useEffect, useState } from 'react';
import { api } from './services/api';
import { Channel, PageId } from './types';
import { Sidebar } from './components/Sidebar';
import { Header } from './components/Header';

// 19 Pages
import { OverviewPage } from './pages/OverviewPage';
import { AutonomousOperatorPage } from './pages/AutonomousOperatorPage';
import { ResearchPage } from './pages/ResearchPage';
import { ContentIdeasPage } from './pages/ContentIdeasPage';
import { StrategyPage } from './pages/StrategyPage';
import { ScriptsPage } from './pages/ScriptsPage';
import { ThumbnailsPage } from './pages/ThumbnailsPage';
import { ProductionPage } from './pages/ProductionPage';
import { ReviewStudioPage } from './pages/ReviewStudioPage';
import { PublishingQueuePage } from './pages/PublishingQueuePage';
import { YouTubeChannelPage } from './pages/YouTubeChannelPage';
import { AnalyticsPage } from './pages/AnalyticsPage';
import { ExperimentsPage } from './pages/ExperimentsPage';
import { LearningPage } from './pages/LearningPage';
import { SchedulerPage } from './pages/SchedulerPage';
import { ProvidersPage } from './pages/ProvidersPage';
import { SettingsPage } from './pages/SettingsPage';
import { LogsPage } from './pages/LogsPage';
import { SystemHealthPage } from './pages/SystemHealthPage';

export const App: React.FC = () => {
  const [currentPage, setCurrentPage] = useState<PageId>('overview');
  const [channels, setChannels] = useState<Channel[]>([]);
  const [selectedChannelId, setSelectedChannelId] = useState<string>('');
  const [pendingApprovalsCount, setPendingApprovalsCount] = useState<number>(0);
  const [isRefreshing, setIsRefreshing] = useState<boolean>(false);
  const [initLoading, setInitLoading] = useState<boolean>(true);

  useEffect(() => {
    initApp();
  }, []);

  useEffect(() => {
    if (selectedChannelId) {
      loadPendingCount();
    }
  }, [selectedChannelId]);

  const initApp = async () => {
    try {
      setInitLoading(true);
      let list = await api.getChannels();
      if (list.length === 0) {
        // Automatically create a default channel workspace if none exists
        const def = await api.createChannel({
          name: 'ContentPilot AI Tech',
          niche: 'Artificial Intelligence & Robotics',
          targetAudience: 'Software Engineers and Tech Enthusiasts',
          brandVoice: 'Authoritative, analytical, and visionary',
          visualStyle: 'Sleek dark tech with cybernetic neon accents',
        });
        list = [def];
      }
      setChannels(list);
      setSelectedChannelId(list[0].id);
    } catch (err) {
      console.error('Failed to initialize channels:', err);
    } finally {
      setInitLoading(false);
    }
  };

  const loadPendingCount = async () => {
    try {
      const pending = await api.getPendingApprovals(selectedChannelId);
      setPendingApprovalsCount(pending.length);
    } catch {
      // Ignore count fetch errors
    }
  };

  const handleRefresh = async () => {
    setIsRefreshing(true);
    await loadPendingCount();
    setTimeout(() => setIsRefreshing(false), 400);
  };

  const renderActivePage = () => {
    switch (currentPage) {
      case 'overview':
        return <OverviewPage channelId={selectedChannelId} onNavigate={setCurrentPage} />;
      case 'operator':
        return <AutonomousOperatorPage channelId={selectedChannelId} onNavigate={setCurrentPage} />;
      case 'research':
        return <ResearchPage channelId={selectedChannelId} onNavigate={setCurrentPage} />;
      case 'ideas':
        return <ContentIdeasPage channelId={selectedChannelId} onNavigate={setCurrentPage} />;
      case 'strategy':
        return <StrategyPage channelId={selectedChannelId} onNavigate={setCurrentPage} />;
      case 'scripts':
        return <ScriptsPage channelId={selectedChannelId} onNavigate={setCurrentPage} />;
      case 'thumbnails':
        return <ThumbnailsPage channelId={selectedChannelId} onNavigate={setCurrentPage} />;
      case 'production':
        return <ProductionPage channelId={selectedChannelId} onNavigate={setCurrentPage} />;
      case 'review':
        return <ReviewStudioPage channelId={selectedChannelId} onNavigate={setCurrentPage} />;
      case 'publishing':
        return <PublishingQueuePage channelId={selectedChannelId} onNavigate={setCurrentPage} />;
      case 'youtube':
        return <YouTubeChannelPage channelId={selectedChannelId} onNavigate={setCurrentPage} />;
      case 'analytics':
        return <AnalyticsPage channelId={selectedChannelId} onNavigate={setCurrentPage} />;
      case 'experiments':
        return <ExperimentsPage channelId={selectedChannelId} onNavigate={setCurrentPage} />;
      case 'learning':
        return <LearningPage channelId={selectedChannelId} onNavigate={setCurrentPage} />;
      case 'scheduler':
        return <SchedulerPage channelId={selectedChannelId} onNavigate={setCurrentPage} />;
      case 'providers':
        return <ProvidersPage />;
      case 'settings':
        return <SettingsPage channelId={selectedChannelId} onRefreshChannels={initApp} />;
      case 'logs':
        return <LogsPage channelId={selectedChannelId} />;
      case 'health':
        return <SystemHealthPage />;
      default:
        return <OverviewPage channelId={selectedChannelId} onNavigate={setCurrentPage} />;
    }
  };

  if (initLoading) {
    return (
      <div
        style={{
          minHeight: '100vh',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          background: 'var(--bg-main)',
          color: 'var(--text-secondary)',
          fontSize: '0.9rem',
        }}
      >
        Initializing ContentPilot AI Enterprise Operations Console...
      </div>
    );
  }

  return (
    <div className="app-container">
      {/* Sidebar Navigation */}
      <Sidebar
        currentPage={currentPage}
        onNavigate={setCurrentPage}
        pendingApprovalsCount={pendingApprovalsCount}
      />

      {/* Main Content Area */}
      <div className="main-content">
        <Header
          channels={channels}
          selectedChannelId={selectedChannelId}
          onSelectChannel={setSelectedChannelId}
          onRefresh={handleRefresh}
          isRefreshing={isRefreshing}
        />

        <main style={{ minHeight: 'calc(100vh - var(--header-height))' }}>
          {renderActivePage()}
        </main>
      </div>
    </div>
  );
};

export default App;

import React, { useEffect, useState } from 'react';
import { api } from '../services/api';
import { HealthReport } from '../types';
import { Activity, RefreshCw, CheckCircle2, AlertTriangle, XCircle, HelpCircle, ShieldCheck } from 'lucide-react';

export const SystemHealthPage: React.FC = () => {
  const [report, setReport] = useState<HealthReport | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    loadHealth();
  }, []);

  const loadHealth = async () => {
    try {
      setLoading(true);
      setError(null);
      const data = await api.getSystemHealth();
      setReport(data);
    } catch (err: any) {
      setError(err.message || 'Health check probe failed');
    } finally {
      setLoading(false);
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'healthy':
        return (
          <span className="badge badge-success">
            <CheckCircle2 size={12} /> Healthy
          </span>
        );
      case 'warning':
        return (
          <span className="badge badge-warning">
            <AlertTriangle size={12} /> Warning
          </span>
        );
      case 'error':
        return (
          <span className="badge badge-danger">
            <XCircle size={12} /> Error
          </span>
        );
      case 'not_configured':
      default:
        return (
          <span className="badge badge-info" style={{ background: 'rgba(100, 116, 139, 0.2)', color: '#94a3b8' }}>
            <HelpCircle size={12} /> Not Configured
          </span>
        );
    }
  };

  return (
    <div style={{ padding: '2rem' }}>
      <div className="page-header">
        <div>
          <h1 className="page-title">Infrastructure Health Diagnostics</h1>
          <p className="page-description">
            Live diagnostic probes checking binary availability, database response times, and credential state.
          </p>
        </div>
        <button className="btn btn-secondary" onClick={loadHealth}>
          <RefreshCw size={14} /> Run Diagnostic Probe
        </button>
      </div>

      {error && (
        <div className="badge badge-danger" style={{ marginBottom: '1.5rem', padding: '8px 12px' }}>
          {error}
        </div>
      )}

      {loading ? (
        <p style={{ color: 'var(--text-muted)' }}>Probing all system services...</p>
      ) : !report ? (
        <p style={{ color: 'var(--text-muted)' }}>No diagnostic report available.</p>
      ) : (
        <div>
          {/* Top Overall Status Panel */}
          <div className="glass-panel" style={{ padding: '1.5rem', marginBottom: '2rem' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
                <div
                  style={{
                    width: '44px',
                    height: '44px',
                    borderRadius: '10px',
                    background: report.status === 'healthy' ? 'rgba(16, 185, 129, 0.15)' : 'rgba(245, 158, 11, 0.15)',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    color: report.status === 'healthy' ? '#34d399' : '#fbbf24',
                  }}
                >
                  <Activity size={24} />
                </div>
                <div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                    <h2 style={{ fontSize: '1.25rem', fontWeight: 800 }}>System Platform State</h2>
                    {getStatusBadge(report.status)}
                  </div>
                  <div style={{ fontSize: '0.85rem', color: 'var(--text-secondary)', marginTop: '2px' }}>
                    Probe completed in {report.totalDurationMs}ms • Timestamp: {new Date(report.timestamp).toLocaleTimeString()}
                  </div>
                </div>
              </div>

              <div style={{ display: 'flex', gap: '0.75rem' }}>
                <span className="badge badge-warning">
                  AUTO_PUBLISH: {report.governance.autoPublish ? 'TRUE' : 'FALSE'}
                </span>
                <span className="badge badge-info">
                  APPROVAL REQUIRED: {report.governance.requireHumanApproval ? 'TRUE' : 'FALSE'}
                </span>
              </div>
            </div>
          </div>

          {/* 8 Components Grid */}
          <h2 style={{ fontSize: '1.15rem', fontWeight: 700, marginBottom: '1rem' }}>Subsystem Probes</h2>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))', gap: '1.25rem' }}>
            {report.components.map((comp) => (
              <div key={comp.name} className="glass-card" style={{ padding: '1.25rem' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '8px' }}>
                  <h3 style={{ fontSize: '1rem', fontWeight: 700 }}>{comp.name}</h3>
                  {getStatusBadge(comp.status)}
                </div>

                <p style={{ fontSize: '0.85rem', color: 'var(--text-secondary)', marginBottom: '8px', lineHeight: 1.4 }}>
                  {comp.message}
                </p>

                {comp.latencyMs !== undefined && (
                  <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>
                    Latency: <strong>{comp.latencyMs}ms</strong>
                  </div>
                )}

                {comp.details && (
                  <div style={{ background: 'var(--bg-surface)', padding: '6px 8px', borderRadius: '6px', marginTop: '8px', fontSize: '0.75rem', fontFamily: 'var(--font-mono)', color: 'var(--text-muted)' }}>
                    {JSON.stringify(comp.details)}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

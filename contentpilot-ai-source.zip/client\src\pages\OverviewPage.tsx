import React, { useEffect, useState } from 'react';
import { api } from '../services/api';
import { OverviewData } from '../types';
import { EmptyState } from '../components/EmptyState';
import {
  Clock,
  AlertTriangle,
  CheckCircle2,
  Calendar,
  Eye,
  ThumbsUp,
  Cpu,
  Youtube,
  HardDrive,
  Film,
  ArrowRight,
} from 'lucide-react';

interface OverviewPageProps {
  channelId: string;
  onNavigate: (page: any) => void;
}

export const OverviewPage: React.FC<OverviewPageProps> = ({ channelId, onNavigate }) => {
  const [data, setData] = useState<OverviewData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    loadOverview();
  }, [channelId]);

  const loadOverview = async () => {
    try {
      setLoading(true);
      setError(null);
      const res = await api.getOverview(channelId);
      setData(res);
    } catch (err: any) {
      setError(err.message || 'Failed to fetch overview telemetry');
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div style={{ padding: '2rem' }}>
        <p style={{ color: 'var(--text-muted)' }}>Loading live operations telemetry...</p>
      </div>
    );
  }

  if (error || !data) {
    return (
      <div style={{ padding: '2rem' }}>
        <div className="badge badge-danger" style={{ marginBottom: '1rem' }}>
          {error || 'Unable to connect to backend telemetry'}
        </div>
        <EmptyState title="No data yet." message={error || 'Could not load overview statistics.'} onAction={loadOverview} actionText="Retry" />
      </div>
    );
  }

  return (
    <div style={{ padding: '2rem' }}>
      {/* Header */}
      <div className="page-header">
        <div>
          <h1 className="page-title">Operations Command Center</h1>
          <p className="page-description">
            Real-time pipeline orchestration, approval gates, and autonomous channel status.
          </p>
        </div>
      </div>

      {/* Prominent Production Safety Governance Indicator */}
      <div
        className="glass-panel"
        style={{
          padding: '1rem 1.5rem',
          marginBottom: '1.5rem',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          background: 'linear-gradient(90deg, rgba(16, 185, 129, 0.08) 0%, rgba(59, 130, 246, 0.08) 100%)',
          border: '1px solid rgba(16, 185, 129, 0.25)',
          borderRadius: '12px',
          flexWrap: 'wrap',
          gap: '1rem',
        }}
      >
        <div style={{ display: 'flex', gap: '0.6rem', flexWrap: 'wrap', alignItems: 'center' }}>
          <span className="badge badge-success" style={{ fontWeight: 700, padding: '6px 12px' }}>
            AUTO-PUBLISH: {data.automation.autoPublish ? 'ON' : 'OFF'}
          </span>
          <span className="badge badge-info" style={{ fontWeight: 700, padding: '6px 12px' }}>
            HUMAN APPROVAL: {data.automation.requireHumanApproval ? 'REQUIRED' : 'DISABLED'}
          </span>
          <span className="badge" style={{ fontWeight: 700, padding: '6px 12px', background: 'rgba(139, 92, 246, 0.2)', color: '#c084fc' }}>
            DEFAULT PRIVACY: {data.automation.defaultPrivacy?.toUpperCase() || 'PUBLIC'}
          </span>
          <span className="badge badge-success" style={{ fontWeight: 700, padding: '6px 12px' }}>
            AUTOMATION: {data.automation.schedulerRunning ? 'ON' : 'IDLE'}
          </span>
        </div>
        <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>
          Cadence: <strong style={{ color: 'var(--text-primary)' }}>{data.automation.publishingCadence}</strong> • Multi-Stage Gates: <strong style={{ color: '#34d399' }}>Enforced</strong>
        </div>
      </div>

      {/* Top Telemetry Stats Grid */}
      <div className="stat-grid">
        <div className="stat-card">
          <div className="label">Active Jobs</div>
          <div className="value" style={{ color: data.activeJobsCount > 0 ? '#60a5fa' : 'var(--text-primary)' }}>
            {data.activeJobsCount}
          </div>
        </div>

        <div className="stat-card">
          <div className="label">Awaiting Human Approval</div>
          <div
            className="value"
            style={{ color: data.awaitingApprovalCount > 0 ? '#fbbf24' : 'var(--text-primary)' }}
          >
            {data.awaitingApprovalCount}
          </div>
        </div>

        <div className="stat-card">
          <div className="label">Scheduled Releases</div>
          <div className="value">{data.scheduledVideosCount}</div>
        </div>

        <div className="stat-card">
          <div className="label">Published on YouTube</div>
          <div className="value" style={{ color: '#34d399' }}>
            {data.publishedVideosCount}
          </div>
        </div>

        <div className="stat-card">
          <div className="label">Failed Jobs</div>
          <div className="value" style={{ color: data.failedJobsCount > 0 ? '#f87171' : 'var(--text-muted)' }}>
            {data.failedJobsCount}
          </div>
        </div>
      </div>

      {/* Main Grid: Pipeline Activity & Channel Analytics */}
      <div style={{ display: 'grid', gridTemplateColumns: '1.4fr 1fr', gap: '1.5rem', marginBottom: '2rem' }}>
        {/* Recent Pipeline Activity */}
        <div className="glass-panel" style={{ padding: '1.5rem' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1rem' }}>
            <h2 style={{ fontSize: '1.1rem', fontWeight: 700 }}>Active Production Pipelines</h2>
            <button
              className="btn btn-secondary"
              style={{ fontSize: '0.75rem', padding: '4px 10px' }}
              onClick={() => onNavigate('production')}
            >
              View All <ArrowRight size={12} />
            </button>
          </div>

          {data.recentProjects.length === 0 ? (
            <EmptyState
              title="No data yet."
              message="No video production pipelines have been initiated. Launch the Autonomous Operator to begin."
              actionText="Open Operator"
              onAction={() => onNavigate('operator')}
            />
          ) : (
            <div className="table-container">
              <table className="table">
                <thead>
                  <tr>
                    <th>Title</th>
                    <th>Stage</th>
                    <th>Status</th>
                    <th>Updated</th>
                  </tr>
                </thead>
                <tbody>
                  {data.recentProjects.map((p) => (
                    <tr key={p.id}>
                      <td style={{ fontWeight: 600, maxWidth: '220px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                        {p.title}
                      </td>
                      <td>
                        <span className="badge badge-info" style={{ fontSize: '0.68rem' }}>
                          {p.currentStage}
                        </span>
                      </td>
                      <td>
                        <span
                          className={`badge ${
                            p.status === 'APPROVED' || p.status === 'PUBLISHED'
                              ? 'badge-success'
                              : p.status === 'AWAITING_APPROVAL'
                              ? 'badge-warning'
                              : 'badge-info'
                          }`}
                          style={{ fontSize: '0.68rem' }}
                        >
                          {p.status}
                        </span>
                      </td>
                      <td style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>
                        {new Date(p.updatedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {/* Channel Analytics Summary */}
        <div className="glass-panel" style={{ padding: '1.5rem' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1rem' }}>
            <h2 style={{ fontSize: '1.1rem', fontWeight: 700 }}>Channel Performance Summary</h2>
            <button
              className="btn btn-secondary"
              style={{ fontSize: '0.75rem', padding: '4px 10px' }}
              onClick={() => onNavigate('analytics')}
            >
              Full Analytics <ArrowRight size={12} />
            </button>
          </div>

          {!data.analytics.hasData ? (
            <EmptyState
              title="No data yet."
              message="No YouTube analytics snapshots captured yet. Sync channel analytics after videos are published."
            />
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
              <div
                style={{
                  display: 'grid',
                  gridTemplateColumns: '1fr 1fr',
                  gap: '0.75rem',
                }}
              >
                <div style={{ background: 'var(--bg-card)', padding: '1rem', borderRadius: '8px' }}>
                  <div style={{ fontSize: '0.75rem', color: 'var(--text-secondary)' }}>Total Views</div>
                  <div style={{ fontSize: '1.25rem', fontWeight: 800, marginTop: '2px' }}>
                    {data.analytics.totalViews.toLocaleString()}
                  </div>
                </div>
                <div style={{ background: 'var(--bg-card)', padding: '1rem', borderRadius: '8px' }}>
                  <div style={{ fontSize: '0.75rem', color: 'var(--text-secondary)' }}>Watch Time (Mins)</div>
                  <div style={{ fontSize: '1.25rem', fontWeight: 800, marginTop: '2px' }}>
                    {data.analytics.totalWatchTimeMinutes.toLocaleString()}
                  </div>
                </div>
                <div style={{ background: 'var(--bg-card)', padding: '1rem', borderRadius: '8px' }}>
                  <div style={{ fontSize: '0.75rem', color: 'var(--text-secondary)' }}>Likes</div>
                  <div style={{ fontSize: '1.25rem', fontWeight: 800, marginTop: '2px' }}>
                    {data.analytics.totalLikes.toLocaleString()}
                  </div>
                </div>
                <div style={{ background: 'var(--bg-card)', padding: '1rem', borderRadius: '8px' }}>
                  <div style={{ fontSize: '0.75rem', color: 'var(--text-secondary)' }}>Videos Tracked</div>
                  <div style={{ fontSize: '1.25rem', fontWeight: 800, marginTop: '2px' }}>
                    {data.analytics.videoCount}
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Subsystem Health Cards Grid */}
      <h2 style={{ fontSize: '1.1rem', fontWeight: 700, marginBottom: '1rem' }}>Engine Infrastructure Status</h2>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: '1rem' }}>
        <div className="glass-card" style={{ padding: '1.25rem' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '8px' }}>
            <Cpu size={18} color="#3b82f6" />
            <span style={{ fontSize: '0.85rem', fontWeight: 600 }}>Google Gemini</span>
          </div>
          <span className={`badge ${data.systemStatus.geminiConfigured ? 'badge-success' : 'badge-warning'}`}>
            {data.systemStatus.geminiConfigured ? 'Configured' : 'Missing Key'}
          </span>
        </div>

        <div className="glass-card" style={{ padding: '1.25rem' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '8px' }}>
            <Youtube size={18} color="#ef4444" />
            <span style={{ fontSize: '0.85rem', fontWeight: 600 }}>YouTube OAuth</span>
          </div>
          <span className={`badge ${data.systemStatus.youtubeConnected ? 'badge-success' : 'badge-info'}`}>
            {data.systemStatus.youtubeConnected ? 'Connected' : 'Not Connected'}
          </span>
        </div>

        <div className="glass-card" style={{ padding: '1.25rem' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '8px' }}>
            <HardDrive size={18} color="#10b981" />
            <span style={{ fontSize: '0.85rem', fontWeight: 600 }}>SQLite Database</span>
          </div>
          <span className="badge badge-success">WAL Mode Active</span>
        </div>

        <div className="glass-card" style={{ padding: '1.25rem' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '8px' }}>
            <Clock size={18} color="#8b5cf6" />
            <span style={{ fontSize: '0.85rem', fontWeight: 600 }}>Persistent Scheduler</span>
          </div>
          <span className={`badge ${data.automation.schedulerRunning ? 'badge-success' : 'badge-warning'}`}>
            {data.automation.schedulerRunning ? 'Loop Running' : 'Idle'}
          </span>
        </div>
      </div>
    </div>
  );
};

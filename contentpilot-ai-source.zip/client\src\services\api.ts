import {
  Channel,
  ChannelSettings,
  HealthReport,
  OverviewData,
  ReviewBundle,
} from '../types';

const BASE_URL = (import.meta.env.VITE_API_URL || '').replace(/\/+$/, '');

async function request<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
  const url = `${BASE_URL}${endpoint}`;
  const headers: HeadersInit = {
    'Content-Type': 'application/json',
    ...(options.headers || {}),
  };

  const response = await fetch(url, { ...options, headers });
  const data = await response.json();

  if (!response.ok || data.success === false) {
    const errorMsg = data.error || data.message || `Request failed with status ${response.status}`;
    throw new Error(errorMsg);
  }

  return data;
}

export const api = {
  // 1. Overview
  async getOverview(channelId?: string): Promise<OverviewData> {
    const query = channelId ? `?channelId=${encodeURIComponent(channelId)}` : '';
    const res = await request<{ success: boolean; data: OverviewData }>(`/api/overview${query}`);
    return res.data;
  },

  // 2. Autonomous Operator
  async getOperatorStatus(channelId?: string) {
    const query = channelId ? `?channelId=${encodeURIComponent(channelId)}` : '';
    const res = await request<{ success: boolean; data: any }>(`/api/operator/status${query}`);
    return res.data;
  },
  async runOperator(payload: any) {
    return request<{ success: boolean; result: any }>('/api/operator/run', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },
  async pauseOperator(projectId: string) {
    return request<{ success: boolean; message: string }>('/api/operator/pause', {
      method: 'POST',
      body: JSON.stringify({ projectId }),
    });
  },
  async resumeOperator(projectId: string, channelId: string) {
    return request<{ success: boolean; result: any; message: string }>('/api/operator/resume', {
      method: 'POST',
      body: JSON.stringify({ projectId, channelId }),
    });
  },
  async cancelOperator(projectId: string) {
    return request<{ success: boolean; message: string }>('/api/operator/cancel', {
      method: 'POST',
      body: JSON.stringify({ projectId }),
    });
  },
  async getOperatorLogs(projectId: string) {
    const res = await request<{ success: boolean; data: any }>(`/api/operator/logs/${projectId}`);
    return res.data;
  },

  // 3. Research
  async getResearchRuns(channelId?: string) {
    const query = channelId ? `?channelId=${encodeURIComponent(channelId)}` : '';
    const res = await request<{ success: boolean; data: any[] }>(`/api/research${query}`);
    return res.data;
  },
  async runResearch(payload: any) {
    const res = await request<{ success: boolean; data: any }>('/api/research/run', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
    return res.data;
  },

  // 4. Content Ideas
  async getContentIdeas(channelId?: string, status?: string) {
    const params = new URLSearchParams();
    if (channelId) params.append('channelId', channelId);
    if (status) params.append('status', status);
    const res = await request<{ success: boolean; data: any[] }>(`/api/ideas?${params.toString()}`);
    return res.data;
  },
  async createIdea(payload: any) {
    const res = await request<{ success: boolean; data: any }>('/api/ideas', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
    return res.data;
  },
  async updateIdeaStatus(id: string, status: string) {
    const res = await request<{ success: boolean; data: any }>(`/api/ideas/${id}/status`, {
      method: 'PATCH',
      body: JSON.stringify({ status }),
    });
    return res.data;
  },

  // 5. Strategy
  async getStrategies(channelId?: string) {
    const query = channelId ? `?channelId=${encodeURIComponent(channelId)}` : '';
    const res = await request<{ success: boolean; data: any[] }>(`/api/strategy${query}`);
    return res.data;
  },
  async generateStrategy(payload: any) {
    const res = await request<{ success: boolean; data: any }>('/api/strategy/generate', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
    return res.data;
  },

  // 6. Scripts
  async getScripts(channelId?: string) {
    const query = channelId ? `?channelId=${encodeURIComponent(channelId)}` : '';
    const res = await request<{ success: boolean; data: any[] }>(`/api/scripts${query}`);
    return res.data;
  },
  async getScript(id: string) {
    const res = await request<{ success: boolean; data: any }>(`/api/scripts/${id}`);
    return res.data;
  },
  async generateScript(payload: any) {
    const res = await request<{ success: boolean; data: any }>('/api/scripts/generate', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
    return res.data;
  },
  async updateScript(id: string, payload: any) {
    const res = await request<{ success: boolean; data: any; version: number }>(`/api/scripts/${id}`, {
      method: 'PUT',
      body: JSON.stringify(payload),
    });
    return res;
  },

  // 7. Thumbnails
  async getThumbnails(channelId?: string) {
    const query = channelId ? `?channelId=${encodeURIComponent(channelId)}` : '';
    const res = await request<{ success: boolean; data: any[] }>(`/api/thumbnails${query}`);
    return res.data;
  },
  async generateThumbnail(payload: any) {
    const res = await request<{ success: boolean; data: any }>('/api/thumbnails/generate', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
    return res.data;
  },
  async selectThumbnailVariant(thumbnailId: string, variantId: string) {
    const res = await request<{ success: boolean; data: any }>(`/api/thumbnails/${thumbnailId}/select-variant`, {
      method: 'POST',
      body: JSON.stringify({ variantId }),
    });
    return res.data;
  },

  // 8. Production
  async getProductionProjects(channelId?: string) {
    const query = channelId ? `?channelId=${encodeURIComponent(channelId)}` : '';
    const res = await request<{ success: boolean; data: any[] }>(`/api/production/projects${query}`);
    return res.data;
  },
  async getProductionProject(id: string) {
    const res = await request<{ success: boolean; data: any }>(`/api/production/projects/${id}`);
    return res.data;
  },
  async renderProject(id: string) {
    return request<{ success: boolean; message: string; jobId: string }>(`/api/production/projects/${id}/render`, {
      method: 'POST',
    });
  },
  async regenerateScene(projectId: string, sceneIndex: number, visualDescription?: string) {
    return request<{ success: boolean; message: string; jobId: string }>(
      `/api/production/projects/${projectId}/regenerate-scene`,
      {
        method: 'POST',
        body: JSON.stringify({ sceneIndex, visualDescription }),
      }
    );
  },

  // 9. Review Studio
  async getReviewBundle(projectId: string): Promise<ReviewBundle> {
    const res = await request<{ success: boolean; data: ReviewBundle }>(`/api/review/review/${projectId}`);
    return res.data;
  },
  async getPendingApprovals(channelId?: string) {
    const query = channelId ? `?channelId=${encodeURIComponent(channelId)}` : '';
    const res = await request<{ success: boolean; count: number; data: any[] }>(`/api/review/pending${query}`);
    return res.data;
  },
  async approveProject(projectId: string, approvedBy: string, notes?: string) {
    return request<{ success: boolean; message: string }>(`/api/review/${projectId}/approve`, {
      method: 'POST',
      body: JSON.stringify({ approvedBy, notes }),
    });
  },
  async rejectProject(projectId: string, reviewer: string, reason: string) {
    return request<{ success: boolean; message: string }>(`/api/review/${projectId}/reject`, {
      method: 'POST',
      body: JSON.stringify({ reviewer, reason }),
    });
  },
  async editProject(projectId: string, edits: any, editor: string) {
    return request<{ success: boolean; message: string }>(`/api/review/${projectId}/edit`, {
      method: 'POST',
      body: JSON.stringify({ edits, editor }),
    });
  },
  async regenerateProjectStage(projectId: string, stage: string, requestedBy: string) {
    return request<{ success: boolean; message: string; jobId: string }>(`/api/review/${projectId}/regenerate`, {
      method: 'POST',
      body: JSON.stringify({ stage, requestedBy }),
    });
  },
  async sendBackProject(projectId: string, targetStage: string, notes: string, reviewer: string) {
    return request<{ success: boolean; message: string }>(`/api/review/${projectId}/send-back`, {
      method: 'POST',
      body: JSON.stringify({ targetStage, notes, reviewer }),
    });
  },
  async scheduleProject(projectId: string, scheduledPublishTime: string, privacyStatus: string, scheduledBy: string) {
    return request<{ success: boolean; message: string }>(`/api/review/${projectId}/schedule`, {
      method: 'POST',
      body: JSON.stringify({ scheduledPublishTime, privacyStatus, scheduledBy }),
    });
  },

  // 10. Publishing Queue
  async getPublishingQueue(channelId?: string) {
    const query = channelId ? `?channelId=${encodeURIComponent(channelId)}` : '';
    const res = await request<{ success: boolean; data: any[] }>(`/api/publishing-queue${query}`);
    return res.data;
  },
  async cancelPublishing(id: string) {
    return request<{ success: boolean; message: string }>(`/api/publishing-queue/${id}/cancel`, {
      method: 'POST',
    });
  },
  async retryPublishing(id: string) {
    return request<{ success: boolean; message: string }>(`/api/publishing-queue/${id}/retry`, {
      method: 'POST',
    });
  },

  // 11. YouTube Channel
  async getYouTubeStatus(channelId: string) {
    const res = await request<{ success: boolean; data: any }>(`/api/youtube/status/${channelId}`);
    return res.data;
  },
  async getYouTubeVideos(channelId: string) {
    const res = await request<{ success: boolean; data: any[] }>(`/api/youtube/videos/${channelId}`);
    return res.data;
  },
  async getYouTubeAuthUrl(state?: string) {
    const query = state ? `?state=${encodeURIComponent(state)}` : '';
    const res = await request<{ success: boolean; url: string }>(`/api/youtube/auth-url${query}`);
    return res.url;
  },
  async disconnectYouTube(channelId: string) {
    return request<{ success: boolean; message: string }>(`/api/youtube/disconnect/${channelId}`, {
      method: 'POST',
    });
  },
  async uploadVideo(projectId: string, channelId: string, privacyStatus = 'private', scheduledPublishTime?: string) {
    return request<{ success: boolean; result: any }>(`/api/youtube/upload/${projectId}`, {
      method: 'POST',
      body: JSON.stringify({ channelId, privacyStatus, scheduledPublishTime }),
    });
  },

  // 12. Analytics
  async getAnalyticsOverview(channelId: string) {
    const res = await request<{ success: boolean; data: any[] }>(`/api/analytics/overview/${channelId}`);
    return res.data;
  },
  async getAnalyticsSnapshots(videoId: string) {
    const res = await request<{ success: boolean; data: any[] }>(`/api/analytics/snapshots/${videoId}`);
    return res.data;
  },
  async syncAnalytics(channelId: string) {
    return request<{ success: boolean; snapshotsCaptured: number }>(`/api/analytics/sync/${channelId}`, {
      method: 'POST',
    });
  },

  // 13. Experiments
  async getExperiments(channelId: string) {
    const res = await request<{ success: boolean; data: any[] }>(`/api/experiments/channel/${channelId}`);
    return res.data;
  },
  async createExperiment(payload: any) {
    return request<{ success: boolean; experiment: any }>('/api/experiments', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },
  async concludeExperiment(id: string, payload: any) {
    return request<{ success: boolean; experiment: any }>(`/api/experiments/${id}/conclude`, {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },
  async approveExperiment(id: string, approvedBy: string) {
    return request<{ success: boolean; message: string }>(`/api/experiments/${id}/approve`, {
      method: 'POST',
      body: JSON.stringify({ approvedBy }),
    });
  },
  async applyExperiment(id: string) {
    return request<{ success: boolean; message: string }>(`/api/experiments/${id}/apply`, {
      method: 'POST',
    });
  },

  // 14. Learning
  async getLearningInsights(channelId: string) {
    const res = await request<{ success: boolean; data: any[] }>(`/api/learning/insights/${channelId}`);
    return res.data;
  },
  async runLearningAnalysis(channelId: string) {
    return request<{ success: boolean; data: any[] }>(`/api/learning/analyze/${channelId}`, {
      method: 'POST',
    });
  },

  // 15. Scheduler
  async getSchedulerTasks(channelId?: string) {
    const query = channelId ? `?channelId=${encodeURIComponent(channelId)}` : '';
    const res = await request<{ success: boolean; data: any[] }>(`/api/scheduler/tasks${query}`);
    return res.data;
  },
  async createSchedulerTask(payload: any) {
    return request<{ success: boolean; taskId: string }>('/api/scheduler/tasks', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },
  async deleteSchedulerTask(id: string) {
    return request<{ success: boolean; message: string }>(`/api/scheduler/tasks/${id}`, {
      method: 'DELETE',
    });
  },
  async triggerSchedulerTick() {
    return request<{ success: boolean; processedTasksCount: number }>('/api/scheduler/tick', {
      method: 'POST',
    });
  },
  async getSchedulerConfig(channelId: string): Promise<ChannelSettings> {
    const res = await request<{ success: boolean; data: ChannelSettings }>(`/api/scheduler/config/${channelId}`);
    return res.data;
  },
  async updateSchedulerConfig(channelId: string, payload: Partial<ChannelSettings>) {
    const res = await request<{ success: boolean; data: ChannelSettings }>(`/api/scheduler/config/${channelId}`, {
      method: 'PUT',
      body: JSON.stringify(payload),
    });
    return res.data;
  },

  // 16. Providers
  async getProviders() {
    const res = await request<{ success: boolean; data: any[] }>('/api/providers');
    return res.data;
  },
  async updateProvider(id: string, payload: any) {
    const res = await request<{ success: boolean; data: any }>(`/api/providers/${id}`, {
      method: 'PATCH',
      body: JSON.stringify(payload),
    });
    return res.data;
  },

  // 17. Settings & Channels
  async getChannels(): Promise<Channel[]> {
    const res = await request<{ success: boolean; data: Channel[] }>('/api/settings/channels');
    return res.data;
  },
  async createChannel(payload: Partial<Channel>): Promise<Channel> {
    const res = await request<{ success: boolean; data: Channel }>('/api/settings/channels', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
    return res.data;
  },
  async getChannelSettings(channelId: string): Promise<Channel> {
    const res = await request<{ success: boolean; data: Channel }>(`/api/settings/${channelId}`);
    return res.data;
  },
  async updateChannelSettings(channelId: string, payload: any): Promise<Channel> {
    const res = await request<{ success: boolean; data: Channel }>(`/api/settings/${channelId}`, {
      method: 'PUT',
      body: JSON.stringify(payload),
    });
    return res.data;
  },

  // 18. Logs
  async getSystemLogs(level?: string, limit = 50) {
    const params = new URLSearchParams({ limit: String(limit) });
    if (level) params.append('level', level);
    const res = await request<{ success: boolean; data: any[] }>(`/api/logs/system?${params.toString()}`);
    return res.data;
  },
  async getAuditLogs(channelId?: string, limit = 50) {
    const params = new URLSearchParams({ limit: String(limit) });
    if (channelId) params.append('channelId', channelId);
    const res = await request<{ success: boolean; data: any[] }>(`/api/logs/audit?${params.toString()}`);
    return res.data;
  },
  async getAutoFixLogs(classification?: string, limit = 50) {
    const params = new URLSearchParams({ limit: String(limit) });
    if (classification) params.append('classification', classification);
    const res = await request<{ success: boolean; data: any[] }>(`/api/logs/autofix?${params.toString()}`);
    return res.data;
  },

  // 19. System Health
  async getSystemHealth(): Promise<HealthReport> {
    return request<HealthReport>('/api/health');
  },

  // Media file stream helper
  getMediaUrl(absolutePath: string): string {
    if (!absolutePath) return '';
    if (absolutePath.startsWith('http://') || absolutePath.startsWith('https://')) return absolutePath;
    return `${BASE_URL}/api/media/file?path=${encodeURIComponent(absolutePath)}`;
  },
};

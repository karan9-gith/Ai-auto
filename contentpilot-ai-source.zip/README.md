# ContentPilot AI 🚀

Enterprise-grade autonomous YouTube operations platform powered by multi-agent orchestration, strict human governance, deterministic media rendering, and closed-loop algorithmic learning.

---

## 🏗️ System Architecture

ContentPilot AI is built as a decoupled, production-ready architecture designed for high durability and governance:

```
┌────────────────────────────────┐         ┌─────────────────────────────────────────────────┐
│     Frontend Dashboard         │         │               Backend & Pipeline                │
│    (React 18 + Vite + TS)      │ ──REST─>│     (Node.js 22 + Express + TypeScript)         │
│       Hosted on Vercel         │         │       Hosted on Persistent VPS / Linux          │
└────────────────────────────────┘         └───────────────────────┬─────────────────────────┘
                                                                   │
                                           ┌───────────────────────┼─────────────────────────┐
                                           ▼                       ▼                         ▼
                                ┌────────────────────┐  ┌───────────────────┐     ┌──────────────────┐
                                │ Background Worker  │  │ SQLite (WAL Mode) │     │ Media Storage    │
                                │  & Cron Scheduler  │  │ Persistent Disk   │     │ (MP4/WAV/Images) │
                                └─────────┬──────────┘  └───────────────────┘     └──────────────────┘
                                          │
                                          ├────────────► Google Gemini AI (Research / Scripts / Vision)
                                          ├────────────► FFmpeg & FFprobe (Video Compilation / QC)
                                          └────────────► YouTube Data API v3 (Resumable OAuth Uploads)
```

- **Frontend**: Single Page Application built with React 18, Vite, and Lucide Icons. Designed for deployment on **Vercel** with automatic SPA rewrites.
- **Backend**: Express + TypeScript API server running with Zod environment validation, strict CORS origin checks, and comprehensive security middleware.
- **Worker & Scheduler**: Persistent SQLite-backed queue and cron engine running continuously on a persistent VPS.
- **Database**: SQLite with Write-Ahead Logging (`WAL`), foreign key enforcement, and persistent disk volume.
- **Media Engine**: Native FFmpeg and FFprobe binaries for timeline composition, loudness normalization (-14 LUFS), and audio-video validation.
- **AI Providers**: Google Gemini API for market research, scriptwriting, SEO optimization, and metadata generation.
- **YouTube Integration**: Official YouTube Data API v3 with encrypted OAuth 2.0 token storage and pre-upload verification.

---

## 🔒 Mandatory Human Governance & Publishing Safety

ContentPilot AI strictly enforces a human-in-the-loop editorial policy:

1. **AI Never Approves Its Own Content**: The AI agent produces artifacts up to Step 15 and pauses at the Mandatory Human Approval Gate (Step 16).
2. **Review Studio Sign-Off**: Video files, script, thumbnails, and automated Quality Control (QC) reports must be reviewed and explicitly signed off by a human editor.
3. **Pre-Upload Safety Guard**: The upload engine independently verifies that `status === 'APPROVED'`, QC scores pass, and valid media exists before making any network calls to YouTube.
4. **Publishing Flow**:
   ```
   GENERATED ──> QC ──> RIGHTS CHECK ──> AWAITING_HUMAN_APPROVAL ──> APPROVED ──> READY_TO_PUBLISH ──> UPLOADING ──> PUBLISHED
   ```

---

## 📋 Prerequisites & System Requirements

### Production Server (VPS / Cloud VM)
- **OS**: Ubuntu 22.04+ / Debian 12 / Linux
- **Node.js**: v20.x or v22.x LTS
- **FFmpeg & FFprobe**: Installed and available on system `$PATH` (or configured via environment variables)
  ```bash
  sudo apt-get update && sudo apt-get install -y ffmpeg sqlite3
  ffmpeg -version
  ffprobe -version
  ```
- **Process Manager**: PM2 or Docker

---

## ⚙️ Environment Variables Configuration

Copy `.env.example` to `.env` on your backend server. All secret credentials must remain on the backend server only.

```bash
cp .env.example backend/.env
```

| Variable | Description | Production Example |
| :--- | :--- | :--- |
| `NODE_ENV` | Runtime environment | `production` |
| `PORT` | API server listen port | `3001` |
| `CORS_ORIGIN` | Allowed frontend origin (Vercel domain) | `https://your-app.vercel.app` |
| `APP_SECRET_KEY` | 32+ char key for AES-256 token encryption | `generate_a_secure_32_byte_secret_key` |
| `DATABASE_URL` | Persistent SQLite file path | `file:/var/data/contentpilot/production.db` |
| `AUTO_PUBLISH` | Safe auto-publish flag | `true` |
| `REQUIRE_HUMAN_APPROVAL` | Mandatory human sign-off | `true` |
| `DEFAULT_YOUTUBE_PRIVACY`| YouTube video privacy | `public`, `unlisted`, or `private` |
| `GEMINI_API_KEY` | Google Gemini API key from Google AI Studio | `your_gemini_api_key` |
| `GEMINI_MODEL` | Gemini model identifier | `gemini-2.5-flash` |
| `YOUTUBE_CLIENT_ID` | OAuth 2.0 Client ID from Google Cloud Console | `xxxx.apps.googleusercontent.com` |
| `YOUTUBE_CLIENT_SECRET` | OAuth 2.0 Client Secret | `your_client_secret` |
| `YOUTUBE_REDIRECT_URI` | Production HTTPS OAuth callback | `https://api.yourdomain.com/api/auth/youtube/callback` |
| `FFMPEG_PATH` | Path to ffmpeg binary (optional if on PATH) | `/usr/bin/ffmpeg` |
| `FFPROBE_PATH` | Path to ffprobe binary (optional if on PATH) | `/usr/bin/ffprobe` |
| `STORAGE_DIR` | Persistent storage directory for media | `/var/data/contentpilot/storage` |

---

## 🔑 Google Cloud & YouTube OAuth Configuration

1. Visit [Google Cloud Console](https://console.cloud.google.com/).
2. Create a new project or select an existing project.
3. Enable the **YouTube Data API v3** under **APIs & Services > Library**.
4. Configure the **OAuth Consent Screen**:
   - User Type: External
   - Add Scopes:
     - `https://www.googleapis.com/auth/youtube.upload`
     - `https://www.googleapis.com/auth/youtube.readonly`
     - `https://www.googleapis.com/auth/youtube.force-ssl`
5. Create **OAuth 2.0 Client Credentials**:
   - Application Type: Web application
   - **Authorized JavaScript origins**:
     - `https://your-frontend.vercel.app`
   - **Authorized redirect URIs**:
     - `https://api.yourdomain.com/api/auth/youtube/callback` (Production HTTPS)
     - `http://localhost:3001/api/auth/youtube/callback` (Local Development only)

---

## 🚀 Deployment Instructions

### Target A: Frontend Deployment (Vercel)

1. Connect your repository to **Vercel** (`https://vercel.com`).
2. Set the project configuration:
   - **Framework Preset**: `Vite`
   - **Root Directory**: `client` (or root using included `vercel.json`)
   - **Build Command**: `npm run build`
   - **Output Directory**: `dist`
   - **Install Command**: `npm install`
3. Configure Environment Variables in Vercel:
   - `VITE_API_URL`: `https://api.yourdomain.com` (Your production backend URL)
4. Deploy the project. Vercel automatically deploys the frontend and configures SPA routing.

---

### Target B: Backend Deployment (Persistent VPS / Linux Server)

#### Option 1: PM2 Process Management

1. **Clone repository and install dependencies**:
   ```bash
   git clone https://github.com/YOUR_USERNAME/contentpilot-ai.git
   cd contentpilot-ai
   npm install
   ```

2. **Configure Environment**:
   ```bash
   cp .env.example backend/.env
   nano backend/.env
   ```

3. **Initialize Database & Build**:
   ```bash
   npm run prisma:generate --workspace=backend
   npm run build --workspace=backend
   ```

4. **Start Service with PM2**:
   ```bash
   npm install -g pm2
   pm2 start ecosystem.config.cjs
   pm2 save
   pm2 startup
   ```

5. **Verify Service Health**:
   ```bash
   curl http://127.0.0.1:3001/health
   curl http://127.0.0.1:3001/health/detailed
   ```

---

#### Option 2: Docker Compose

1. **Build and start containerized stack**:
   ```bash
   docker compose up -d --build
   ```

2. **Verify running containers**:
   ```bash
   docker compose ps
   docker compose logs -f contentpilot-backend
   ```

---

### 🌐 Nginx Reverse Proxy with HTTPS (Let's Encrypt)

1. Copy the included Nginx configuration:
   ```bash
   sudo cp nginx/contentpilot.conf /etc/nginx/sites-available/contentpilot.conf
   sudo nano /etc/nginx/sites-available/contentpilot.conf # Update domain name
   sudo ln -s /etc/nginx/sites-available/contentpilot.conf /etc/nginx/sites-enabled/
   ```

2. Issue SSL Certificate via Certbot:
   ```bash
   sudo certbot --nginx -d api.yourdomain.com
   sudo nginx -t && sudo systemctl reload nginx
   ```

---

## 🧪 Testing and Verification

Run comprehensive production validation tests:

```bash
# Generate Prisma Client
npm run prisma:generate

# Compile TypeScript
npm run build --workspaces

# Run unit and integration tests (72 deterministic tests)
npm run test
```

---

## 🛡️ Security Architecture

- **Zero Secret Exposure**: Keys and tokens are kept in backend server memory or AES-256 encrypted at rest.
- **SSRF Hardening**: External requests are checked against private IP ranges (`10.0.0.0/8`, `192.168.0.0/16`, AWS/GCP metadata services).
- **Path Traversal Protection**: All media queries validate paths against storage root boundaries using `SecurityGuard`.
- **Media Verification**: File magic numbers are inspected before file operations.
- **CORS Protection**: Access is restricted strictly to designated frontend domains in production.

---

## 📄 License

MIT License. Designed and engineered for production autonomous operations.

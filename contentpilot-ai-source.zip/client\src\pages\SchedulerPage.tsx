import React, { useEffect, useState } from 'react';
import { api } from '../services/api';
import { EmptyState } from '../components/EmptyState';
import { ChannelSettings } from '../types';
import { Calendar, Clock, Save, Trash2, Play, Lock, CheckCircle2 } from 'lucide-react';

interface SchedulerPageProps {
  channelId: string;
  onNavigate: (page: any) => void;
}

export const SchedulerPage: React.FC<SchedulerPageProps> = ({ channelId, onNavigate }) => {
  const [tasks, setTasks] = useState<any[]>([]);
  const [config, setConfig] = useState<ChannelSettings | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState<string | null>(null);

  // Form states
  const [automationEnabled, setAutomationEnabled] = useState(false);
  const [researchEnabled, setResearchEnabled] = useState(true);
  const [generationEnabled, setGenerationEnabled] = useState(true);
  const [autoPublishEnabled, setAutoPublishEnabled] = useState(false);
  const [cadence, setCadence] = useState('weekly');
  const [preferredTime, setPreferredTime] = useState('14:00');
  const [timezone, setTimezone] = useState('UTC');
  const [maxVideos, setMaxVideos] = useState(1);
  const [maxConcurrent, setMaxConcurrent] = useState(2);

  useEffect(() => {
    loadScheduler();
  }, [channelId]);

  const loadScheduler = async () => {
    try {
      setLoading(true);
      const [t, c] = await Promise.all([
        api.getSchedulerTasks(channelId),
        api.getSchedulerConfig(channelId),
      ]);
      setTasks(t);
      setConfig(c);
      setAutomationEnabled(c.automationEnabled);
      setResearchEnabled(c.researchEnabled);
      setGenerationEnabled(c.generationEnabled);
      setAutoPublishEnabled(c.autoPublishEnabled ?? false);
      setCadence(c.publishingCadence || 'weekly');
      setPreferredTime(c.preferredPublishTime || '14:00');
      setTimezone(c.timezone || 'UTC');
      setMaxVideos(c.maxVideosPerDay || 1);
      setMaxConcurrent(c.maxConcurrentJobs || 2);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleSaveConfig = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      setSaving(true);
      setMessage(null);
      await api.updateSchedulerConfig(channelId, {
        automationEnabled,
        researchEnabled,
        generationEnabled,
        autoPublishEnabled,
        publishingCadence: cadence,
        preferredPublishTime: preferredTime,
        timezone,
        maxVideosPerDay: Number(maxVideos),
        maxConcurrentJobs: Number(maxConcurrent),
      });
      setMessage('Scheduler configuration updated successfully.');
      await loadScheduler();
    } catch (err: any) {
      setMessage(`Save failed: ${err.message}`);
    } finally {
      setSaving(false);
    }
  };

  const handleDeleteTask = async (id: string) => {
    try {
      await api.deleteSchedulerTask(id);
      await loadScheduler();
    } catch (err) {
      console.error(err);
    }
  };

  const handleTick = async () => {
    try {
      const res = await api.triggerSchedulerTick();
      setMessage(`Scheduler tick triggered. Processed ${res.processedTasksCount} tasks.`);
      await loadScheduler();
    } catch (err: any) {
      setMessage(`Tick error: ${err.message}`);
    }
  };

  return (
    <div style={{ padding: '2rem' }}>
      <div className="page-header">
        <div>
          <h1 className="page-title">Persistent Task Scheduler</h1>
          <p className="page-description">
            SQLite-backed cron orchestration that survives crashes. Enforces strict human approval safeguards.
          </p>
        </div>
        <button className="btn btn-secondary" onClick={handleTick}>
          <Clock size={16} /> Run Manual Scheduler Tick
        </button>
      </div>

      {message && (
        <div className="badge badge-info" style={{ marginBottom: '1.25rem', padding: '8px 12px' }}>
          {message}
        </div>
      )}

      {loading ? (
        <p style={{ color: 'var(--text-muted)' }}>Loading scheduler...</p>
      ) : (
        <div style={{ display: 'grid', gridTemplateColumns: '1.2fr 1.8fr', gap: '1.5rem' }}>
          {/* Controls Form */}
          <div className="glass-panel" style={{ padding: '1.5rem' }}>
            <h3 style={{ fontSize: '1.1rem', fontWeight: 700, marginBottom: '1.25rem' }}>
              Automation & Cadence Controls
            </h3>
            <form onSubmit={handleSaveConfig} style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
              {/* Toggles */}
              <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
                <label style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', cursor: 'pointer' }}>
                  <span>Automation Master Switch</span>
                  <input
                    type="checkbox"
                    checked={automationEnabled}
                    onChange={(e) => setAutomationEnabled(e.target.checked)}
                  />
                </label>

                <label style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', cursor: 'pointer' }}>
                  <span>Automated Topic Research</span>
                  <input
                    type="checkbox"
                    checked={researchEnabled}
                    onChange={(e) => setResearchEnabled(e.target.checked)}
                  />
                </label>

                <label style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', cursor: 'pointer' }}>
                  <span>Automated Content Generation</span>
                  <input
                    type="checkbox"
                    checked={generationEnabled}
                    onChange={(e) => setGenerationEnabled(e.target.checked)}
                  />
                </label>

                <div
                  style={{
                    background: 'rgba(245, 158, 11, 0.08)',
                    padding: '10px',
                    borderRadius: '8px',
                    border: '1px solid rgba(245, 158, 11, 0.25)',
                  }}
                >
                  <label style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', cursor: 'pointer' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '6px', fontWeight: 700, color: '#fbbf24', fontSize: '0.85rem' }}>
                      <Lock size={14} /> Auto-Publish (Default: OFF)
                    </div>
                    <input
                      type="checkbox"
                      checked={autoPublishEnabled}
                      onChange={(e) => setAutoPublishEnabled(e.target.checked)}
                    />
                  </label>
                  <div style={{ fontSize: '0.72rem', color: 'var(--text-muted)', marginTop: '4px' }}>
                    When OFF, all generated videos must be explicitly approved in Review Studio.
                  </div>
                </div>
              </div>

              {/* Cadence Inputs */}
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.75rem' }}>
                <div>
                  <label style={{ fontSize: '0.75rem', color: 'var(--text-secondary)' }}>Publishing Cadence</label>
                  <select className="select" value={cadence} onChange={(e) => setCadence(e.target.value)}>
                    <option value="daily">Daily</option>
                    <option value="weekly">Weekly</option>
                    <option value="biweekly">Bi-Weekly</option>
                  </select>
                </div>

                <div>
                  <label style={{ fontSize: '0.75rem', color: 'var(--text-secondary)' }}>Preferred Time</label>
                  <input
                    type="time"
                    className="input"
                    value={preferredTime}
                    onChange={(e) => setPreferredTime(e.target.value)}
                  />
                </div>
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.75rem' }}>
                <div>
                  <label style={{ fontSize: '0.75rem', color: 'var(--text-secondary)' }}>Max Videos / Day</label>
                  <input
                    type="number"
                    min="1"
                    max="10"
                    className="input"
                    value={maxVideos}
                    onChange={(e) => setMaxVideos(Number(e.target.value))}
                  />
                </div>

                <div>
                  <label style={{ fontSize: '0.75rem', color: 'var(--text-secondary)' }}>Concurrent Jobs</label>
                  <input
                    type="number"
                    min="1"
                    max="5"
                    className="input"
                    value={maxConcurrent}
                    onChange={(e) => setMaxConcurrent(Number(e.target.value))}
                  />
                </div>
              </div>

              <button type="submit" className="btn btn-primary" disabled={saving}>
                <Save size={16} /> {saving ? 'Saving...' : 'Save Configuration'}
              </button>
            </form>
          </div>

          {/* Persistent Scheduled Tasks Table */}
          <div className="glass-panel" style={{ padding: '1.5rem' }}>
            <h3 style={{ fontSize: '1.1rem', fontWeight: 700, marginBottom: '1rem' }}>
              Persistent Scheduled Tasks ({tasks.length})
            </h3>
            {tasks.length === 0 ? (
              <EmptyState
                title="No tasks scheduled."
                message="Scheduled recurring jobs (research, rendering, analytics sync) will appear here."
              />
            ) : (
              <div className="table-container">
                <table className="table">
                  <thead>
                    <tr>
                      <th>Task</th>
                      <th>Type</th>
                      <th>Schedule</th>
                      <th>Next Run</th>
                      <th>Runs</th>
                      <th>Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    {tasks.map((task) => (
                      <tr key={task.id}>
                        <td style={{ fontWeight: 600 }}>{task.name}</td>
                        <td style={{ fontSize: '0.78rem' }}>
                          <span className="badge badge-info">{task.taskType}</span>
                        </td>
                        <td style={{ fontSize: '0.8rem' }}>{task.scheduleType}</td>
                        <td style={{ fontSize: '0.78rem', color: 'var(--text-muted)' }}>
                          {task.nextRunAt ? new Date(task.nextRunAt).toLocaleString() : 'N/A'}
                        </td>
                        <td style={{ fontSize: '0.8rem' }}>{task.runCount}</td>
                        <td>
                          <button
                            className="btn btn-danger"
                            style={{ padding: '3px 8px', fontSize: '0.72rem' }}
                            onClick={() => handleDeleteTask(task.id)}
                          >
                            <Trash2 size={12} />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

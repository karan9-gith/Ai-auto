import fs from 'node:fs';
import { prisma } from '../../database/client.js';
import { logger } from '../../utils/logger.js';
import { AppError } from '../../utils/errors.js';
import { preUploadSafetyChecker } from './preUploadSafetyCheck.js';
import { youtubeAuthService } from './youtubeAuth.js';
import { autoFixEngine } from '../autofix/autoFixEngine.js';
import { pipelineStateMachine } from '../../core/pipeline/stateMachine.js';
import { VideoPipelineState } from '../../core/pipeline/stateTypes.js';
import { config } from '../../config/index.js';
import {
  UploadLifecycleStatus,
  UploadOptions,
  UploadProgress,
  PublishedVideoResult,
} from './types.js';

export class YouTubeUploadEngine {
  /**
   * Execute an idempotent, pre-safety-checked YouTube upload
   */
  public async upload(
    options: UploadOptions,
    onProgress?: (progress: UploadProgress) => void
  ): Promise<PublishedVideoResult> {
    const { projectId, channelId } = options;
    const idempotencyKey =
      options.idempotencyKey || `upload_${projectId}_${Date.now()}`;

    // ==========================================
    // 1. DUPLICATE PREVENTION & IDEMPOTENCY CHECK
    // ==========================================
    const existingPublished = await prisma.youTubeVideo.findFirst({
      where: { projectId },
    });

    if (existingPublished) {
      logger.info({
        msg: 'Video already published; returning idempotent result to prevent duplication',
        projectId,
        youtubeVideoId: existingPublished.youtubeVideoId,
      });

      return {
        youtubeVideoId: existingPublished.youtubeVideoId,
        youtubeUrl: existingPublished.youtubeUrl,
        title: existingPublished.title,
        privacyStatus: existingPublished.privacyStatus,
        publishedAt: existingPublished.publishedAt,
        idempotencyKey,
      };
    }

    // ==========================================
    // 2. MANDATORY PRE-UPLOAD SAFETY CHECK
    // ==========================================
    await preUploadSafetyChecker.verify(projectId);

    // ==========================================
    // 3. RETRIEVE ARTIFACTS
    // ==========================================
    const project = await prisma.videoProject.findUnique({
      where: { id: projectId },
      include: {
        renders: { where: { status: 'completed' }, take: 1, orderBy: { createdAt: 'desc' } },
        seoPackage: true,
        thumbnail: { include: { variants: true } },
      },
    });

    if (!project || !project.renders[0] || !project.seoPackage) {
      throw new AppError('Incomplete project artifacts for upload', 400, 'ARTIFACTS_INCOMPLETE');
    }

    const render = project.renders[0];
    const seo = project.seoPackage;
    const selectedVariant =
      project.thumbnail?.variants.find((v) => v.isSelected) ||
      project.thumbnail?.variants[0];

    // ==========================================
    // 4. QUEUE & UPLOAD RECORD INITIALIZATION
    // ==========================================
    const queueItem = await prisma.publishingQueue.upsert({
      where: { projectId },
      update: {
        status: 'QUEUED',
        uploadAttempts: { increment: 1 },
        lastError: null,
      },
      create: {
        projectId,
        channelId,
        idempotencyKey,
        privacyStatus: options.privacyStatus || config.DEFAULT_YOUTUBE_PRIVACY || 'public',
        scheduledPublishTime: options.scheduledPublishTime || null,
        status: 'QUEUED',
        uploadAttempts: 1,
      },
    });

    const uploadRecord = await prisma.youTubeUpload.create({
      data: {
        publishingQueueId: queueItem.id,
        projectId,
        uploadStatus: 'initiated',
        idempotencyKey,
        bytesUploaded: 0,
        totalBytes: render.fileSize,
      },
    });

    await pipelineStateMachine.transition(
      projectId,
      VideoPipelineState.UPLOADING,
      'system',
      { idempotencyKey }
    );

    // ==========================================
    // 5. COMMENCE UPLOAD
    // ==========================================
    try {
      await prisma.publishingQueue.update({
        where: { id: queueItem.id },
        data: { status: 'UPLOADING' },
      });

      const { youtube } = await youtubeAuthService.getAuthenticatedClient(channelId);

      const privacy = options.privacyStatus || config.DEFAULT_YOUTUBE_PRIVACY || 'public';
      const isScheduled = !!options.scheduledPublishTime && privacy === 'private';

      // Parse tags
      let parsedTags: string[] = [];
      try {
        parsedTags = JSON.parse(seo.tagsJson || '[]');
      } catch {
        parsedTags = [];
      }

      const requestBody: {
        snippet: {
          title: string;
          description: string;
          tags: string[];
          categoryId: string;
        };
        status: {
          privacyStatus: string;
          selfDeclaredMadeForKids: boolean;
          publishAt?: string;
        };
      } = {
        snippet: {
          title: seo.recommendedTitle,
          description: seo.description,
          tags: parsedTags,
          categoryId: '27', // Default: Education
        },
        status: {
          privacyStatus: isScheduled ? 'private' : privacy,
          selfDeclaredMadeForKids: false,
          ...(isScheduled && {
            publishAt: options.scheduledPublishTime?.toISOString(),
          }),
        },
      };

      // Create readable stream for video file
      const fileSize = render.fileSize;
      const fileStream = fs.createReadStream(render.outputPath);

      // Perform resumable upload with progress events
      const res = await youtube.videos.insert(
        {
          part: ['snippet', 'status'],
          requestBody,
          media: {
            body: fileStream,
          },
        },
        {
          onUploadProgress: (evt) => {
            const bytesRead = evt.bytesRead || 0;
            const pct = Math.min(100, Math.round((bytesRead / fileSize) * 100));

            onProgress?.({
              bytesUploaded: bytesRead,
              totalBytes: fileSize,
              percentage: pct,
              status: 'UPLOADING',
            });

            // Periodically sync upload progress to DB
            if (pct % 25 === 0) {
              prisma.youTubeUpload
                .update({
                  where: { id: uploadRecord.id },
                  data: { bytesUploaded: bytesRead },
                })
                .catch(() => {});
            }
          },
        }
      );

      const uploadedVideo = res.data;
      if (!uploadedVideo || !uploadedVideo.id) {
        throw new AppError('YouTube upload did not return a valid video ID', 502, 'YOUTUBE_API_ERROR');
      }

      const youtubeVideoId = uploadedVideo.id;
      const youtubeUrl = `https://www.youtube.com/watch?v=${youtubeVideoId}`;

      // ==========================================
      // 6. UPLOAD THUMBNAIL IF PRESENT
      // ==========================================
      if (selectedVariant && selectedVariant.assetPath && fs.existsSync(selectedVariant.assetPath)) {
        try {
          await youtube.thumbnails.set({
            videoId: youtubeVideoId,
            media: {
              body: fs.createReadStream(selectedVariant.assetPath),
            },
          });
          logger.info({ msg: 'Successfully set YouTube thumbnail', videoId: youtubeVideoId });
        } catch (thumbErr) {
          logger.warn({ msg: 'Thumbnail upload failed (non-blocking)', error: thumbErr });
        }
      }

      // ==========================================
      // 7. PLAYLIST MANAGEMENT IF REQUESTED
      // ==========================================
      if (options.playlistId) {
        try {
          await youtube.playlistItems.insert({
            part: ['snippet'],
            requestBody: {
              snippet: {
                playlistId: options.playlistId,
                resourceId: {
                  kind: 'youtube#video',
                  videoId: youtubeVideoId,
                },
              },
            },
          });
          logger.info({ msg: 'Added video to playlist', playlistId: options.playlistId });
        } catch (playlistErr) {
          logger.warn({ msg: 'Playlist addition failed (non-blocking)', error: playlistErr });
        }
      }

      // ==========================================
      // 8. FINALIZE STATUS & PERSIST
      // ==========================================
      const finalYtVideo = await prisma.youTubeVideo.upsert({
        where: { youtubeVideoId },
        update: {
          title: seo.recommendedTitle,
          description: seo.description,
          tagsJson: seo.tagsJson,
          privacyStatus: privacy,
        },
        create: {
          projectId,
          channelId,
          youtubeVideoId,
          youtubeUrl,
          title: seo.recommendedTitle,
          description: seo.description,
          tagsJson: seo.tagsJson,
          privacyStatus: privacy,
          publishedAt: new Date(),
        },
      });

      await prisma.publishingQueue.update({
        where: { id: queueItem.id },
        data: { status: 'PUBLISHED' },
      });

      await prisma.youTubeUpload.update({
        where: { id: uploadRecord.id },
        data: {
          uploadStatus: 'completed',
          bytesUploaded: fileSize,
          completedAt: new Date(),
        },
      });

      await pipelineStateMachine.transition(
        projectId,
        VideoPipelineState.PUBLISHED,
        'system',
        { youtubeVideoId, youtubeUrl }
      );

      await prisma.auditLog.create({
        data: {
          channelId,
          entityType: 'publishing',
          entityId: projectId,
          action: 'PUBLISH_SUCCESS',
          afterJson: JSON.stringify({ youtubeVideoId, youtubeUrl, privacyStatus: privacy }),
          timestamp: new Date(),
        },
      });

      logger.info({
        msg: 'Successfully published video to YouTube',
        projectId,
        youtubeVideoId,
        youtubeUrl,
      });

      return {
        youtubeVideoId,
        youtubeUrl,
        title: seo.recommendedTitle,
        privacyStatus: privacy,
        publishedAt: finalYtVideo.publishedAt,
        idempotencyKey,
      };
    } catch (uploadError) {
      const errorMsg = uploadError instanceof Error ? uploadError.message : String(uploadError);
      const diagnosis = autoFixEngine.classifyError(uploadError);

      await prisma.publishingQueue.update({
        where: { id: queueItem.id },
        data: {
          status: 'FAILED',
          lastError: errorMsg,
        },
      });

      await prisma.youTubeUpload.update({
        where: { id: uploadRecord.id },
        data: {
          uploadStatus: 'aborted',
          error: errorMsg,
        },
      });

      await autoFixEngine.recordAutoFix({
        projectId,
        error: errorMsg,
        classification: diagnosis.classification,
        diagnosis: diagnosis.diagnosis,
        fixApplied: diagnosis.suggestedFix || 'Upload failure recorded',
        result: diagnosis.isRecoverable ? 'ESCALATED' : 'FAILED',
        retryCount: queueItem.uploadAttempts,
      });

      logger.error({
        msg: 'YouTube upload failed',
        projectId,
        error: errorMsg,
        classification: diagnosis.classification,
      });

      throw uploadError;
    }
  }

  /**
   * Check YouTube video processing status
   */
  public async getVideoStatus(channelId: string, youtubeVideoId: string) {
    const { youtube } = await youtubeAuthService.getAuthenticatedClient(channelId);
    const res = await youtube.videos.list({
      part: ['status', 'snippet', 'contentDetails', 'statistics'],
      id: [youtubeVideoId],
    });

    const item = res.data.items?.[0];
    if (!item) {
      throw new AppError(`Video '${youtubeVideoId}' not found on YouTube`, 404, 'VIDEO_NOT_FOUND');
    }

    return {
      id: item.id,
      title: item.snippet?.title,
      uploadStatus: item.status?.uploadStatus, // uploaded, processed, failed, rejected
      privacyStatus: item.status?.privacyStatus,
      rejectionReason: item.status?.rejectionReason,
      viewCount: item.statistics?.viewCount ? parseInt(item.statistics.viewCount, 10) : 0,
    };
  }

  /**
   * Update video metadata on YouTube
   */
  public async updateMetadata(
    channelId: string,
    youtubeVideoId: string,
    metadata: { title?: string; description?: string; tags?: string[]; categoryId?: string }
  ) {
    const { youtube } = await youtubeAuthService.getAuthenticatedClient(channelId);

    // First fetch existing snippet
    const existing = await youtube.videos.list({
      part: ['snippet'],
      id: [youtubeVideoId],
    });

    const snippet = existing.data.items?.[0]?.snippet;
    if (!snippet) {
      throw new AppError(`Video '${youtubeVideoId}' not found on YouTube`, 404, 'VIDEO_NOT_FOUND');
    }

    const updated = await youtube.videos.update({
      part: ['snippet'],
      requestBody: {
        id: youtubeVideoId,
        snippet: {
          ...snippet,
          title: metadata.title ?? snippet.title,
          description: metadata.description ?? snippet.description,
          tags: metadata.tags ?? snippet.tags,
          categoryId: metadata.categoryId ?? snippet.categoryId,
        },
      },
    });

    return updated.data;
  }
}

export const youtubeUploadEngine = new YouTubeUploadEngine();

import { PrismaClient } from '@prisma/client';
import { logger } from '../utils/logger.js';

// Global singleton instance for Prisma
const globalForPrisma = globalThis as unknown as { prisma: PrismaClient | undefined };

export const prisma =
  globalForPrisma.prisma ??
  new PrismaClient({
    log: [
      { emit: 'event', level: 'query' },
      { emit: 'event', level: 'error' },
      { emit: 'event', level: 'info' },
      { emit: 'event', level: 'warn' },
    ],
  });

if (process.env.NODE_ENV !== 'production') {
  globalForPrisma.prisma = prisma;
}

// Log query and error events in development mode
prisma.$on('error' as never, (e: { message: string }) => {
  logger.error({ msg: 'Prisma Client Database Error', error: e.message });
});

/**
 * Configure SQLite PRAGMAs for concurrency and durability
 */
export async function initializeDatabasePragmas(): Promise<void> {
  try {
    await prisma.$executeRawUnsafe(`PRAGMA journal_mode = WAL;`);
    await prisma.$executeRawUnsafe(`PRAGMA synchronous = NORMAL;`);
    await prisma.$executeRawUnsafe(`PRAGMA foreign_keys = ON;`);
    await prisma.$executeRawUnsafe(`PRAGMA busy_timeout = 5000;`);
    logger.info('SQLite Pragmas applied: WAL mode enabled, foreign keys ON, busy_timeout 5000ms');
  } catch (error) {
    logger.error({ msg: 'Failed to configure SQLite Pragmas', error });
  }
}

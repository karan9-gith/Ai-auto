export type JobStatus = 'pending' | 'running' | 'completed' | 'failed' | 'cancelled';

export interface BaseJobPayload {
  productionId?: string;
  stage?: string;
  triggeredBy: string;
}

export interface PipelineExecutionJobPayload extends BaseJobPayload {
  productionId: string;
  targetStages?: string[];
  forceRegenerate?: boolean;
}

export interface VideoRenderJobPayload extends BaseJobPayload {
  productionId: string;
  sceneIndices?: number[];
  resolution?: '1080p' | '720p';
}

export interface YouTubeUploadJobPayload extends BaseJobPayload {
  productionId: string;
  publishTime?: string;
  privacyStatus: 'private' | 'unlisted' | 'public';
}

export interface JobDefinition<T extends BaseJobPayload = BaseJobPayload> {
  id: string;
  type: string;
  payload: T;
  status: JobStatus;
  priority: number;
  attempts: number;
  maxAttempts: number;
  lastError?: string;
  lockedBy?: string;
  lastHeartbeat?: Date;
  scheduledFor: Date;
  completedAt?: Date;
  createdAt: Date;
  updatedAt: Date;
}

import React, { useEffect, useState } from 'react';
import { api } from '../services/api';
import { EmptyState } from '../components/EmptyState';
import { FileText, Edit3, Save, CheckCircle2, History, ShieldAlert } from 'lucide-react';

interface ScriptsPageProps {
  channelId: string;
  onNavigate: (page: any) => void;
}

export const ScriptsPage: React.FC<ScriptsPageProps> = ({ channelId, onNavigate }) => {
  const [scripts, setScripts] = useState<any[]>([]);
  const [selectedScript, setSelectedScript] = useState<any | null>(null);
  const [loading, setLoading] = useState(true);
  const [isEditing, setIsEditing] = useState(false);
  const [editedTitle, setEditedTitle] = useState('');
  const [editedHook, setEditedHook] = useState('');
  const [editedCta, setEditedCta] = useState('');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    loadScripts();
  }, [channelId]);

  const loadScripts = async () => {
    try {
      setLoading(true);
      const data = await api.getScripts(channelId);
      setScripts(data);
      if (data.length > 0) {
        await loadScriptDetails(data[0].id);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const loadScriptDetails = async (id: string) => {
    try {
      const full = await api.getScript(id);
      setSelectedScript(full);
      setEditedTitle(full.title);
      setEditedHook(full.hookText);
      setEditedCta(full.ctaText);
      setIsEditing(false);
    } catch (err) {
      console.error(err);
    }
  };

  const handleSave = async () => {
    if (!selectedScript) return;
    try {
      setSaving(true);
      const res = await api.updateScript(selectedScript.id, {
        title: editedTitle,
        hookText: editedHook,
        ctaText: editedCta,
        changeSummary: 'Editorial refinement from dashboard',
      });
      await loadScriptDetails(selectedScript.id);
      setIsEditing(false);
    } catch (err) {
      console.error(err);
    } finally {
      setSaving(false);
    }
  };

  let parsedSections: any[] = [];
  try {
    if (selectedScript?.sectionsJson) {
      parsedSections = JSON.parse(selectedScript.sectionsJson);
    }
  } catch {}

  return (
    <div style={{ padding: '2rem' }}>
      <div className="page-header">
        <div>
          <h1 className="page-title">Script Studio & Fact Verification</h1>
          <p className="page-description">
            Full narrative pacing, factual claim auditing, and immutable version tracking.
          </p>
        </div>
        {selectedScript && (
          <div style={{ display: 'flex', gap: '0.75rem' }}>
            {isEditing ? (
              <button className="btn btn-primary" onClick={handleSave} disabled={saving}>
                <Save size={16} /> {saving ? 'Saving...' : 'Save New Version'}
              </button>
            ) : (
              <button className="btn btn-secondary" onClick={() => setIsEditing(true)}>
                <Edit3 size={16} /> Edit Script
              </button>
            )}
          </div>
        )}
      </div>

      {loading ? (
        <p style={{ color: 'var(--text-muted)' }}>Loading scripts...</p>
      ) : scripts.length === 0 ? (
        <EmptyState
          title="No scripts generated yet."
          message="Run the Autonomous Operator or generate a script from a strategy to inspect narrative sections."
          actionText="Run Operator"
          onAction={() => onNavigate('operator')}
        />
      ) : (
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 2.5fr', gap: '1.5rem' }}>
          {/* Scripts list */}
          <div className="glass-panel" style={{ padding: '1rem', maxHeight: '75vh', overflowY: 'auto' }}>
            <h3 style={{ fontSize: '0.85rem', color: 'var(--text-secondary)', marginBottom: '0.75rem', textTransform: 'uppercase' }}>
              Channel Scripts ({scripts.length})
            </h3>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
              {scripts.map((s) => {
                const isSelected = selectedScript?.id === s.id;
                return (
                  <div
                    key={s.id}
                    onClick={() => loadScriptDetails(s.id)}
                    style={{
                      padding: '0.85rem',
                      borderRadius: '8px',
                      background: isSelected ? 'rgba(59, 130, 246, 0.15)' : 'var(--bg-surface-elevated)',
                      border: `1px solid ${isSelected ? '#3b82f6' : 'var(--border-subtle)'}`,
                      cursor: 'pointer',
                    }}
                  >
                    <div style={{ fontWeight: 700, fontSize: '0.9rem' }}>{s.title}</div>
                    <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', marginTop: '4px' }}>
                      Version {s.currentVersion || 1} • {s.wordCount} words • ~{Math.round(s.estimatedDurationSec / 60)} min
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Script Editor / Reader */}
          {selectedScript && (
            <div className="glass-panel" style={{ padding: '1.75rem' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1.5rem' }}>
                <div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '6px' }}>
                    <span className="badge badge-info">v{selectedScript.currentVersion}</span>
                    <span className="badge badge-success">{selectedScript.status}</span>
                  </div>
                  {isEditing ? (
                    <input
                      className="input"
                      value={editedTitle}
                      onChange={(e) => setEditedTitle(e.target.value)}
                      style={{ fontSize: '1.25rem', fontWeight: 800 }}
                    />
                  ) : (
                    <h2 style={{ fontSize: '1.35rem', fontWeight: 800 }}>{selectedScript.title}</h2>
                  )}
                </div>

                <div style={{ textAlign: 'right', fontSize: '0.8rem', color: 'var(--text-muted)' }}>
                  <div>{selectedScript.wordCount} words</div>
                  <div>~{Math.round(selectedScript.estimatedDurationSec / 60)} minutes</div>
                </div>
              </div>

              {/* Hook Section */}
              <div style={{ background: 'rgba(59, 130, 246, 0.08)', border: '1px solid rgba(59, 130, 246, 0.25)', borderRadius: '8px', padding: '1rem', marginBottom: '1.5rem' }}>
                <div style={{ fontSize: '0.75rem', color: '#60a5fa', fontWeight: 700, marginBottom: '6px' }}>
                  HOOK (0:00 - 0:{selectedScript.hookDurationSec?.toFixed(0) || '10'})
                </div>
                {isEditing ? (
                  <textarea
                    className="textarea"
                    value={editedHook}
                    onChange={(e) => setEditedHook(e.target.value)}
                    style={{ minHeight: '60px' }}
                  />
                ) : (
                  <p style={{ fontSize: '0.95rem', lineHeight: 1.5, fontWeight: 500 }}>{selectedScript.hookText}</p>
                )}
                <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', marginTop: '6px' }}>
                  Visual Cue: <em>{selectedScript.hookVisualCue}</em>
                </div>
              </div>

              {/* Main Content Sections */}
              <div style={{ marginBottom: '1.5rem' }}>
                <h3 style={{ fontSize: '1rem', fontWeight: 700, marginBottom: '0.75rem' }}>Narrative Sections</h3>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
                  {parsedSections.map((sec, idx) => (
                    <div key={idx} className="glass-card" style={{ padding: '1rem' }}>
                      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '4px' }}>
                        <span style={{ fontSize: '0.75rem', fontWeight: 700, color: 'var(--text-secondary)' }}>
                          {sec.type || 'SECTION'} {idx + 1}: {sec.title}
                        </span>
                      </div>
                      <p style={{ fontSize: '0.9rem', lineHeight: 1.6, color: 'var(--text-primary)' }}>
                        {sec.narration}
                      </p>
                      {sec.visualCue && (
                        <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', marginTop: '8px' }}>
                          Visual Prompt: <em>{sec.visualCue}</em>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>

              {/* CTA & Outro */}
              <div style={{ background: 'var(--bg-surface-elevated)', borderRadius: '8px', padding: '1rem' }}>
                <div style={{ fontSize: '0.75rem', color: 'var(--text-secondary)', fontWeight: 700, marginBottom: '4px' }}>
                  CALL TO ACTION & OUTRO
                </div>
                {isEditing ? (
                  <textarea
                    className="textarea"
                    value={editedCta}
                    onChange={(e) => setEditedCta(e.target.value)}
                    style={{ minHeight: '60px' }}
                  />
                ) : (
                  <p style={{ fontSize: '0.875rem', lineHeight: 1.5 }}>{selectedScript.ctaText}</p>
                )}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

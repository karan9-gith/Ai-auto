import React, { useEffect, useState } from 'react';
import { api } from '../services/api';
import { Channel } from '../types';
import { Settings, Save, ShieldCheck, Lock, Plus } from 'lucide-react';

interface SettingsPageProps {
  channelId: string;
  onRefreshChannels: () => void;
}

export const SettingsPage: React.FC<SettingsPageProps> = ({ channelId, onRefreshChannels }) => {
  const [channel, setChannel] = useState<Channel | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState<string | null>(null);

  // Form states
  const [name, setName] = useState('');
  const [niche, setNiche] = useState('');
  const [audience, setAudience] = useState('');
  const [brandVoice, setBrandVoice] = useState('');
  const [visualStyle, setVisualStyle] = useState('');
  const [language, setLanguage] = useState('en');
  const [timezone, setTimezone] = useState('UTC');
  const [bannedTopics, setBannedTopics] = useState('');
  const [contentPillars, setContentPillars] = useState('');

  // Create channel form
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [newChanName, setNewChanName] = useState('');
  const [newChanNiche, setNewChanNiche] = useState('');

  useEffect(() => {
    loadSettings();
  }, [channelId]);

  const loadSettings = async () => {
    try {
      setLoading(true);
      const data = await api.getChannelSettings(channelId);
      setChannel(data);
      setName(data.name);
      setNiche(data.niche);
      setAudience(data.targetAudience);
      setBrandVoice(data.brandVoice);
      setVisualStyle(data.visualStyle);
      setLanguage(data.defaultLanguage);
      setTimezone(data.timezone);
      setBannedTopics(data.settings?.bannedTopics || '[]');
      setContentPillars(data.settings?.contentPillars || '[]');
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      setSaving(true);
      setMessage(null);

      let parsedBanned = [];
      let parsedPillars = [];
      try {
        parsedBanned = JSON.parse(bannedTopics);
      } catch {
        parsedBanned = bannedTopics.split(',').map((s) => s.trim()).filter(Boolean);
      }
      try {
        parsedPillars = JSON.parse(contentPillars);
      } catch {
        parsedPillars = contentPillars.split(',').map((s) => s.trim()).filter(Boolean);
      }

      await api.updateChannelSettings(channelId, {
        name,
        niche,
        targetAudience: audience,
        brandVoice,
        visualStyle,
        defaultLanguage: language,
        timezone,
        settings: {
          bannedTopics: parsedBanned,
          contentPillars: parsedPillars,
        },
      });

      setMessage('Settings updated successfully.');
      onRefreshChannels();
      await loadSettings();
    } catch (err: any) {
      setMessage(`Save failed: ${err.message}`);
    } finally {
      setSaving(false);
    }
  };

  const handleCreateChannel = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await api.createChannel({ name: newChanName, niche: newChanNiche });
      setShowCreateModal(false);
      setNewChanName('');
      setNewChanNiche('');
      onRefreshChannels();
    } catch (err: any) {
      alert(`Create channel failed: ${err.message}`);
    }
  };

  return (
    <div style={{ padding: '2rem' }}>
      <div className="page-header">
        <div>
          <h1 className="page-title">Channel Brand & Editorial Guardrails</h1>
          <p className="page-description">
            Define tone of voice, visual identity constraints, prohibited topics, and content pillars.
          </p>
        </div>
        <button className="btn btn-secondary" onClick={() => setShowCreateModal(true)}>
          <Plus size={16} /> New Channel Workspace
        </button>
      </div>

      {message && (
        <div className="badge badge-info" style={{ marginBottom: '1.25rem', padding: '8px 12px' }}>
          {message}
        </div>
      )}

      {loading ? (
        <p style={{ color: 'var(--text-muted)' }}>Loading settings...</p>
      ) : (
        <form onSubmit={handleSave} className="glass-panel" style={{ padding: '1.75rem', maxWidth: '800px' }}>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
              <div>
                <label style={{ fontSize: '0.8rem', color: 'var(--text-secondary)' }}>Channel Name</label>
                <input className="input" style={{ marginTop: '4px' }} value={name} onChange={(e) => setName(e.target.value)} required />
              </div>
              <div>
                <label style={{ fontSize: '0.8rem', color: 'var(--text-secondary)' }}>Primary Niche</label>
                <input className="input" style={{ marginTop: '4px' }} value={niche} onChange={(e) => setNiche(e.target.value)} required />
              </div>
            </div>

            <div>
              <label style={{ fontSize: '0.8rem', color: 'var(--text-secondary)' }}>Target Audience Persona</label>
              <input className="input" style={{ marginTop: '4px' }} value={audience} onChange={(e) => setAudience(e.target.value)} required />
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
              <div>
                <label style={{ fontSize: '0.8rem', color: 'var(--text-secondary)' }}>Brand Voice & Tone</label>
                <input className="input" style={{ marginTop: '4px' }} value={brandVoice} onChange={(e) => setBrandVoice(e.target.value)} required />
              </div>
              <div>
                <label style={{ fontSize: '0.8rem', color: 'var(--text-secondary)' }}>Visual Style & Aesthetics</label>
                <input className="input" style={{ marginTop: '4px' }} value={visualStyle} onChange={(e) => setVisualStyle(e.target.value)} required />
              </div>
            </div>

            <div>
              <label style={{ fontSize: '0.8rem', color: 'var(--text-secondary)' }}>Content Pillars (JSON array or comma-separated)</label>
              <textarea className="textarea" style={{ marginTop: '4px', minHeight: '60px' }} value={contentPillars} onChange={(e) => setContentPillars(e.target.value)} />
            </div>

            <div>
              <label style={{ fontSize: '0.8rem', color: 'var(--text-secondary)' }}>Banned Topics & Prohibited Keywords</label>
              <textarea className="textarea" style={{ marginTop: '4px', minHeight: '60px' }} value={bannedTopics} onChange={(e) => setBannedTopics(e.target.value)} placeholder="e.g. gambling, crypto hype, unverified medical claims" />
            </div>

            <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: '0.5rem' }}>
              <button type="submit" className="btn btn-primary" disabled={saving}>
                <Save size={16} /> {saving ? 'Saving...' : 'Save Settings'}
              </button>
            </div>
          </div>
        </form>
      )}

      {/* Modal to create channel workspace */}
      {showCreateModal && (
        <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.7)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 100 }}>
          <div className="glass-panel" style={{ width: '420px', padding: '1.75rem', background: 'var(--bg-surface)' }}>
            <h3 style={{ fontSize: '1.2rem', fontWeight: 800, marginBottom: '1rem' }}>Create Channel Workspace</h3>
            <form onSubmit={handleCreateChannel} style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
              <div>
                <label style={{ fontSize: '0.8rem', color: 'var(--text-secondary)' }}>Channel Name</label>
                <input className="input" value={newChanName} onChange={(e) => setNewChanName(e.target.value)} required placeholder="e.g. AI Frontier" />
              </div>
              <div>
                <label style={{ fontSize: '0.8rem', color: 'var(--text-secondary)' }}>Niche</label>
                <input className="input" value={newChanNiche} onChange={(e) => setNewChanNiche(e.target.value)} required placeholder="e.g. Artificial Intelligence" />
              </div>
              <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '0.75rem', marginTop: '0.5rem' }}>
                <button type="button" className="btn btn-secondary" onClick={() => setShowCreateModal(false)}>Cancel</button>
                <button type="submit" className="btn btn-primary">Create Channel</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

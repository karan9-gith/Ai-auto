import { Router, Request, Response, NextFunction } from 'express';
import { prisma } from '../database/client.js';

const router = Router();

// GET system logs
router.get('/system', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const level = req.query.level as string | undefined;
    const limit = Math.min(Number(req.query.limit || 50), 200);

    const logs = await prisma.systemLog.findMany({
      where: level ? { level } : undefined,
      orderBy: { timestamp: 'desc' },
      take: limit,
    });

    res.json({ success: true, count: logs.length, data: logs });
  } catch (err) {
    next(err);
  }
});

// GET audit logs
router.get('/audit', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const channelId = req.query.channelId as string | undefined;
    const action = req.query.action as string | undefined;
    const limit = Math.min(Number(req.query.limit || 50), 200);

    const logs = await prisma.auditLog.findMany({
      where: {
        ...(channelId ? { channelId } : {}),
        ...(action ? { action } : {}),
      },
      include: { user: { select: { name: true, email: true } } },
      orderBy: { timestamp: 'desc' },
      take: limit,
    });

    res.json({ success: true, count: logs.length, data: logs });
  } catch (err) {
    next(err);
  }
});

// GET auto-fix error recovery logs
router.get('/autofix', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const classification = req.query.classification as string | undefined;
    const limit = Math.min(Number(req.query.limit || 50), 200);

    const logs = await prisma.autoFixLog.findMany({
      where: classification ? { classification } : undefined,
      orderBy: { timestamp: 'desc' },
      take: limit,
    });

    res.json({ success: true, count: logs.length, data: logs });
  } catch (err) {
    next(err);
  }
});

export default router;

import React, { useEffect, useState } from 'react';
import { api } from '../services/api';
import { EmptyState } from '../components/EmptyState';
import { UploadCloud, Clock, Key, AlertCircle, XCircle, RotateCcw } from 'lucide-react';

interface PublishingQueuePageProps {
  channelId: string;
  onNavigate: (page: any) => void;
}

export const PublishingQueuePage: React.FC<PublishingQueuePageProps> = ({ channelId, onNavigate }) => {
  const [items, setItems] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [message, setMessage] = useState<string | null>(null);

  useEffect(() => {
    loadQueue();
  }, [channelId]);

  const loadQueue = async () => {
    try {
      setLoading(true);
      const data = await api.getPublishingQueue(channelId);
      setItems(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleCancel = async (id: string) => {
    try {
      await api.cancelPublishing(id);
      setMessage('Publishing task cancelled.');
      await loadQueue();
    } catch (err: any) {
      setMessage(`Cancel error: ${err.message}`);
    }
  };

  const handleRetry = async (id: string) => {
    try {
      await api.retryPublishing(id);
      setMessage('Task queued for retry.');
      await loadQueue();
    } catch (err: any) {
      setMessage(`Retry error: ${err.message}`);
    }
  };

  return (
    <div style={{ padding: '2rem' }}>
      <div className="page-header">
        <div>
          <h1 className="page-title">Publishing & Upload Queue</h1>
          <p className="page-description">
            Idempotent release orchestrator with resumable chunk uploads and duplicate prevention.
          </p>
        </div>
      </div>

      {message && (
        <div className="badge badge-info" style={{ marginBottom: '1rem', padding: '8px 12px' }}>
          {message}
        </div>
      )}

      {loading ? (
        <p style={{ color: 'var(--text-muted)' }}>Loading publishing queue...</p>
      ) : items.length === 0 ? (
        <EmptyState
          title="No queued uploads."
          message="Approved videos scheduled for YouTube release will appear here."
        />
      ) : (
        <div className="table-container">
          <table className="table">
            <thead>
              <tr>
                <th>Project Title</th>
                <th>Status</th>
                <th>Scheduled Time</th>
                <th>Privacy</th>
                <th>Attempts</th>
                <th>Idempotency Key</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {items.map((item) => (
                <tr key={item.id}>
                  <td style={{ fontWeight: 600 }}>{item.project?.title || item.projectId}</td>
                  <td>
                    <span
                      className={`badge ${
                        item.status === 'PUBLISHED'
                          ? 'badge-success'
                          : item.status === 'FAILED'
                          ? 'badge-danger'
                          : item.status === 'PUBLISHING'
                          ? 'badge-info'
                          : 'badge-warning'
                      }`}
                    >
                      {item.status}
                    </span>
                  </td>
                  <td style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>
                    {item.scheduledPublishTime ? new Date(item.scheduledPublishTime).toLocaleString() : 'Immediate'}
                  </td>
                  <td style={{ fontSize: '0.8rem', textTransform: 'uppercase' }}>{item.privacyStatus}</td>
                  <td style={{ fontSize: '0.8rem' }}>{item.uploadAttempts}</td>
                  <td style={{ fontSize: '0.72rem', fontFamily: 'var(--font-mono)', color: 'var(--text-muted)' }}>
                    {item.idempotencyKey.slice(0, 16)}...
                  </td>
                  <td>
                    <div style={{ display: 'flex', gap: '0.5rem' }}>
                      {item.status !== 'PUBLISHED' && item.status !== 'CANCELLED' && (
                        <button
                          className="btn btn-danger"
                          style={{ fontSize: '0.72rem', padding: '4px 8px' }}
                          onClick={() => handleCancel(item.id)}
                        >
                          Cancel
                        </button>
                      )}
                      {item.status === 'FAILED' && (
                        <button
                          className="btn btn-secondary"
                          style={{ fontSize: '0.72rem', padding: '4px 8px' }}
                          onClick={() => handleRetry(item.id)}
                        >
                          Retry
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

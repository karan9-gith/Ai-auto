import { Router, Request, Response } from 'express';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import fs from 'node:fs/promises';
import path from 'node:path';
import { prisma } from '../database/client.js';
import { config } from '../config/index.js';
import { persistentScheduler } from '../services/scheduler/schedulerEngine.js';
import { jobWorkerManager } from '../jobs/jobWorker.js';

const execFileAsync = promisify(execFile);
const router = Router();

export type HealthStatus = 'healthy' | 'warning' | 'error' | 'not_configured';

export interface ComponentHealth {
  name: string;
  status: HealthStatus;
  message: string;
  latencyMs?: number;
  details?: Record<string, unknown>;
}

router.get('/', async (_req: Request, res: Response) => {
  const startTime = Date.now();
  const components: ComponentHealth[] = [];

  // 1. Backend process check
  components.push({
    name: 'Backend Core',
    status: 'healthy',
    message: `Running on Node ${process.version} (PID ${process.pid})`,
    details: {
      uptimeSec: Math.floor(process.uptime()),
      memoryMb: Math.round(process.memoryUsage().rss / 1024 / 1024),
      env: config.NODE_ENV,
    },
  });

  // 2. Database (Prisma + SQLite) check
  const dbStart = Date.now();
  try {
    await prisma.$queryRaw`SELECT 1`;
    components.push({
      name: 'Database (SQLite/WAL)',
      status: 'healthy',
      message: 'Connection responsive and responsive to read queries',
      latencyMs: Date.now() - dbStart,
    });
  } catch (dbErr) {
    components.push({
      name: 'Database (SQLite/WAL)',
      status: 'error',
      message: `Database query failed: ${(dbErr as Error).message}`,
      latencyMs: Date.now() - dbStart,
    });
  }

  // 3. Google Gemini AI provider check
  if (!config.GEMINI_API_KEY || config.GEMINI_API_KEY.includes('your_') || config.GEMINI_API_KEY.length < 10) {
    components.push({
      name: 'Google Gemini',
      status: 'not_configured',
      message: 'GEMINI_API_KEY is not configured in .env',
      details: { model: config.GEMINI_MODEL },
    });
  } else {
    components.push({
      name: 'Google Gemini',
      status: 'healthy',
      message: `API Key active, targeting ${config.GEMINI_MODEL}`,
      details: { model: config.GEMINI_MODEL },
    });
  }

  // 4. YouTube Data API v3 OAuth check
  if (!config.YOUTUBE_CLIENT_ID || !config.YOUTUBE_CLIENT_SECRET) {
    components.push({
      name: 'YouTube OAuth v3',
      status: 'not_configured',
      message: 'YOUTUBE_CLIENT_ID or YOUTUBE_CLIENT_SECRET not configured in .env',
    });
  } else {
    // Check if any active tokens exist in DB
    const activeTokens = await prisma.credential.count({
      where: { provider: 'youtube', status: 'active' },
    });
    components.push({
      name: 'YouTube OAuth v3',
      status: activeTokens > 0 ? 'healthy' : 'warning',
      message:
        activeTokens > 0
          ? `${activeTokens} connected channel(s) with active refresh tokens`
          : 'OAuth secrets configured, but no channel connected yet',
      details: { connectedChannels: activeTokens },
    });
  }

  // 5. FFmpeg & FFprobe binary check
  const ffmpegStart = Date.now();
  try {
    const { stdout: ffmpegOut } = await execFileAsync(config.FFMPEG_PATH || 'ffmpeg', ['-version']);
    const { stdout: ffprobeOut } = await execFileAsync(config.FFPROBE_PATH || 'ffprobe', ['-version']);
    const ffmpegVer = ffmpegOut.split('\n')[0] || 'ffmpeg available';
    const ffprobeVer = ffprobeOut.split('\n')[0] || 'ffprobe available';
    components.push({
      name: 'FFmpeg Media Engine',
      status: 'healthy',
      message: `${ffmpegVer.trim()} | ${ffprobeVer.trim()}`,
      latencyMs: Date.now() - ffmpegStart,
      details: { ffmpeg: ffmpegVer.trim(), ffprobe: ffprobeVer.trim() },
    });
  } catch (ffmpegErr) {
    components.push({
      name: 'FFmpeg Media Engine',
      status: 'error',
      message: `FFmpeg/FFprobe binary check failed: ${(ffmpegErr as Error).message}`,
      latencyMs: Date.now() - ffmpegStart,
    });
  }

  // 6. Media Storage System check
  const storageStart = Date.now();
  try {
    const testFile = path.join(config.STORAGE_DIR, '.health_probe');
    await fs.mkdir(config.STORAGE_DIR, { recursive: true });
    await fs.writeFile(testFile, 'probe_test');
    await fs.unlink(testFile);
    components.push({
      name: 'Storage Subsystem',
      status: 'healthy',
      message: `Read/Write verified at ${config.STORAGE_DIR}`,
      latencyMs: Date.now() - storageStart,
    });
  } catch (storageErr) {
    components.push({
      name: 'Storage Subsystem',
      status: 'error',
      message: `Storage permission or path error: ${(storageErr as Error).message}`,
      latencyMs: Date.now() - storageStart,
    });
  }

  // 7. Persistent Scheduler check
  const schedulerRunning = persistentScheduler.getIsRunning();
  components.push({
    name: 'Persistent Scheduler',
    status: schedulerRunning ? 'healthy' : 'warning',
    message: schedulerRunning
      ? 'Cron loop active and polling SQLite scheduled_tasks'
      : 'Scheduler engine is currently idle or paused',
  });

  // 8. Background Job Worker check
  const workerRunning = jobWorkerManager.isWorkerRunning();
  components.push({
    name: 'Background Job Worker',
    status: workerRunning ? 'healthy' : 'warning',
    message: workerRunning
      ? 'Worker active, polling persistent SQLite job queue'
      : 'Job worker manager is not actively polling',
  });

  // Determine overall status
  const hasError = components.some((c) => c.status === 'error');
  const hasWarning = components.some((c) => c.status === 'warning');
  const overallStatus: HealthStatus = hasError ? 'error' : hasWarning ? 'warning' : 'healthy';

  res.status(hasError ? 503 : 200).json({
    success: true,
    status: overallStatus,
    timestamp: new Date().toISOString(),
    totalDurationMs: Date.now() - startTime,
    governance: {
      autoPublish: config.AUTO_PUBLISH,
      requireHumanApproval: config.REQUIRE_HUMAN_APPROVAL,
    },
    components,
  });
});

export default router;

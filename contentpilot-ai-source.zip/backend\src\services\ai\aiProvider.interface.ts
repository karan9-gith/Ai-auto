import { z } from 'zod';

export interface ResearchRequest {
  niche: string;
  targetAudience: string;
  language: string;
  contentPillars: string[];
  excludedTopics: string[];
  videoFormat: string;
  researchDepth: string;
}

export interface ResearchIdeaOutput {
  topic: string;
  angle: string;
  audience: string;
  trendScore: number;
  searchIntent: string;
  competitionScore: number;
  noveltyScore: number;
  evergreenScore: number;
  riskScore: number;
  recommendedFormat: string;
  sourceUrls: string[];
  evidenceSummary: string;
}

export interface StrategyRequest {
  selectedIdea: ResearchIdeaOutput;
  channelNiche: string;
  targetAudience: string;
  contentPillars: string[];
  cadencePerWeek: number;
  defaultFormat: string;
}

export interface StrategyOutput {
  titleConcept: string;
  hook: string;
  angle: string;
  audience: string;
  contentPillar: string;
  format: string;
  estimatedDurationSec: number;
  primaryKeyword: string;
  secondaryKeywords: string[];
  cta: string;
  thumbnailConcept: string;
  expectedKpi: string;
  priority: number;
  risk: string;
  reasonForSelection: string;
}

export interface ScriptRequest {
  strategy: StrategyOutput;
  brandVoice: string;
  targetDurationSec: number;
}

export interface ScriptSectionOutput {
  type: 'HOOK' | 'INTRO' | 'CONTEXT' | 'MAIN_CONTENT' | 'PATTERN_INTERRUPT' | 'EXAMPLE' | 'KEY_TAKEAWAY' | 'CTA' | 'OUTRO';
  label: string;
  narrationText: string;
  visualDescription: string;
  targetDurationSec: number;
}

export interface ClaimOutput {
  claim: string;
  confidence: number;
  sourceReferences: string[];
}

export interface ScriptOutput {
  title: string;
  hook: {
    text: string;
    visualCue: string;
    durationSec: number;
  };
  sections: ScriptSectionOutput[];
  cta: {
    text: string;
    visualCue: string;
  };
  outro: {
    text: string;
    visualCue: string;
  };
  estimatedDurationSec: number;
  wordCount: number;
  claims: ClaimOutput[];
}

export interface SeoRequest {
  script: ScriptOutput;
  primaryKeyword: string;
  secondaryKeywords: string[];
}

export interface SeoOutput {
  titleCandidates: Array<{
    title: string;
    relevance: number;
    clarity: number;
    searchIntent: number;
    specificity: number;
    curiosity: number;
    brandFit: number;
    clickbaitRisk: number;
  }>;
  recommendedTitle: string;
  description: string;
  chapters: Array<{ timestamp: string; title: string }>;
  tags: string[];
  hashtags: string[];
  primaryKeyword: string;
  secondaryKeywords: string[];
  thumbnailTextOptions: string[];
}

export interface ThumbnailConceptRequest {
  title: string;
  hook: string;
  visualStyle: string;
}

export interface ThumbnailConceptItem {
  imagePrompt: string;
  composition: string;
  subject: string;
  emotion: string;
  textOverlay: string;
  layout: string;
  visualHierarchy: string;
  contrastGuidance: string;
}

export interface ThumbnailConceptOutput {
  concepts: ThumbnailConceptItem[];
}

export interface ScenePlanRequest {
  script: ScriptOutput;
  aspectRatio: '16:9' | '9:16';
}

export interface ScenePlanItem {
  sceneIndex: number;
  label: string;
  narrationSegment: string;
  visualDescription: string;
  visualType: 'image' | 'video_clip';
  durationSec: number;
  transitionEffect: string;
  motionEffect: string;
}

export interface ScenePlanOutput {
  scenes: ScenePlanItem[];
}

export interface QualityReportRequest {
  script: ScriptOutput;
  seo: SeoOutput;
  measuredLoudnessLufs: number;
  measuredDurationSec: number;
  audioVideoDriftSec: number;
  hasBlackFrames: boolean;
}

export interface QualityReportOutput {
  passed: boolean;
  overallScore: number;
  findings: Array<{
    rule: string;
    severity: 'INFO' | 'WARNING' | 'CRITICAL';
    passed: boolean;
    message: string;
  }>;
}

export interface AIProvider {
  readonly providerName: string;

  generateText(prompt: string, systemInstruction?: string): Promise<string>;

  generateStructuredJSON<T>(
    prompt: string,
    schema: z.ZodSchema<T>,
    systemInstruction?: string,
    maxRetries?: number
  ): Promise<T>;

  generateResearch(request: ResearchRequest): Promise<{ ideas: ResearchIdeaOutput[] }>;

  generateStrategy(request: StrategyRequest): Promise<StrategyOutput>;

  generateScript(request: ScriptRequest): Promise<ScriptOutput>;

  generateTitles(scriptText: string, primaryKeyword: string): Promise<string[]>;

  generateSEO(request: SeoRequest): Promise<SeoOutput>;

  generateThumbnailConcept(request: ThumbnailConceptRequest): Promise<ThumbnailConceptOutput>;

  generateScenePlan(request: ScenePlanRequest): Promise<ScenePlanOutput>;

  analyzeContent(text: string): Promise<{ repetitionScore: number; safetyScore: number; notes: string }>;

  generateQualityReport(request: QualityReportRequest): Promise<QualityReportOutput>;
}

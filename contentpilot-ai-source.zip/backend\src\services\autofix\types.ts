export type ErrorClassification =
  | 'TRANSIENT'
  | 'CONFIGURATION'
  | 'AUTHENTICATION'
  | 'QUOTA'
  | 'VALIDATION'
  | 'MEDIA'
  | 'DATABASE'
  | 'NETWORK'
  | 'UNKNOWN';

export type AutoFixResult = 'SUCCESS' | 'FAILED' | 'ESCALATED';

export interface DiagnosedError {
  classification: ErrorClassification;
  diagnosis: string;
  isRecoverable: boolean;
  recommendedAction: string;
  suggestedFix?: string;
  retryDelayMs?: number;
}

export interface AutoFixAttempt {
  jobId?: string;
  projectId?: string;
  error: string;
  classification: ErrorClassification;
  diagnosis: string;
  fixApplied: string;
  result: AutoFixResult;
  retryCount: number;
  meta?: Record<string, unknown>;
}

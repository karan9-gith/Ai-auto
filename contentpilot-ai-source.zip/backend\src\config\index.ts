import { z } from 'zod';
import dotenv from 'dotenv';
import path from 'node:path';

// Load environment variables from .env file
dotenv.config();

const envSchema = z.object({
  NODE_ENV: z.enum(['development', 'production', 'test']).default('development'),
  PORT: z.coerce.number().default(3001),
  CORS_ORIGIN: z.string().default('http://localhost:5173'),
  APP_SECRET_KEY: z.string().min(16).default('contentpilot_super_secret_master_key_default_32b'),
  DATABASE_URL: z.string().default('file:./dev.db'),

  // SAFETY REQUIREMENTS ENFORCEMENT
  AUTO_PUBLISH: z
    .string()
    .default('false')
    .transform((val) => val === 'true'),
  REQUIRE_HUMAN_APPROVAL: z
    .string()
    .default('true')
    .transform((val) => val === 'true'),
  DEFAULT_YOUTUBE_PRIVACY: z
    .enum(['public', 'unlisted', 'private'])
    .default('public'),

  // AI Providers
  GEMINI_API_KEY: z.string().optional(),
  GEMINI_MODEL: z.string().default('gemini-2.5-flash'),
  OPENAI_API_KEY: z.string().optional(),
  OPENAI_MODEL: z.string().default('gpt-4o-mini'),

  // Voice & Video
  TTS_PROVIDER: z.enum(['gemini', 'elevenlabs', 'azure']).default('gemini'),
  ELEVENLABS_API_KEY: z.string().optional(),
  ELEVENLABS_VOICE_ID: z.string().default('21m00Tcm4TlvDq8ikWAM'),

  IMAGE_PROVIDER: z.enum(['gemini', 'replicate', 'openai']).default('gemini'),
  REPLICATE_API_TOKEN: z.string().optional(),

  // YouTube OAuth
  YOUTUBE_CLIENT_ID: z.string().optional(),
  YOUTUBE_CLIENT_SECRET: z.string().optional(),
  YOUTUBE_REDIRECT_URI: z.string().default('http://localhost:3001/api/auth/youtube/callback'),

  // Media & Storage
  FFMPEG_PATH: z.string().optional(),
  FFPROBE_PATH: z.string().optional(),
  STORAGE_DIR: z.string().default(path.resolve(process.cwd(), 'storage')),
  MAX_CONCURRENT_RENDERS: z.coerce.number().default(1),

  // Job Queue Settings
  JOB_WORKER_POLL_INTERVAL_MS: z.coerce.number().default(2000),
  JOB_HEARTBEAT_INTERVAL_SEC: z.coerce.number().default(30),
  JOB_MAX_ATTEMPTS: z.coerce.number().default(3),

  LOG_LEVEL: z.enum(['fatal', 'error', 'warn', 'info', 'debug', 'trace']).default('info'),
});

const parsed = envSchema.safeParse(process.env);

if (!parsed.success) {
  console.error('❌ Invalid environment configuration:', parsed.error.format());
  throw new Error('Environment configuration error. Please verify your .env file.');
}

export const config = parsed.data;

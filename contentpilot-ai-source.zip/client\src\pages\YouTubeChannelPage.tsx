import React, { useEffect, useState } from 'react';
import { api } from '../services/api';
import { EmptyState } from '../components/EmptyState';
import { Youtube, Link, Unlink, ExternalLink, Video, CheckCircle2, ShieldCheck, Clock } from 'lucide-react';

interface YouTubeChannelPageProps {
  channelId: string;
  onNavigate: (page: any) => void;
}

export const YouTubeChannelPage: React.FC<YouTubeChannelPageProps> = ({ channelId, onNavigate }) => {
  const [status, setStatus] = useState<any>(null);
  const [videos, setVideos] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [connecting, setConnecting] = useState(false);
  const [message, setMessage] = useState<string | null>(null);

  useEffect(() => {
    loadData();
  }, [channelId]);

  const loadData = async () => {
    try {
      setLoading(true);
      const [s, v] = await Promise.all([
        api.getYouTubeStatus(channelId),
        api.getYouTubeVideos(channelId),
      ]);
      setStatus(s);
      setVideos(v);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleConnect = async () => {
    try {
      setConnecting(true);
      const authUrl = await api.getYouTubeAuthUrl(channelId);
      window.open(authUrl, '_blank', 'width=600,height=700');
      setMessage('OAuth consent window opened. Complete sign-in, then click Refresh.');
    } catch (err: any) {
      setMessage(`Connect error: ${err.message}`);
    } finally {
      setConnecting(false);
    }
  };

  const handleDisconnect = async () => {
    if (!confirm('Disconnect YouTube OAuth for this channel?')) return;
    try {
      await api.disconnectYouTube(channelId);
      setMessage('Channel disconnected.');
      await loadData();
    } catch (err: any) {
      setMessage(`Disconnect error: ${err.message}`);
    }
  };

  return (
    <div style={{ padding: '2rem' }}>
      <div className="page-header">
        <div>
          <h1 className="page-title">YouTube Channel & OAuth Integration</h1>
          <p className="page-description">
            Direct YouTube Data API v3 connectivity, verified permissions, and live publishing status.
          </p>
        </div>

        <div>
          {status?.isConnected ? (
            <button className="btn btn-danger" onClick={handleDisconnect}>
              <Unlink size={16} /> Disconnect Channel
            </button>
          ) : (
            <button className="btn btn-primary" onClick={handleConnect} disabled={connecting}>
              <Link size={16} /> Connect YouTube OAuth
            </button>
          )}
        </div>
      </div>

      {message && (
        <div className="badge badge-info" style={{ marginBottom: '1.25rem', padding: '8px 12px' }}>
          {message}
        </div>
      )}

      {/* Connection Card */}
      <div className="glass-panel" style={{ padding: '1.75rem', marginBottom: '2rem' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '1.25rem' }}>
            <div
              style={{
                width: '54px',
                height: '54px',
                borderRadius: '12px',
                background: 'rgba(239, 68, 68, 0.15)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                color: '#ef4444',
                border: '1px solid rgba(239, 68, 68, 0.3)',
              }}
            >
              <Youtube size={28} />
            </div>
            <div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                <h2 style={{ fontSize: '1.25rem', fontWeight: 800 }}>
                  {status?.channel?.name || 'ContentPilot Channel'}
                </h2>
                <span className={`badge ${status?.isConnected ? 'badge-success' : 'badge-warning'}`}>
                  {status?.isConnected ? 'OAuth Active' : 'Disconnected'}
                </span>
              </div>
              <div style={{ fontSize: '0.85rem', color: 'var(--text-secondary)', marginTop: '2px' }}>
                Language: {status?.channel?.defaultLanguage} • Timezone: {status?.channel?.timezone}
              </div>
            </div>
          </div>

          <div style={{ display: 'flex', gap: '1.5rem', textAlign: 'right' }}>
            <div>
              <div style={{ fontSize: '0.72rem', color: 'var(--text-secondary)', textTransform: 'uppercase' }}>Published Videos</div>
              <div style={{ fontSize: '1.5rem', fontWeight: 800 }}>{status?.publishedCount || 0}</div>
            </div>
            <div>
              <div style={{ fontSize: '0.72rem', color: 'var(--text-secondary)', textTransform: 'uppercase' }}>Queued in Release</div>
              <div style={{ fontSize: '1.5rem', fontWeight: 800 }}>{status?.queuedCount || 0}</div>
            </div>
          </div>
        </div>
      </div>

      {/* Published Videos Table */}
      <h2 style={{ fontSize: '1.15rem', fontWeight: 700, marginBottom: '1rem' }}>Published YouTube Catalog</h2>
      {videos.length === 0 ? (
        <EmptyState
          title="No published videos on record."
          message="Once approved videos are processed by the YouTube upload engine, they will be listed here with direct links and view telemetry."
        />
      ) : (
        <div className="table-container">
          <table className="table">
            <thead>
              <tr>
                <th>Video Title</th>
                <th>YouTube Video ID</th>
                <th>Published At</th>
                <th>Privacy</th>
                <th>Lifetime Views</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              {videos.map((v) => (
                <tr key={v.id}>
                  <td style={{ fontWeight: 600 }}>{v.title}</td>
                  <td style={{ fontSize: '0.78rem', fontFamily: 'var(--font-mono)', color: 'var(--text-muted)' }}>
                    {v.youtubeVideoId}
                  </td>
                  <td style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>
                    {new Date(v.publishedAt).toLocaleDateString()}
                  </td>
                  <td>
                    <span className="badge badge-info">{v.privacyStatus}</span>
                  </td>
                  <td style={{ fontWeight: 700, color: '#34d399' }}>
                    {v.analytics?.[0]?.views ? v.analytics[0].views.toLocaleString() : 'Syncing'}
                  </td>
                  <td>
                    <a
                      href={v.youtubeUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="btn btn-secondary"
                      style={{ fontSize: '0.72rem', padding: '4px 8px', display: 'inline-flex', alignItems: 'center', gap: '4px' }}
                    >
                      Watch <ExternalLink size={12} />
                    </a>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

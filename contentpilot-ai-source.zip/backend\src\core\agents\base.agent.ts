import { IAIService } from '../ai/types.js';
import { PipelineStageType } from '../../types/index.js';

export interface AgentContext {
  productionId?: string;
  strategyId?: string;
  storageDir: string;
  traceId: string;
}

export abstract class BaseAgent<TInput, TOutput> {
  abstract readonly name: string;
  abstract readonly stage: PipelineStageType;

  constructor(protected readonly ai: IAIService) {}

  /**
   * Primary entry point for agent execution.
   * Enforces logging, runtime validation, and timing metrics.
   */
  async run(input: TInput, context: AgentContext): Promise<TOutput> {
    const startTime = Date.now();
    try {
      this.validateInput(input);
      const output = await this.execute(input, context);
      this.validateOutput(output);
      const durationMs = Date.now() - startTime;
      return output;
    } catch (error) {
      throw error;
    }
  }

  protected abstract execute(input: TInput, context: AgentContext): Promise<TOutput>;

  protected abstract validateInput(input: TInput): void;

  protected abstract validateOutput(output: TOutput): void;
}

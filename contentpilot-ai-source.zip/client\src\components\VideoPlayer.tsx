import React from 'react';
import { Film, AlertCircle } from 'lucide-react';
import { api } from '../services/api';

interface VideoPlayerProps {
  filePath?: string | null;
  thumbnailPath?: string | null;
  title?: string;
}

export const VideoPlayer: React.FC<VideoPlayerProps> = ({ filePath, thumbnailPath, title }) => {
  if (!filePath) {
    return (
      <div
        style={{
          width: '100%',
          aspectRatio: '16/9',
          background: '#0a0d14',
          borderRadius: '10px',
          border: '1px solid var(--border-subtle)',
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
          color: 'var(--text-muted)',
          gap: '0.75rem',
        }}
      >
        <Film size={40} strokeWidth={1.5} />
        <span style={{ fontSize: '0.875rem' }}>Video master render not generated yet</span>
      </div>
    );
  }

  const mediaUrl = api.getMediaUrl(filePath);
  const posterUrl = thumbnailPath ? api.getMediaUrl(thumbnailPath) : undefined;

  return (
    <div
      style={{
        width: '100%',
        aspectRatio: '16/9',
        background: '#000',
        borderRadius: '10px',
        overflow: 'hidden',
        border: '1px solid var(--border-subtle)',
        position: 'relative',
      }}
    >
      <video
        src={mediaUrl}
        poster={posterUrl}
        controls
        playsInline
        style={{ width: '100%', height: '100%', objectFit: 'contain' }}
      >
        <track kind="captions" />
        Your browser does not support HTML5 video streaming.
      </video>
    </div>
  );
};

import React from 'react';
import {
  LayoutDashboard,
  PlayCircle,
  Search,
  Lightbulb,
  Target,
  FileText,
  Image,
  Video,
  CheckSquare,
  UploadCloud,
  Youtube,
  BarChart3,
  FlaskConical,
  GraduationCap,
  Calendar,
  Cpu,
  Settings,
  Terminal,
  Activity,
} from 'lucide-react';
import { PageId } from '../types';

interface SidebarProps {
  currentPage: PageId;
  onNavigate: (page: PageId) => void;
  pendingApprovalsCount?: number;
}

interface NavItem {
  id: PageId;
  label: string;
  icon: React.ComponentType<any>;
  badge?: number;
}

interface NavSection {
  title: string;
  items: NavItem[];
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentPage,
  onNavigate,
  pendingApprovalsCount = 0,
}) => {
  const sections: NavSection[] = [
    {
      title: 'ORCHESTRATION',
      items: [
        { id: 'overview', label: 'Overview', icon: LayoutDashboard },
        { id: 'operator', label: 'Autonomous Operator', icon: PlayCircle },
        { id: 'review', label: 'Review Studio', icon: CheckSquare, badge: pendingApprovalsCount },
        { id: 'production', label: 'Production', icon: Video },
      ],
    },
    {
      title: 'CONTENT ENGINE',
      items: [
        { id: 'research', label: 'Research', icon: Search },
        { id: 'ideas', label: 'Content Ideas', icon: Lightbulb },
        { id: 'strategy', label: 'Strategy', icon: Target },
        { id: 'scripts', label: 'Scripts', icon: FileText },
        { id: 'thumbnails', label: 'Thumbnails', icon: Image },
      ],
    },
    {
      title: 'DISTRIBUTION',
      items: [
        { id: 'publishing', label: 'Publishing Queue', icon: UploadCloud },
        { id: 'youtube', label: 'YouTube Channel', icon: Youtube },
        { id: 'scheduler', label: 'Scheduler', icon: Calendar },
      ],
    },
    {
      title: 'INTELLIGENCE',
      items: [
        { id: 'analytics', label: 'Analytics', icon: BarChart3 },
        { id: 'experiments', label: 'Experiments', icon: FlaskConical },
        { id: 'learning', label: 'Learning Agent', icon: GraduationCap },
      ],
    },
    {
      title: 'PLATFORM',
      items: [
        { id: 'providers', label: 'AI Providers', icon: Cpu },
        { id: 'health', label: 'System Health', icon: Activity },
        { id: 'logs', label: 'Logs & Audit', icon: Terminal },
        { id: 'settings', label: 'Settings', icon: Settings },
      ],
    },
  ];

  return (
    <aside
      style={{
        width: 'var(--sidebar-width)',
        height: '100vh',
        background: 'var(--bg-surface)',
        borderRight: '1px solid var(--border-subtle)',
        position: 'fixed',
        left: 0,
        top: 0,
        display: 'flex',
        flexDirection: 'column',
        zIndex: 50,
      }}
    >
      {/* Brand Header */}
      <div
        style={{
          height: 'var(--header-height)',
          display: 'flex',
          alignItems: 'center',
          gap: '12px',
          padding: '0 1.25rem',
          borderBottom: '1px solid var(--border-subtle)',
        }}
      >
        <div
          style={{
            width: '34px',
            height: '34px',
            borderRadius: '8px',
            background: 'var(--accent-gradient)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            boxShadow: 'var(--glow-blue)',
          }}
        >
          <Video size={18} color="#fff" />
        </div>
        <div>
          <div style={{ fontSize: '1.05rem', fontWeight: 800, letterSpacing: '-0.02em' }}>ContentPilot</div>
          <div style={{ fontSize: '0.7rem', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.06em' }}>
            Enterprise AI
          </div>
        </div>
      </div>

      {/* Nav List */}
      <div
        style={{
          flex: 1,
          overflowY: 'auto',
          padding: '1rem 0.75rem',
          display: 'flex',
          flexDirection: 'column',
          gap: '1.25rem',
        }}
      >
        {sections.map((sec) => (
          <div key={sec.title}>
            <div
              style={{
                fontSize: '0.68rem',
                fontWeight: 700,
                color: 'var(--text-muted)',
                letterSpacing: '0.08em',
                padding: '0 0.5rem 0.4rem',
              }}
            >
              {sec.title}
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '2px' }}>
              {sec.items.map((item) => {
                const isActive = currentPage === item.id;
                const Icon = item.icon;
                return (
                  <button
                    key={item.id}
                    onClick={() => onNavigate(item.id)}
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'space-between',
                      width: '100%',
                      padding: '8px 10px',
                      borderRadius: '8px',
                      background: isActive ? 'rgba(59, 130, 246, 0.12)' : 'transparent',
                      border: isActive ? '1px solid rgba(59, 130, 246, 0.3)' : '1px solid transparent',
                      color: isActive ? '#60a5fa' : 'var(--text-secondary)',
                      fontSize: '0.825rem',
                      fontWeight: isActive ? 600 : 500,
                      cursor: 'pointer',
                      transition: 'all 0.15s ease',
                      textAlign: 'left',
                    }}
                  >
                    <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                      <Icon size={16} />
                      <span>{item.label}</span>
                    </div>
                    {item.badge !== undefined && item.badge > 0 && (
                      <span
                        style={{
                          fontSize: '0.7rem',
                          fontWeight: 700,
                          background: 'rgba(245, 158, 11, 0.25)',
                          color: '#fbbf24',
                          padding: '1px 7px',
                          borderRadius: '9999px',
                          border: '1px solid rgba(245, 158, 11, 0.4)',
                        }}
                      >
                        {item.badge}
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          </div>
        ))}
      </div>
    </aside>
  );
};

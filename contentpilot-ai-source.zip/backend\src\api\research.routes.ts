import { Router, Request, Response, NextFunction } from 'express';
import { prisma } from '../database/client.js';
import { defaultAiProvider } from '../services/ai/defaultAIProvider.js';
import { AppError } from '../utils/errors.js';

const router = Router();
const param = (p: string | string[]): string => (Array.isArray(p) ? p[0] : p);

// GET all research runs for a channel
router.get('/', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const channelId = req.query.channelId as string | undefined;
    const runs = await prisma.researchRun.findMany({
      where: channelId ? { channelId } : undefined,
      include: {
        sources: true,
        ideas: true,
      },
      orderBy: { createdAt: 'desc' },
      take: 20,
    });
    res.json({ success: true, count: runs.length, data: runs });
  } catch (err) {
    next(err);
  }
});

// GET single research run with sources and ideas
router.get('/:id', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const run = await prisma.researchRun.findUnique({
      where: { id: param(req.params.id) },
      include: {
        sources: true,
        ideas: true,
      },
    });
    if (!run) {
      throw new AppError('Research run not found', 404, 'RESEARCH_NOT_FOUND');
    }
    res.json({ success: true, data: run });
  } catch (err) {
    next(err);
  }
});

// POST trigger new research run
router.post('/run', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { channelId, niche, targetAudience, language, contentPillars, excludedTopics, videoFormat, researchDepth } = req.body;
    if (!channelId) {
      res.status(400).json({ success: false, error: 'Field "channelId" is required' });
      return;
    }

    const channel = await prisma.channel.findUnique({
      where: { id: channelId },
      include: { settings: true },
    });

    if (!channel) {
      throw new AppError(`Channel ${channelId} not found`, 404, 'CHANNEL_NOT_FOUND');
    }

    const selectedNiche = niche || channel.niche;
    const selectedAudience = targetAudience || channel.targetAudience;
    const selectedLang = language || channel.defaultLanguage;
    const pillars = contentPillars || JSON.parse(channel.settings?.contentPillars || '[]');
    const banned = excludedTopics || JSON.parse(channel.settings?.bannedTopics || '[]');

    const aiResult = await defaultAiProvider.generateResearch({
      niche: selectedNiche,
      targetAudience: selectedAudience,
      language: selectedLang,
      contentPillars: pillars,
      excludedTopics: banned,
      videoFormat: videoFormat || channel.settings?.defaultFormat || 'explainer',
      researchDepth: researchDepth || 'standard',
    });

    const run = await prisma.researchRun.create({
      data: {
        channelId,
        niche: selectedNiche,
        targetAudience: selectedAudience,
        language: selectedLang,
        contentPillars: JSON.stringify(pillars),
        excludedTopics: JSON.stringify(banned),
        videoFormat: videoFormat || 'long_form',
        researchDepth: researchDepth || 'standard',
        status: 'completed',
        completedAt: new Date(),
      },
    });

    // Save generated ideas and sources
    for (const idea of aiResult.ideas) {
      await prisma.contentIdea.create({
        data: {
          researchRunId: run.id,
          channelId,
          topic: idea.topic,
          angle: idea.angle,
          targetAudience: idea.audience,
          trendScore: idea.trendScore,
          searchIntent: idea.searchIntent,
          competitionScore: idea.competitionScore,
          noveltyScore: idea.noveltyScore,
          evergreenScore: idea.evergreenScore,
          riskScore: idea.riskScore,
          recommendedFormat: idea.recommendedFormat,
          sourceUrlsJson: JSON.stringify(idea.sourceUrls),
          evidenceSummary: idea.evidenceSummary,
          status: 'backlog',
        },
      });

      for (const url of idea.sourceUrls) {
        await prisma.researchSource.create({
          data: {
            researchRunId: run.id,
            title: idea.topic,
            url,
            sourcePlatform: 'web',
            authorityScore: 88.0,
            relevanceScore: 92.0,
          },
        });
      }
    }

    const completedRun = await prisma.researchRun.findUnique({
      where: { id: run.id },
      include: { sources: true, ideas: true },
    });

    res.json({ success: true, data: completedRun });
  } catch (err) {
    next(err);
  }
});

export default router;

import { Router, Request, Response, NextFunction } from 'express';
import { prisma } from '../database/client.js';
import { persistentScheduler } from '../services/scheduler/schedulerEngine.js';

const router = Router();

// GET list scheduled tasks
router.get('/tasks', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const channelId = req.query.channelId as string | undefined;
    const tasks = await prisma.scheduledTask.findMany({
      where: channelId ? { channelId } : undefined,
      orderBy: { createdAt: 'desc' },
    });
    res.json({ success: true, count: tasks.length, data: tasks });
  } catch (err) {
    next(err);
  }
});

// POST create scheduled task
router.post('/tasks', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { channelId, name, taskType, scheduleType, intervalMs, preferredTime, timezone, config, nextRunAt } = req.body;
    if (!name || !taskType || !scheduleType) {
      res.status(400).json({ success: false, error: 'Fields "name", "taskType", and "scheduleType" are required' });
      return;
    }
    const taskId = await persistentScheduler.createTask({
      channelId,
      name,
      taskType,
      scheduleType,
      intervalMs,
      preferredTime,
      timezone,
      config,
      nextRunAt: nextRunAt ? new Date(nextRunAt) : undefined,
    });
    res.json({ success: true, taskId });
  } catch (err) {
    next(err);
  }
});

// POST trigger manual scheduler tick
router.post('/tick', async (_req: Request, res: Response, next: NextFunction) => {
  try {
    const processed = await persistentScheduler.tick();
    res.json({ success: true, processedTasksCount: processed });
  } catch (err) {
    next(err);
  }
});

// GET channel scheduler settings
router.get('/config/:channelId', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const channelId = Array.isArray(req.params.channelId) ? req.params.channelId[0] : req.params.channelId;
    let settings = await prisma.channelSetting.findUnique({
      where: { channelId },
    });

    if (!settings) {
      settings = await prisma.channelSetting.create({
        data: {
          channelId,
          autoPublish: false,
          requireHumanApproval: true,
          automationEnabled: false,
        },
      });
    }

    res.json({ success: true, data: settings });
  } catch (err) {
    next(err);
  }
});

// PUT update channel scheduler configuration
router.put('/config/:channelId', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const channelId = Array.isArray(req.params.channelId) ? req.params.channelId[0] : req.params.channelId;
    const {
      automationEnabled,
      researchEnabled,
      generationEnabled,
      autoPublishEnabled,
      publishingCadence,
      preferredPublishTime,
      timezone,
      maxVideosPerDay,
      maxConcurrentJobs,
    } = req.body;

    const updated = await prisma.channelSetting.upsert({
      where: { channelId },
      create: {
        channelId,
        automationEnabled: automationEnabled ?? false,
        researchEnabled: researchEnabled ?? true,
        generationEnabled: generationEnabled ?? true,
        autoPublishEnabled: autoPublishEnabled ?? false,
        publishingCadence: publishingCadence || 'weekly',
        preferredPublishTime: preferredPublishTime || '14:00',
        timezone: timezone || 'UTC',
        maxVideosPerDay: Number(maxVideosPerDay ?? 1),
        maxConcurrentJobs: Number(maxConcurrentJobs ?? 2),
      },
      update: {
        automationEnabled: automationEnabled !== undefined ? automationEnabled : undefined,
        researchEnabled: researchEnabled !== undefined ? researchEnabled : undefined,
        generationEnabled: generationEnabled !== undefined ? generationEnabled : undefined,
        autoPublishEnabled: autoPublishEnabled !== undefined ? autoPublishEnabled : undefined,
        publishingCadence,
        preferredPublishTime,
        timezone,
        maxVideosPerDay: maxVideosPerDay !== undefined ? Number(maxVideosPerDay) : undefined,
        maxConcurrentJobs: maxConcurrentJobs !== undefined ? Number(maxConcurrentJobs) : undefined,
      },
    });

    res.json({ success: true, data: updated });
  } catch (err) {
    next(err);
  }
});

// DELETE a scheduled task
router.delete('/tasks/:id', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const id = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
    await prisma.scheduledTask.delete({ where: { id } });
    res.json({ success: true, message: 'Task deleted' });
  } catch (err) {
    next(err);
  }
});

export default router;

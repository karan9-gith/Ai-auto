import { prisma } from '../../database/client.js';
import { logger } from '../../utils/logger.js';

export interface StructuredInsight {
  category: 'topic' | 'title' | 'thumbnail' | 'timing' | 'format' | 'audience';
  insight: string;
  evidence: string;
  confidence: number; // 0.0 to 1.0
  recommendation: string;
  actionRule: Record<string, unknown>;
  sampleVideoIds: string[];
}

export class LearningAgent {
  /**
   * Run analytical learning engine over historical channel performance
   */
  public async analyzeChannel(channelId: string): Promise<StructuredInsight[]> {
    const snapshots = await prisma.analyticsSnapshot.findMany({
      where: {
        channelId,
        measurementWindow: 'lifetime',
      },
      include: {
        youtubeVideo: {
          include: {
            project: {
              include: {
                seoPackage: true,
                thumbnail: { include: { variants: true } },
                script: { include: { strategy: true } },
              },
            },
          },
        },
      },
    });

    const sampleSize = snapshots.length;
    const insights: StructuredInsight[] = [];

    // Safeguard: Insufficient observations check
    if (sampleSize < 2) {
      logger.info({
        msg: 'Learning Agent requires at least 2 published video snapshots to infer patterns',
        channelId,
        sampleSize,
      });

      const preliminaryInsight: StructuredInsight = {
        category: 'audience',
        insight: 'Channel is in initial discovery phase with insufficient statistical baseline',
        evidence: `Only ${sampleSize} video snapshot(s) recorded to date. Minimum 3-5 observations required before inferring statistical significance.`,
        confidence: 0.15,
        recommendation: 'Continue scheduled content production according to established content pillars to establish initial variance baseline.',
        actionRule: { minimumSampleSizeRequired: 5, currentSampleSize: sampleSize },
        sampleVideoIds: snapshots.map((s) => s.youtubeVideoId),
      };

      await this.persistInsights(channelId, [preliminaryInsight]);
      return [preliminaryInsight];
    }

    // 1. Analyze Topics
    const topicPerformance = new Map<string, { views: number[]; vids: string[] }>();
    for (const snap of snapshots) {
      const topic =
        snap.youtubeVideo?.project?.script?.strategy?.primaryKeyword ||
        snap.youtubeVideo?.project?.script?.title ||
        'general';
      const existing = topicPerformance.get(topic) || { views: [], vids: [] };
      existing.views.push(snap.views);
      existing.vids.push(snap.youtubeVideoId);
      topicPerformance.set(topic, existing);
    }

    const topicsWithAverages = Array.from(topicPerformance.entries())
      .map(([topic, data]) => ({
        topic,
        avgViews: data.views.reduce((a, b) => a + b, 0) / data.views.length,
        count: data.views.length,
        vids: data.vids,
      }))
      .sort((a, b) => b.avgViews - a.avgViews);

    if (topicsWithAverages.length > 1) {
      const best = topicsWithAverages[0];
      const worst = topicsWithAverages[topicsWithAverages.length - 1];
      const topicConfidence = this.calculateConfidence(sampleSize, best.count);

      insights.push({
        category: 'topic',
        insight: `Topic '${best.topic}' outperforms average channel viewership`,
        evidence: `'${best.topic}' averaged ${Math.round(best.avgViews)} views across ${best.count} video(s), compared to '${worst.topic}' which averaged ${Math.round(worst.avgViews)} views (n=${sampleSize} total videos).`,
        confidence: topicConfidence,
        recommendation: `Increase production weighting of '${best.topic}' and related cluster subtopics in upcoming research cycles.`,
        actionRule: { prioritizeTopic: best.topic, deprioritizeTopic: worst.topic },
        sampleVideoIds: best.vids,
      });
    }

    // 2. Analyze Title Patterns (Question titles vs Statements)
    const questionTitles: number[] = [];
    const statementTitles: number[] = [];
    const questionVids: string[] = [];
    const statementVids: string[] = [];

    for (const snap of snapshots) {
      const title = snap.youtubeVideo?.title || '';
      if (title.includes('?')) {
        questionTitles.push(snap.views);
        questionVids.push(snap.youtubeVideoId);
      } else {
        statementTitles.push(snap.views);
        statementVids.push(snap.youtubeVideoId);
      }
    }

    if (questionTitles.length > 0 && statementTitles.length > 0) {
      const avgQuestion = questionTitles.reduce((a, b) => a + b, 0) / questionTitles.length;
      const avgStatement = statementTitles.reduce((a, b) => a + b, 0) / statementTitles.length;
      const titleConfidence = this.calculateConfidence(sampleSize, questionTitles.length);

      const performsBetter = avgQuestion >= avgStatement;
      const ratio = avgStatement > 0 ? (avgQuestion / avgStatement).toFixed(2) : '1.0';

      insights.push({
        category: 'title',
        insight: performsBetter
          ? 'Question-framed titles demonstrate stronger viewership performance'
          : 'Direct affirmative statement titles outperform question-framed titles',
        evidence: `Question titles averaged ${Math.round(avgQuestion)} views (n=${questionTitles.length}) vs statement titles averaging ${Math.round(avgStatement)} views (n=${statementTitles.length}). Ratio: ${ratio}x.`,
        confidence: titleConfidence,
        recommendation: performsBetter
          ? 'Frame high-intent explainer video titles around curiosity-inducing questions.'
          : 'Utilize authoritative statement titles emphasizing immediate practical benefit.',
        actionRule: { preferQuestionTitles: performsBetter },
        sampleVideoIds: performsBetter ? questionVids : statementVids,
      });
    }

    // 3. Analyze Format Performance
    const formatPerformance = new Map<string, { views: number[]; vids: string[] }>();
    for (const snap of snapshots) {
      const fmt = snap.youtubeVideo?.project?.script?.strategy?.format || 'explainer';
      const entry = formatPerformance.get(fmt) || { views: [], vids: [] };
      entry.views.push(snap.views);
      entry.vids.push(snap.youtubeVideoId);
      formatPerformance.set(fmt, entry);
    }

    if (formatPerformance.size > 1) {
      const formatsList = Array.from(formatPerformance.entries()).map(([format, data]) => ({
        format,
        avg: data.views.reduce((a, b) => a + b, 0) / data.views.length,
        count: data.views.length,
        vids: data.vids,
      })).sort((a, b) => b.avg - a.avg);

      const topFormat = formatsList[0];
      const fmtConfidence = this.calculateConfidence(sampleSize, topFormat.count);

      insights.push({
        category: 'format',
        insight: `Format '${topFormat.format}' yields highest average audience reach`,
        evidence: `'${topFormat.format}' averaged ${Math.round(topFormat.avg)} views across ${topFormat.count} production(s) on channel.`,
        confidence: fmtConfidence,
        recommendation: `Maintain '${topFormat.format}' as default structural template for upcoming batches.`,
        actionRule: { preferredFormat: topFormat.format },
        sampleVideoIds: topFormat.vids,
      });
    }

    // 4. Analyze Publishing Times
    const dayPerformance = new Map<number, { views: number[]; vids: string[] }>();
    for (const snap of snapshots) {
      const pubDate = snap.youtubeVideo?.publishedAt ? new Date(snap.youtubeVideo.publishedAt) : new Date();
      const day = pubDate.getUTCDay(); // 0 = Sun, 1 = Mon...
      const entry = dayPerformance.get(day) || { views: [], vids: [] };
      entry.views.push(snap.views);
      entry.vids.push(snap.youtubeVideoId);
      dayPerformance.set(day, entry);
    }

    if (dayPerformance.size >= 2) {
      const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
      const rankedDays = Array.from(dayPerformance.entries()).map(([day, d]) => ({
        dayName: days[day],
        avg: d.views.reduce((a, b) => a + b, 0) / d.views.length,
        count: d.views.length,
        vids: d.vids,
      })).sort((a, b) => b.avg - a.avg);

      const bestDay = rankedDays[0];
      const timingConfidence = this.calculateConfidence(sampleSize, bestDay.count);

      insights.push({
        category: 'timing',
        insight: `Releases on ${bestDay.dayName} correlate with higher initial velocity`,
        evidence: `${bestDay.dayName} releases averaged ${Math.round(bestDay.avg)} views (n=${bestDay.count}) across channel dataset.`,
        confidence: timingConfidence,
        recommendation: `Align channel weekly publication schedule to target ${bestDay.dayName} releases.`,
        actionRule: { preferredPublishDay: bestDay.dayName },
        sampleVideoIds: bestDay.vids,
      });
    }

    await this.persistInsights(channelId, insights);
    return insights;
  }

  /**
   * Statistical confidence scaling rule:
   * Prevents claiming causation from small sample sizes.
   * - N < 3 => max 0.20
   * - 3 <= N < 6 => max 0.55
   * - N >= 6 => scales up to 0.85
   */
  public calculateConfidence(totalObservations: number, categoryObservations: number): number {
    if (totalObservations < 3) return 0.2;
    if (totalObservations < 6) return Math.min(0.55, 0.3 + (categoryObservations / totalObservations) * 0.25);
    const base = Math.min(0.85, 0.5 + (totalObservations / 20) * 0.35);
    return parseFloat(base.toFixed(2));
  }

  private async persistInsights(channelId: string, insights: StructuredInsight[]): Promise<void> {
    for (const item of insights) {
      await prisma.learningInsight.create({
        data: {
          channelId,
          category: item.category,
          finding: item.insight,
          confidence: item.confidence,
          impactScore: item.confidence * 10,
          evidence: item.evidence,
          recommendation: item.recommendation,
          actionRuleJson: JSON.stringify(item.actionRule),
          sampleVideoIdsJson: JSON.stringify(item.sampleVideoIds),
        },
      });
    }
  }
}

export const learningAgent = new LearningAgent();

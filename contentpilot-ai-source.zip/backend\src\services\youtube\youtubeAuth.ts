import { google, Auth, youtube_v3 } from 'googleapis';
import { prisma } from '../../database/client.js';
import { config } from '../../config/index.js';
import { encryptSecret, decryptSecret } from '../../utils/crypto.js';
import { logger } from '../../utils/logger.js';
import { AppError } from '../../utils/errors.js';

export const YOUTUBE_OAUTH_SCOPES = [
  'https://www.googleapis.com/auth/youtube.upload',
  'https://www.googleapis.com/auth/youtube.readonly',
  'https://www.googleapis.com/auth/youtube.force-ssl',
  'https://www.googleapis.com/auth/youtubepartner',
];

export interface ChannelVerificationResult {
  connected: boolean;
  channelId?: string;
  title?: string;
  handle?: string;
  subscriberCount?: number;
  videoCount?: number;
  status: string;
}

export class YouTubeAuthService {
  /**
   * Initialize a new Google OAuth2 client with server-side credentials
   */
  public getOAuth2Client(): Auth.OAuth2Client {
    if (!config.YOUTUBE_CLIENT_ID || !config.YOUTUBE_CLIENT_SECRET) {
      throw new AppError(
        'YOUTUBE_CLIENT_ID and YOUTUBE_CLIENT_SECRET must be configured in environment',
        500,
        'YOUTUBE_CONFIG_MISSING'
      );
    }

    return new google.auth.OAuth2(
      config.YOUTUBE_CLIENT_ID,
      config.YOUTUBE_CLIENT_SECRET,
      config.YOUTUBE_REDIRECT_URI
    );
  }

  /**
   * Generate authorization URL for connecting a YouTube channel
   */
  public getAuthUrl(state?: string): string {
    const oauth2Client = this.getOAuth2Client();
    return oauth2Client.generateAuthUrl({
      access_type: 'offline',
      prompt: 'consent',
      scope: YOUTUBE_OAUTH_SCOPES,
      state,
    });
  }

  /**
   * Exchange authorization code for tokens and associate with Channel in DB
   */
  public async handleCallback(code: string, channelId: string): Promise<ChannelVerificationResult> {
    const oauth2Client = this.getOAuth2Client();
    const { tokens } = await oauth2Client.getToken(code);
    oauth2Client.setCredentials(tokens);

    if (!tokens.access_token) {
      throw new AppError('Failed to obtain access token from Google', 400, 'OAUTH_TOKEN_FAILED');
    }

    // Call YouTube API to verify channel identity
    const youtube = google.youtube({ version: 'v3', auth: oauth2Client });
    const response = await youtube.channels.list({
      part: ['snippet', 'statistics'],
      mine: true,
    });

    const ytChannel = response.data.items?.[0];
    if (!ytChannel || !ytChannel.id) {
      throw new AppError('No YouTube channel found associated with this Google account', 404, 'CHANNEL_NOT_FOUND');
    }

    const encryptedAccess = encryptSecret(tokens.access_token);
    const encryptedRefresh = tokens.refresh_token ? encryptSecret(tokens.refresh_token) : undefined;
    const expiresAt = tokens.expiry_date ? new Date(tokens.expiry_date) : new Date(Date.now() + 3600 * 1000);

    // Upsert credential record securely
    const existingCred = await prisma.credential.findUnique({
      where: {
        channelId_provider_keyType: {
          channelId,
          provider: 'youtube',
          keyType: 'oauth',
        },
      },
    });

    if (existingCred) {
      await prisma.credential.update({
        where: { id: existingCred.id },
        data: {
          encryptedKey: encryptedAccess,
          encryptedSecret: encryptedRefresh ?? existingCred.encryptedSecret,
          scopes: YOUTUBE_OAUTH_SCOPES.join(' '),
          expiresAt,
          status: 'active',
          updatedAt: new Date(),
        },
      });
    } else {
      await prisma.credential.create({
        data: {
          channelId,
          provider: 'youtube',
          keyType: 'oauth',
          encryptedKey: encryptedAccess,
          encryptedSecret: encryptedRefresh,
          scopes: YOUTUBE_OAUTH_SCOPES.join(' '),
          expiresAt,
          status: 'active',
        },
      });
    }

    // Update Channel with verified YouTube ID & handle
    await prisma.channel.update({
      where: { id: channelId },
      data: {
        youtubeChannelId: ytChannel.id,
        handle: ytChannel.snippet?.customUrl ?? null,
      },
    });

    logger.info({
      msg: 'Successfully connected YouTube channel',
      channelId,
      youtubeChannelId: ytChannel.id,
      title: ytChannel.snippet?.title,
    });

    return {
      connected: true,
      channelId: ytChannel.id,
      title: ytChannel.snippet?.title ?? undefined,
      handle: ytChannel.snippet?.customUrl ?? undefined,
      subscriberCount: ytChannel.statistics?.subscriberCount ? parseInt(ytChannel.statistics.subscriberCount, 10) : 0,
      videoCount: ytChannel.statistics?.videoCount ? parseInt(ytChannel.statistics.videoCount, 10) : 0,
      status: 'active',
    };
  }

  /**
   * Load and refresh YouTube client for channel
   */
  public async getAuthenticatedClient(
    channelId: string
  ): Promise<{ oauth2Client: Auth.OAuth2Client; youtube: youtube_v3.Youtube }> {
    const cred = await prisma.credential.findUnique({
      where: {
        channelId_provider_keyType: {
          channelId,
          provider: 'youtube',
          keyType: 'oauth',
        },
      },
    });

    if (!cred || !cred.encryptedKey || cred.status !== 'active') {
      throw new AppError(
        `YouTube credentials not found or inactive for channel '${channelId}'`,
        401,
        'YOUTUBE_NOT_CONNECTED'
      );
    }

    const accessToken = decryptSecret(cred.encryptedKey);
    const refreshToken = cred.encryptedSecret ? decryptSecret(cred.encryptedSecret) : undefined;

    const oauth2Client = this.getOAuth2Client();
    oauth2Client.setCredentials({
      access_token: accessToken,
      refresh_token: refreshToken,
      expiry_date: cred.expiresAt ? cred.expiresAt.getTime() : undefined,
    });

    // Check if token is expired or expiring within 2 minutes
    const isExpired = cred.expiresAt && cred.expiresAt.getTime() <= Date.now() + 2 * 60 * 1000;
    if (isExpired && refreshToken) {
      try {
        logger.info({ msg: 'Refreshing expired YouTube OAuth access token', channelId });
        const { credentials } = await oauth2Client.refreshAccessToken();
        oauth2Client.setCredentials(credentials);

        if (credentials.access_token) {
          await prisma.credential.update({
            where: { id: cred.id },
            data: {
              encryptedKey: encryptSecret(credentials.access_token),
              encryptedSecret: credentials.refresh_token
                ? encryptSecret(credentials.refresh_token)
                : cred.encryptedSecret,
              expiresAt: credentials.expiry_date
                ? new Date(credentials.expiry_date)
                : new Date(Date.now() + 3600 * 1000),
              status: 'active',
            },
          });
          logger.info({ msg: 'Refreshed and stored new YouTube access token', channelId });
        }
      } catch (refreshErr) {
        logger.error({ msg: 'Failed to refresh YouTube OAuth token', channelId, error: refreshErr });
        await prisma.credential.update({
          where: { id: cred.id },
          data: { status: 'expired' },
        });
        throw new AppError(
          'YouTube access token expired and could not be refreshed. Re-authentication required.',
          401,
          'TOKEN_EXPIRED'
        );
      }
    }

    const youtube = google.youtube({ version: 'v3', auth: oauth2Client });
    return { oauth2Client, youtube };
  }

  /**
   * Verify channel connection and fetch real-time channel profile
   */
  public async verifyChannel(channelId: string): Promise<ChannelVerificationResult> {
    try {
      const { youtube } = await this.getAuthenticatedClient(channelId);
      const res = await youtube.channels.list({
        part: ['snippet', 'statistics', 'status'],
        mine: true,
      });

      const item = res.data.items?.[0];
      if (!item) {
        return { connected: false, status: 'channel_not_found' };
      }

      return {
        connected: true,
        channelId: item.id ?? undefined,
        title: item.snippet?.title ?? undefined,
        handle: item.snippet?.customUrl ?? undefined,
        subscriberCount: item.statistics?.subscriberCount ? parseInt(item.statistics.subscriberCount, 10) : 0,
        videoCount: item.statistics?.videoCount ? parseInt(item.statistics.videoCount, 10) : 0,
        status: 'active',
      };
    } catch (err) {
      logger.warn({ msg: 'YouTube channel verification failed', channelId, error: err });
      return { connected: false, status: 'error' };
    }
  }

  /**
   * Disconnect YouTube channel and revoke token
   */
  public async disconnectChannel(channelId: string): Promise<void> {
    const cred = await prisma.credential.findUnique({
      where: {
        channelId_provider_keyType: {
          channelId,
          provider: 'youtube',
          keyType: 'oauth',
        },
      },
    });

    if (cred) {
      if (cred.encryptedKey) {
        try {
          const accessToken = decryptSecret(cred.encryptedKey);
          const oauth2Client = this.getOAuth2Client();
          await oauth2Client.revokeToken(accessToken);
        } catch (revokeErr) {
          logger.warn({ msg: 'Failed to revoke token with Google during disconnect', channelId });
        }
      }

      await prisma.credential.update({
        where: { id: cred.id },
        data: {
          status: 'revoked',
          encryptedKey: null,
          encryptedSecret: null,
          expiresAt: null,
        },
      });
    }

    await prisma.channel.update({
      where: { id: channelId },
      data: { youtubeChannelId: null },
    });

    logger.info({ msg: 'Disconnected YouTube channel', channelId });
  }
}

export const youtubeAuthService = new YouTubeAuthService();

import { describe, it, expect, beforeEach } from 'vitest';
import fs from 'node:fs/promises';
import path from 'node:path';
import { prisma } from '../../src/database/client.js';
import { preUploadSafetyChecker, PreUploadSafetyError } from '../../src/services/youtube/preUploadSafetyCheck.js';
import { storageManager } from '../../src/storage/storageManager.js';

describe('Pre-Upload Safety Check', () => {
  let channelId: string;
  let projectId: string;
  let validMp4Path: string;
  let validAudioPath: string;

  beforeEach(async () => {
    const user = await prisma.user.upsert({
      where: { email: 'safety_test_user@contentpilot.ai' },
      update: {},
      create: { email: 'safety_test_user@contentpilot.ai', name: 'Safety Test User' },
    });

    const channel = await prisma.channel.create({
      data: {
        userId: user.id,
        name: 'Safety Channel',
        niche: 'Engineering',
        targetAudience: 'Developers',
        brandVoice: 'Authoritative',
        visualStyle: 'Modern',
      },
    });
    channelId = channel.id;

    // Create strategy & script
    const strategy = await prisma.contentStrategy.create({
      data: {
        channelId,
        titleConcept: 'Pre-Upload Safety In Action',
        hook: 'Never publish without checking safety gates.',
        angle: 'Safety engineering',
        targetAudience: 'Devs',
        primaryKeyword: 'safety',
        cta: 'Subscribe',
        thumbnailConcept: 'Locked vault',
        reasonForSelection: 'Critical testing',
      },
    });

    const script = await prisma.script.create({
      data: {
        strategyId: strategy.id,
        channelId,
        title: 'Safety Test Screenplay',
        hookText: 'Checking all gates',
        hookVisualCue: 'Lock indicator',
        sectionsJson: '[]',
        ctaText: 'Subscribe',
        ctaVisualCue: 'Button',
        outroText: 'Goodbye',
        outroVisualCue: 'Card',
      },
    });

    const project = await prisma.videoProject.create({
      data: {
        channelId,
        title: 'Pre-Upload Safety Test Video',
        scriptId: script.id,
        status: 'AWAITING_APPROVAL',
      },
    });
    projectId = project.id;

    // Create real files in storage for the test
    const videoDir = storageManager.getVideoDir(projectId);
    validMp4Path = path.join(videoDir, 'test_render.mp4');
    await fs.writeFile(validMp4Path, Buffer.from('ftypmp42fakevalidmp4data'));

    const audioDir = storageManager.getAudioDir(projectId);
    validAudioPath = path.join(audioDir, 'test_audio.wav');
    await fs.writeFile(validAudioPath, Buffer.from('RIFFfakewavdata'));
  });

  it('should strictly BLOCK upload if approval is missing or not APPROVED', async () => {
    // No approval request yet
    await expect(preUploadSafetyChecker.verify(projectId)).rejects.toThrow(PreUploadSafetyError);

    // Approval request exists but is still WAITING_APPROVAL
    await prisma.approvalRequest.create({
      data: {
        projectId,
        channelId,
        status: 'WAITING_APPROVAL',
      },
    });

    await expect(preUploadSafetyChecker.verify(projectId)).rejects.toThrow(PreUploadSafetyError);
  });

  it('should strictly BLOCK upload if QC is missing or failed', async () => {
    // Approve project
    await prisma.approvalRequest.create({
      data: {
        projectId,
        channelId,
        status: 'APPROVED',
        approvedBy: 'lead_editor@contentpilot.ai',
        approvedAt: new Date(),
      },
    });

    // QC missing -> throws
    await expect(preUploadSafetyChecker.verify(projectId)).rejects.toThrow(/QC_CHECK_FAILED/);

    // QC exists but status is BLOCKED
    await prisma.qualityCheck.create({
      data: {
        projectId,
        passed: false,
        status: 'BLOCKED',
        overallScore: 40.0,
        loudnessLufs: -25.0,
      },
    });

    await expect(preUploadSafetyChecker.verify(projectId)).rejects.toThrow(/QC_CHECK_FAILED/);
  });

  it('should strictly BLOCK upload if video MP4 is missing or invalid', async () => {
    // Approve and pass QC
    await prisma.approvalRequest.create({
      data: {
        projectId,
        channelId,
        status: 'APPROVED',
        approvedBy: 'lead_editor@contentpilot.ai',
        approvedAt: new Date(),
      },
    });

    await prisma.qualityCheck.create({
      data: {
        projectId,
        passed: true,
        status: 'PASS',
        overallScore: 95.0,
        loudnessLufs: -14.0,
      },
    });

    // No render record -> throws
    await expect(preUploadSafetyChecker.verify(projectId)).rejects.toThrow(/VIDEO_CHECK_FAILED/);
  });

  it('should strictly BLOCK upload if narration is missing or 0 seconds duration', async () => {
    // Setup approval, QC, video render
    await prisma.approvalRequest.create({
      data: {
        projectId,
        channelId,
        status: 'APPROVED',
        approvedBy: 'lead_editor@contentpilot.ai',
        approvedAt: new Date(),
      },
    });

    await prisma.qualityCheck.create({
      data: {
        projectId,
        passed: true,
        status: 'PASS',
        overallScore: 95.0,
        loudnessLufs: -14.0,
      },
    });

    await prisma.videoRender.create({
      data: {
        projectId,
        outputPath: validMp4Path,
        durationSec: 10.0,
        fileSize: 1024,
        status: 'completed',
        renderTimeSec: 1.0,
      },
    });

    // Narration missing -> throws
    await expect(preUploadSafetyChecker.verify(projectId)).rejects.toThrow(/NARRATION_CHECK_FAILED/);
  });

  it('should strictly BLOCK upload if metadata title exceeds 100 chars', async () => {
    const project = await prisma.videoProject.findUnique({ where: { id: projectId } });

    await prisma.approvalRequest.create({
      data: {
        projectId,
        channelId,
        status: 'APPROVED',
        approvedBy: 'lead_editor@contentpilot.ai',
        approvedAt: new Date(),
      },
    });

    await prisma.qualityCheck.create({
      data: {
        projectId,
        passed: true,
        status: 'PASS',
        overallScore: 95.0,
        loudnessLufs: -14.0,
      },
    });

    await prisma.videoRender.create({
      data: {
        projectId,
        outputPath: validMp4Path,
        durationSec: 10.0,
        fileSize: 1024,
        status: 'completed',
        renderTimeSec: 1.0,
      },
    });

    const narration = await prisma.narration.create({
      data: {
        scriptId: project!.scriptId!,
        channelId,
        voiceId: 'voice_en',
        audioPath: validAudioPath,
        durationSec: 10.0,
        status: 'validated',
      },
    });

    await prisma.videoProject.update({
      where: { id: projectId },
      data: { narrationId: narration.id },
    });

    // Seo title > 100 chars
    const overlyLongTitle = 'A'.repeat(105);
    const seo = await prisma.seoPackage.create({
      data: {
        scriptId: project!.scriptId!,
        channelId,
        recommendedTitle: overlyLongTitle,
        titleCandidatesJson: '[]',
        description: 'Valid description that has plenty of length',
        chaptersJson: '[]',
        tagsJson: '["ai"]',
        hashtagsJson: '["#ai"]',
        primaryKeyword: 'ai',
      },
    });

    await prisma.videoProject.update({
      where: { id: projectId },
      data: { seoPackageId: seo.id },
    });

    await expect(preUploadSafetyChecker.verify(projectId)).rejects.toThrow(/exceeds YouTube 100 char limit/);
  });

  it('should PASS pre-upload check when all 5 conditions are satisfied', async () => {
    const project = await prisma.videoProject.findUnique({ where: { id: projectId } });

    // 1. Approval
    await prisma.approvalRequest.create({
      data: {
        projectId,
        channelId,
        status: 'APPROVED',
        approvedBy: 'lead_editor@contentpilot.ai',
        approvedAt: new Date(),
      },
    });

    // 2. QC
    await prisma.qualityCheck.create({
      data: {
        projectId,
        passed: true,
        status: 'PASS',
        overallScore: 98.0,
        loudnessLufs: -14.0,
      },
    });

    // 3. Video Render
    await prisma.videoRender.create({
      data: {
        projectId,
        outputPath: validMp4Path,
        durationSec: 10.0,
        fileSize: 1024,
        status: 'completed',
        renderTimeSec: 1.0,
      },
    });

    // 4. Narration
    const narration = await prisma.narration.create({
      data: {
        scriptId: project!.scriptId!,
        channelId,
        voiceId: 'voice_en',
        audioPath: validAudioPath,
        durationSec: 10.0,
        status: 'validated',
      },
    });

    // 5. Metadata
    const seo = await prisma.seoPackage.create({
      data: {
        scriptId: project!.scriptId!,
        channelId,
        recommendedTitle: 'The Ultimate Guide to Production AI Agents',
        titleCandidatesJson: '[]',
        description: 'In this complete architectural breakdown we explore how autonomous multi-agent pipelines work.',
        chaptersJson: '[]',
        tagsJson: '["ai", "agents"]',
        hashtagsJson: '["#ai"]',
        primaryKeyword: 'ai agents',
      },
    });

    await prisma.videoProject.update({
      where: { id: projectId },
      data: {
        narrationId: narration.id,
        seoPackageId: seo.id,
      },
    });

    const result = await preUploadSafetyChecker.verify(projectId);
    expect(result.passed).toBe(true);
    expect(result.errors).toHaveLength(0);
    expect(result.checks.approval.passed).toBe(true);
    expect(result.checks.qc.passed).toBe(true);
    expect(result.checks.video.passed).toBe(true);
    expect(result.checks.narration.passed).toBe(true);
    expect(result.checks.metadata.passed).toBe(true);
  });
});

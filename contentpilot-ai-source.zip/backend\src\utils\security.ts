import path from 'node:path';
import fs from 'node:fs/promises';
import { config } from '../config/index.js';
import { AppError } from './errors.js';

/**
 * Security Hardening Utilities
 * Protects against Path Traversal, SSRF, Media Exploits, and Untrusted AI Inputs.
 */

// Private IP ranges for SSRF prevention
const BLOCKED_IP_PATTERNS = [
  /^127\./,
  /^10\./,
  /^172\.(1[6-9]|2[0-9]|3[0-1])\./,
  /^192\.168\./,
  /^169\.254\./, // AWS / GCP metadata service
  /^0\./,
  /^localhost$/i,
  /^::1$/,
];

export class SecurityGuard {
  /**
   * Validates that a file path resolves strictly within the allowed storage boundary.
   * Prevents Path Traversal attacks (e.g., ../../../etc/passwd).
   */
  public static validatePathWithinStorage(targetPath: string, customBaseDir = config.STORAGE_DIR): string {
    const baseDir = path.resolve(customBaseDir);
    const resolved = path.resolve(targetPath);

    if (!resolved.startsWith(baseDir)) {
      throw new AppError(
        `Security Violation: Access denied to path outside storage sandbox: ${targetPath}`,
        403,
        'PATH_TRAVERSAL_DETECTED'
      );
    }

    return resolved;
  }

  /**
   * SSRF Prevention: Validates a URL against prohibited internal hostnames and schemes.
   */
  public static validateSafeExternalUrl(urlStr: string): URL {
    let parsed: URL;
    try {
      parsed = new URL(urlStr);
    } catch {
      throw new AppError(`Invalid URL provided: ${urlStr}`, 400, 'MALFORMED_URL');
    }

    if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') {
      throw new AppError(`Prohibited protocol: ${parsed.protocol}. Only HTTP/HTTPS allowed.`, 400, 'UNSAFE_PROTOCOL');
    }

    const hostname = parsed.hostname;
    for (const pattern of BLOCKED_IP_PATTERNS) {
      if (pattern.test(hostname)) {
        throw new AppError(
          `Security Violation: Access to private/internal network address (${hostname}) blocked.`,
          403,
          'SSRF_DETECTED'
        );
      }
    }

    return parsed;
  }

  /**
   * Validates media file magic numbers to prevent malicious payload uploads disguised as media.
   */
  public static async validateMediaFileMagicBytes(
    filePath: string,
    expectedType: 'mp4' | 'png' | 'jpeg' | 'wav'
  ): Promise<boolean> {
    const handle = await fs.open(filePath, 'r');
    try {
      const buffer = Buffer.alloc(16);
      await handle.read(buffer, 0, 16, 0);

      switch (expectedType) {
        case 'mp4': {
          // MP4 files start with ftyp box at offset 4
          const ftypMarker = buffer.subarray(4, 8).toString('utf-8');
          return ftypMarker === 'ftyp';
        }
        case 'png': {
          // PNG magic number: 89 50 4E 47 0D 0A 1A 0A
          return (
            buffer[0] === 0x89 &&
            buffer[1] === 0x50 &&
            buffer[2] === 0x4e &&
            buffer[3] === 0x47
          );
        }
        case 'jpeg': {
          // JPEG magic number: FF D8 FF
          return buffer[0] === 0xff && buffer[1] === 0xd8 && buffer[2] === 0xff;
        }
        case 'wav': {
          // RIFF header ... WAVE
          const riff = buffer.subarray(0, 4).toString('utf-8');
          const wave = buffer.subarray(8, 12).toString('utf-8');
          return riff === 'RIFF' && wave === 'WAVE';
        }
        default:
          return false;
      }
    } finally {
      await handle.close();
    }
  }

  /**
   * Untrusted AI output sanitization:
   * Strips potential control escape characters, null bytes, and malicious script injection.
   */
  public static sanitizeAiText(raw: string): string {
    if (!raw) return '';
    // Strip null bytes and non-printable control characters except newline and tab
    return raw.replace(/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/g, '').trim();
  }
}

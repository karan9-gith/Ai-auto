export type UploadLifecycleStatus =
  | 'QUEUED'
  | 'UPLOADING'
  | 'PROCESSING'
  | 'PUBLISHED'
  | 'FAILED';

export interface UploadOptions {
  projectId: string;
  channelId: string;
  privacyStatus?: 'private' | 'unlisted' | 'public';
  scheduledPublishTime?: Date;
  playlistId?: string;
  idempotencyKey?: string;
}

export interface UploadProgress {
  bytesUploaded: number;
  totalBytes: number;
  percentage: number;
  status: UploadLifecycleStatus;
}

export interface PublishedVideoResult {
  youtubeVideoId: string;
  youtubeUrl: string;
  title: string;
  privacyStatus: string;
  publishedAt: Date;
  idempotencyKey: string;
}

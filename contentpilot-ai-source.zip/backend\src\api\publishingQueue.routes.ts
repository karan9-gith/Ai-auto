import { Router, Request, Response, NextFunction } from 'express';
import { prisma } from '../database/client.js';
import { AppError } from '../utils/errors.js';

const router = Router();
const param = (p: string | string[]): string => (Array.isArray(p) ? p[0] : p);

// GET all items in publishing queue
router.get('/', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const channelId = req.query.channelId as string | undefined;
    const items = await prisma.publishingQueue.findMany({
      where: channelId ? { channelId } : undefined,
      include: {
        project: {
          select: {
            id: true,
            title: true,
            status: true,
            currentStage: true,
            format: true,
          },
        },
        uploads: {
          orderBy: { createdAt: 'desc' },
          take: 1,
        },
      },
      orderBy: { createdAt: 'desc' },
    });
    res.json({ success: true, count: items.length, data: items });
  } catch (err) {
    next(err);
  }
});

// POST cancel queued publishing item
router.post('/:id/cancel', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const id = param(req.params.id);
    const item = await prisma.publishingQueue.findUnique({ where: { id } });
    if (!item) {
      throw new AppError('Publishing queue item not found', 404, 'NOT_FOUND');
    }

    if (item.status === 'PUBLISHED') {
      throw new AppError('Cannot cancel: video is already published', 400, 'ALREADY_PUBLISHED');
    }

    const updated = await prisma.publishingQueue.update({
      where: { id },
      data: { status: 'CANCELLED' },
    });

    res.json({ success: true, message: 'Publishing item cancelled', data: updated });
  } catch (err) {
    next(err);
  }
});

// POST retry failed item
router.post('/:id/retry', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const id = param(req.params.id);
    const item = await prisma.publishingQueue.findUnique({ where: { id } });
    if (!item) {
      throw new AppError('Publishing queue item not found', 404, 'NOT_FOUND');
    }

    const updated = await prisma.publishingQueue.update({
      where: { id },
      data: {
        status: 'QUEUED',
        uploadAttempts: item.uploadAttempts + 1,
        lastError: null,
      },
    });

    res.json({ success: true, message: 'Item queued for retry', data: updated });
  } catch (err) {
    next(err);
  }
});

export default router;

export class AppError extends Error {
  public readonly statusCode: number;
  public readonly isOperational: boolean;
  public readonly code: string;

  constructor(message: string, statusCode = 500, code = 'INTERNAL_ERROR', isOperational = true) {
    super(message);
    this.name = this.constructor.name;
    this.statusCode = statusCode;
    this.code = code;
    this.isOperational = isOperational;
    Error.captureStackTrace(this, this.constructor);
  }
}

export class ValidationError extends AppError {
  public readonly details: unknown;

  constructor(message: string, details?: unknown) {
    super(message, 400, 'VALIDATION_ERROR');
    this.details = details;
  }
}

export class NotFoundError extends AppError {
  constructor(resource: string, id?: string) {
    super(`${resource}${id ? ` with id '${id}'` : ''} not found`, 404, 'NOT_FOUND');
  }
}

export class SecurityError extends AppError {
  constructor(message: string) {
    super(message, 403, 'SECURITY_VIOLATION');
  }
}

export class AIProviderError extends AppError {
  public readonly retryable: boolean;

  constructor(message: string, retryable = true) {
    super(message, 502, 'AI_PROVIDER_ERROR');
    this.retryable = retryable;
  }
}

export class QualityGateBlockedError extends AppError {
  public readonly findings: unknown;

  constructor(message: string, findings?: unknown) {
    super(message, 422, 'QUALITY_GATE_BLOCKED');
    this.findings = findings;
  }
}

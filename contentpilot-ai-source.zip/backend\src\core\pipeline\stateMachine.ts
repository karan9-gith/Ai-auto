import { prisma } from '../../database/client.js';
import { logger } from '../../utils/logger.js';
import { AppError } from '../../utils/errors.js';
import { VideoPipelineState, VideoPipeStateType, StateTransitionEvent } from './stateTypes.js';

export class InvalidStateTransitionError extends AppError {
  constructor(fromState: string, toState: string, reason?: string) {
    super(
      `Invalid state transition from '${fromState}' to '${toState}'${reason ? `: ${reason}` : ''}`,
      400,
      'INVALID_STATE_TRANSITION'
    );
  }
}

export class PipelineStateMachine {
  /**
   * Allowed transitions matrix
   */
  private readonly ALLOWED_TRANSITIONS: Record<VideoPipeStateType, VideoPipeStateType[]> = {
    [VideoPipelineState.IDEA]: [
      VideoPipelineState.RESEARCHED,
    ],
    [VideoPipelineState.RESEARCHED]: [
      VideoPipelineState.STRATEGY_READY,
      VideoPipelineState.IDEA, // Rollback/discard
    ],
    [VideoPipelineState.STRATEGY_READY]: [
      VideoPipelineState.SCRIPT_READY,
      VideoPipelineState.RESEARCHED,
    ],
    [VideoPipelineState.SCRIPT_READY]: [
      VideoPipelineState.SEO_READY,
      VideoPipelineState.NARRATION_READY,
      VideoPipelineState.STRATEGY_READY,
    ],
    [VideoPipelineState.SEO_READY]: [
      VideoPipelineState.THUMBNAIL_READY,
      VideoPipelineState.NARRATION_READY,
      VideoPipelineState.SCRIPT_READY,
    ],
    [VideoPipelineState.THUMBNAIL_READY]: [
      VideoPipelineState.NARRATION_READY,
      VideoPipelineState.VISUALS_READY,
      VideoPipelineState.SEO_READY,
    ],
    [VideoPipelineState.NARRATION_READY]: [
      VideoPipelineState.VISUALS_READY,
      VideoPipelineState.SCRIPT_READY, // If narration voice fails/rejected
    ],
    [VideoPipelineState.VISUALS_READY]: [
      VideoPipelineState.RENDERED,
      VideoPipelineState.NARRATION_READY,
    ],
    [VideoPipelineState.RENDERED]: [
      VideoPipelineState.QC_PASSED,
      VideoPipelineState.VISUALS_READY, // Re-render needed
      VideoPipelineState.NARRATION_READY,
    ],
    [VideoPipelineState.QC_PASSED]: [
      VideoPipelineState.AWAITING_APPROVAL,
      VideoPipelineState.RENDERED, // If re-run QC
    ],
    [VideoPipelineState.AWAITING_APPROVAL]: [
      VideoPipelineState.APPROVED,
      // Human can send back to any prior creative stage:
      VideoPipelineState.SCRIPT_READY,
      VideoPipelineState.SEO_READY,
      VideoPipelineState.THUMBNAIL_READY,
      VideoPipelineState.NARRATION_READY,
      VideoPipelineState.VISUALS_READY,
      VideoPipelineState.RENDERED,
      VideoPipelineState.IDEA, // Full rejection / back to idea
    ],
    [VideoPipelineState.APPROVED]: [
      VideoPipelineState.SCHEDULED,
      VideoPipelineState.UPLOADING,
      VideoPipelineState.AWAITING_APPROVAL, // Can un-approve back to review
    ],
    [VideoPipelineState.SCHEDULED]: [
      VideoPipelineState.UPLOADING,
      VideoPipelineState.AWAITING_APPROVAL, // Cancel schedule
      VideoPipelineState.APPROVED,
    ],
    [VideoPipelineState.UPLOADING]: [
      VideoPipelineState.PUBLISHED,
      VideoPipelineState.APPROVED, // On retryable upload error
      VideoPipelineState.SCHEDULED,
    ],
    [VideoPipelineState.PUBLISHED]: [
      VideoPipelineState.ANALYTICS_PENDING,
    ],
    [VideoPipelineState.ANALYTICS_PENDING]: [
      VideoPipelineState.LEARNING_COMPLETE,
    ],
    [VideoPipelineState.LEARNING_COMPLETE]: [
      // Terminal state for individual video pipeline lifecycle
    ],
  };

  /**
   * Check if transition is valid
   */
  public isValidTransition(fromState: VideoPipeStateType, toState: VideoPipeStateType): boolean {
    const allowed = this.ALLOWED_TRANSITIONS[fromState];
    return !!allowed && allowed.includes(toState);
  }

  /**
   * Transition video project to a new state with audit and history logging
   */
  public async transition(
    projectId: string,
    toState: VideoPipeStateType,
    trigger: 'user_action' | 'agent_complete' | 'error_recovery' | 'scheduler' | 'system',
    meta?: Record<string, unknown>
  ): Promise<void> {
    const project = await prisma.videoProject.findUnique({
      where: { id: projectId },
    });

    if (!project) {
      throw new AppError(`Video project '${projectId}' not found`, 404, 'PROJECT_NOT_FOUND');
    }

    const currentState = (project.status as VideoPipeStateType) || VideoPipelineState.IDEA;

    // Self-transition is a no-op if same state
    if (currentState === toState) {
      return;
    }

    // STRICT GOVERNANCE: Verify transition validity
    if (!this.isValidTransition(currentState, toState)) {
      // Special safety check: No publishing operation may bypass approval
      if (
        (toState === VideoPipelineState.SCHEDULED ||
          toState === VideoPipelineState.UPLOADING ||
          toState === VideoPipelineState.PUBLISHED) &&
        currentState !== VideoPipelineState.APPROVED &&
        currentState !== VideoPipelineState.SCHEDULED
      ) {
        throw new InvalidStateTransitionError(
          currentState,
          toState,
          'Publishing and scheduling operations strictly require explicit prior approval (APPROVED state)'
        );
      }

      throw new InvalidStateTransitionError(currentState, toState);
    }

    // Update project state in DB
    await prisma.videoProject.update({
      where: { id: projectId },
      data: {
        status: toState,
        currentStage: toState.toLowerCase(),
      },
    });

    // Immutable state transition log
    await prisma.pipelineStateLog.create({
      data: {
        projectId,
        fromState: currentState,
        toState,
        trigger,
        metaJson: meta ? JSON.stringify(meta) : null,
        timestamp: new Date(),
      },
    });

    logger.info({
      msg: 'Pipeline state transition recorded',
      projectId,
      from: currentState,
      to: toState,
      trigger,
    });
  }

  /**
   * Retrieve state transition history for a video project
   */
  public async getHistory(projectId: string) {
    return prisma.pipelineStateLog.findMany({
      where: { projectId },
      orderBy: { timestamp: 'asc' },
    });
  }
}

export const pipelineStateMachine = new PipelineStateMachine();
